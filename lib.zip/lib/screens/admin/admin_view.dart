import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:core_portal/screens/admin/admin_controller.dart';
import 'package:core_portal/screens/super_admin/super_admin_role_list_view.dart';
import 'package:core_portal/widgets/custom_snackbar.dart';
import 'package:core_portal/routes/page_route.dart';
import 'package:core_portal/screens/super_admin/super_admin_edit_user_groups_view.dart';

class AdminView extends GetView<AdminController> {
  const AdminView({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      _buildDashboardHome(context),
      const AdminAppsListView(),
      _buildUsersTab(context),
      _buildAdminSettingsTab(context),
    ];

    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      body: Obx(() => pages[controller.currentIndex.value]),
      bottomNavigationBar: Obx(
        () => Container(
          margin: const EdgeInsets.only(left: 16, right: 16, bottom: 20),
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.95),
            borderRadius: BorderRadius.circular(35),
            border: Border.all(
              color: const Color(0xffD4AF37).withOpacity(0.2),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xffD4AF37).withOpacity(0.08),
                blurRadius: 25,
                offset: const Offset(0, 12),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(0, Icons.dashboard_rounded, "ផ្ទាំងគ្រប់គ្រង"),
              _buildNavItem(1, Icons.grid_view_rounded, "កម្មវិធី"),
              _buildNavItem(2, Icons.people_alt_rounded, "អ្នកប្រើប្រាស់"),
              _buildNavItem(3, Icons.settings_rounded, "ការកំណត់"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    final isSelected = controller.currentIndex.value == index;

    return GestureDetector(
      onTap: () => controller.changeTab(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xffFCFAF3) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? const Color(0xffE9D8A6).withOpacity(0.5)
                : Colors.transparent,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected
                  ? const Color(0xff8A6514)
                  : Colors.grey.shade500,
              size: 20,
            ),
            const SizedBox(width: 6),
            AnimatedCrossFade(
              firstChild: Text(
                label,
                style: GoogleFonts.kantumruyPro(
                  color: const Color(0xff8A6514),
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.1,
                ),
              ),
              secondChild: const SizedBox.shrink(),
              crossFadeState: isSelected
                  ? CrossFadeState.showFirst
                  : CrossFadeState.showSecond,
              duration: const Duration(milliseconds: 200),
            ),
          ],
        ),
      ),
    );
  }

  /// ==========================================
  /// 1. DASHBOARD TAB VIEW
  /// ==========================================
  Widget _buildDashboardHome(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        title: Text(
          "ផ្ទាំងគ្រប់គ្រង Admin",
          style: GoogleFonts.kantumruyPro(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: const Color(0xff0F172A),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.logout_rounded,
              color: Color(0xff64748B),
              size: 22,
            ),
            onPressed: () => _confirmLogout(context),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: controller.fetchDashboardData,
        color: const Color(0xff8A6514),
        child: Obx(() {
          if (controller.isLoading.value && controller.appsList.isEmpty) {
            return const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xff8A6514)),
              ),
            );
          }

          return Stack(
            children: [
              SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildWelcomeCard(),
                    const SizedBox(height: 20),
                    _buildStatsGrid(),
                    const SizedBox(height: 20),
                    _buildAppsSection(),
                    const SizedBox(height: 20),
                    _buildRecentAnnouncementsSection(),
                    const SizedBox(height: 20),
                    _buildAuditLogsSection(),
                    const SizedBox(height: 20),
                    _buildQuickAccessSection(context),
                    const SizedBox(height: 30),
                  ],
                ),
              ),
              if (controller.isBackingUp.value) _buildBackupOverlay(),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xff8A6514), Color(0xff6B5005)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: const Color(0xff8A6514).withOpacity(0.15),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "សួស្តី, អភិបាលប្រព័ន្ធ!",
                style: GoogleFonts.kantumruyPro(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Text(
                  "Online",
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 10,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            "សូមស្វាគមន៍មកកាន់ប្រព័ន្ធគ្រប់គ្រងសេវាព័ត៌មានវិទ្យា ក្រសួងមហាផ្ទៃ។",
            style: GoogleFonts.kantumruyPro(
              color: Colors.white.withOpacity(0.85),
              fontSize: 13,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsGrid() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.3,
      children: [
        _buildStatCard(
          "កម្មវិធីសរុប",
          controller.totalApps.value.toString(),
          Icons.grid_view_rounded,
          const Color(0xffEFF6FF),
          const Color(0xff2563EB),
        ),
        _buildStatCard(
          "អ្នកប្រើប្រាស់សរុប",
          controller.totalUsers.value.toString(),
          Icons.people_alt_rounded,
          const Color(0xffECFDF5),
          const Color(0xff10B981),
        ),
        _buildStatCard(
          "កំពុងដំណើរការ",
          controller.runningApps.value.toString(),
          Icons.toggle_on_rounded,
          const Color(0xffFEF3C7),
          const Color(0xffD97706),
        ),
        _buildStatCard(
          "សេចក្តីប្រកាស",
          controller.announcementsCount.value.toString(),
          Icons.notifications_active_rounded,
          const Color(0xffFEE2E2),
          const Color(0xffEF4444),
        ),
      ],
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color bgIconColor,
    Color accentColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xffF1F5F9)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: bgIconColor,
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: accentColor, size: 18),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: Colors.grey[300],
                size: 10,
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.kantumruyPro(
                  fontSize: 11,
                  color: const Color(0xff64748B),
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff0F172A),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRecentAnnouncementsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "សេចក្តីប្រកាសថ្មីៗ",
              style: GoogleFonts.kantumruyPro(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: const Color(0xff0F172A),
              ),
            ),
            TextButton(
              onPressed: () =>
                  Get.toNamed(AppRoutes.announcement, arguments: 'admin'),
              child: Text(
                "មើលទាំងអស់ >",
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff8A6514),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (controller.announcementsList.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xffE2E8F0)),
            ),
            child: Center(
              child: Text(
                "មិនមានសេចក្តីប្រកាសឡើយ",
                style: GoogleFonts.kantumruyPro(
                  color: Colors.grey,
                  fontSize: 13,
                ),
              ),
            ),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: controller.announcementsList.length > 2
                ? 2
                : controller.announcementsList.length,
            separatorBuilder: (context, index) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final announcement = controller.announcementsList[index];
              return _buildAnnouncementItemCard(announcement);
            },
          ),
      ],
    );
  }

  Widget _buildAnnouncementItemCard(Map<String, dynamic> ann) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffF1F5F9)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              color: Color(0xffFEF3C7),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.campaign_outlined,
              color: Color(0xffD97706),
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ann['title'] ?? '',
                  style: GoogleFonts.kantumruyPro(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: const Color(0xff1E293B),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  ann['date'] ?? '',
                  style: GoogleFonts.poppins(
                    fontSize: 10,
                    color: const Color(0xff94A3B8),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAuditLogsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "សកម្មភាពថ្មីៗនៃប្រព័ន្ធ",
          style: GoogleFonts.kantumruyPro(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: const Color(0xff0F172A),
          ),
        ),
        const SizedBox(height: 12),
        if (controller.auditLogs.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xffE2E8F0)),
            ),
            child: Center(
              child: Text(
                "មិនទាន់មានសកម្មភាពនៅឡើយទេ",
                style: GoogleFonts.kantumruyPro(
                  color: Colors.grey,
                  fontSize: 13,
                ),
              ),
            ),
          )
        else
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xffF1F5F9)),
            ),
            child: ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: controller.auditLogs.length > 3
                  ? 3
                  : controller.auditLogs.length,
              separatorBuilder: (context, index) =>
                  const Divider(height: 24, color: Color(0xffF1F5F9)),
              itemBuilder: (context, index) {
                final log = controller.auditLogs[index];
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: const BoxDecoration(
                        color: Color(0xffDCFCE7),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.campaign_rounded,
                        color: Color(0xff16A34A),
                        size: 14,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            log['title'] ?? '',
                            style: GoogleFonts.kantumruyPro(
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              color: const Color(0xff0F172A),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            log['desc'] ?? '',
                            style: GoogleFonts.kantumruyPro(
                              fontSize: 11,
                              color: const Color(0xff475569),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            log['time'] ?? '',
                            style: GoogleFonts.poppins(
                              fontSize: 9,
                              color: const Color(0xff94A3B8),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
      ],
    );
  }

  Widget _buildAppsSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.grid_view_rounded,
                    color: Color(0xff8A6514),
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "កម្មវិធី",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff0F172A),
                    ),
                  ),
                ],
              ),
              TextButton(
                onPressed: () => Get.to(() => const AdminAppsListView()),
                child: Text(
                  "មើលទាំងអស់ >",
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff8A6514),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _buildAppTableHeader(),
          const Divider(height: 1, color: Color(0xffE2E8F0)),
          if (controller.appsList.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Center(
                child: Text(
                  "មិនមានទិន្នន័យឡើយ",
                  style: GoogleFonts.kantumruyPro(
                    color: Colors.grey,
                    fontSize: 13,
                  ),
                ),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: controller.appsList.length,
              separatorBuilder: (context, index) =>
                  const Divider(height: 1, color: Color(0xffF1F5F9)),
              itemBuilder: (context, index) {
                final app = controller.appsList[index];
                return _buildAppTableRow(index + 1, app);
              },
            ),
        ],
      ),
    );
  }

  Widget _buildAppTableHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
      child: Row(
        children: [
          SizedBox(
            width: 30,
            child: Text(
              "#",
              style: GoogleFonts.kantumruyPro(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: const Color(0xff64748B),
              ),
            ),
          ),
          Expanded(
            child: Text(
              "ឈ្មោះកម្មវិធី",
              style: GoogleFonts.kantumruyPro(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: const Color(0xff64748B),
              ),
            ),
          ),
          Text(
            "ស្ថានភាព",
            style: GoogleFonts.kantumruyPro(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: const Color(0xff64748B),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppTableRow(int number, Map<String, dynamic> app) {
    final titleKh = app['titleKh'] ?? 'កម្មវិធី';
    final titleEn = app['titleEn'] ?? 'App';
    final bool isActive = app['isActive'] ?? true;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
      child: Row(
        children: [
          SizedBox(
            width: 30,
            child: Text(
              number.toString(),
              style: GoogleFonts.poppins(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xff475569),
              ),
            ),
          ),
          Expanded(
            child: Row(
              children: [
                _buildAppIconAvatar(app),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        titleKh,
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xff0F172A),
                        ),
                      ),
                      Text(
                        titleEn,
                        style: GoogleFonts.poppins(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xff64748B),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: isActive
                  ? const Color(0xffECFDF5)
                  : const Color(0xffFEE2E2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isActive
                    ? const Color(0xffA7F3D0)
                    : const Color(0xffFECACA),
              ),
            ),
            child: Text(
              isActive ? "ដំណើរការ" : "ផ្អាក",
              style: GoogleFonts.kantumruyPro(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                color: isActive
                    ? const Color(0xff065F46)
                    : const Color(0xff991B1B),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppIconAvatar(Map<String, dynamic> app) {
    final String iconPath = app['icon'] ?? 'assets/img/about-moi-logo.png';
    final String iconUrl = app['iconUrl'] ?? '';

    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: const Color(0xffF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: iconUrl.isNotEmpty
            ? Image.network(
                iconUrl,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset(
                    'assets/img/about-moi-logo.png',
                    fit: BoxFit.contain,
                  );
                },
              )
            : Image.asset(
                iconPath,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset(
                    'assets/img/about-moi-logo.png',
                    fit: BoxFit.contain,
                  );
                },
              ),
      ),
    );
  }

  Widget _buildQuickAccessSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.bolt_outlined, color: Color(0xff8A6514), size: 18),
            const SizedBox(width: 8),
            Text(
              "ចូលប្រើប្រាស់រហ័ស",
              style: GoogleFonts.kantumruyPro(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: const Color(0xff0F172A),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.5,
          children: [
            _buildQuickAccessBtn(
              "បន្ថែមកម្មវិធី",
              Icons.add_to_photos_rounded,
              const Color(0xff2563EB),
              () => Get.to(
                () => const AdminAppsListView(),
              ), // Navigates to Apps List
            ),
            _buildQuickAccessBtn(
              "អ្នកប្រើប្រាស់",
              Icons.person_search_rounded,
              const Color(0xff10B981),
              () => controller.changeTab(2), // Navigates to Users Tab
            ),
            _buildQuickAccessBtn(
              "តួនាទី និងសិទ្ធិ",
              Icons.verified_user_rounded,
              const Color(0xff7C3AED),
              () => Get.to(() => const SuperAdminRoleListView()),
            ),
            _buildQuickAccessBtn(
              "បន្ថែមសេចក្តីប្រកាស",
              Icons.add_comment_rounded,
              const Color(0xffD97706),
              () => Get.toNamed(AppRoutes.announcement, arguments: 'admin'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickAccessBtn(
    String label,
    IconData icon,
    Color iconColor,
    VoidCallback onTap,
  ) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: iconColor,
        elevation: 0,
        side: const BorderSide(color: Color(0xffE2E8F0)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
      onPressed: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            textAlign: TextAlign.center,
            style: GoogleFonts.kantumruyPro(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: const Color(0xff1E293B),
            ),
          ),
        ],
      ),
    );
  }

  /// ==========================================
  /// 2. APPS LIST TAB VIEW
  /// ==========================================
  /// ==========================================
  /// 3. USERS LIST TAB VIEW
  /// ==========================================
  Widget _buildUsersTab(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        title: Text(
          "អ្នកប្រើប្រាស់ប្រព័ន្ធ",
          style: GoogleFonts.kantumruyPro(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: const Color(0xff0F172A),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.person_add_alt_1_rounded,
              color: Color(0xff8A6514),
              size: 22,
            ),
            onPressed: () => _showAddUserSheet(context),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Obx(() {
        final list = controller.filteredUsers;
        final total = controller.usersList.length;
        final active = controller.usersList
            .where(
              (u) =>
                  (u['status'] ?? 'ACTIVE').toString().toUpperCase() ==
                  'ACTIVE',
            )
            .length;
        final suspended = total - active;
        final assigned = controller.usersList
            .where((u) => u['role'] != 'User')
            .length;

        return RefreshIndicator(
          onRefresh: controller.fetchDashboardData,
          color: const Color(0xff8A6514),
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                /// Horizontal Stats Scroll
                _buildUsersStatsScroll(total, active, suspended, assigned),

                /// Search & Dropdown Filters Section
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xffE2E8F0)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "បញ្ជីអ្នកប្រើប្រាស់",
                            style: GoogleFonts.kantumruyPro(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: const Color(0xff0F172A),
                            ),
                          ),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xffE29D11),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              minimumSize: const Size(0, 36),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            icon: const Icon(Icons.add_rounded, size: 16),
                            label: Text(
                              "កំណត់អ្នកប្រើទៅក្រុម",
                              style: GoogleFonts.kantumruyPro(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            onPressed: () => Get.to(() => SuperAdminEditUserGroupsView(
                              user: controller.usersList.isNotEmpty ? controller.usersList[0] : {},
                            )),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      // Search Bar
                      TextField(
                        onChanged: (val) =>
                            controller.userSearchQuery.value = val,
                        decoration: InputDecoration(
                          hintText: "ស្វែងរកតាមឈ្មោះ អ៊ីមែល ឬគណនី...",
                          hintStyle: GoogleFonts.kantumruyPro(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                          prefixIcon: const Icon(
                            Icons.search_rounded,
                            color: Colors.grey,
                            size: 18,
                          ),
                          filled: true,
                          fillColor: const Color(0xffF8FAFC),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(
                              color: Color(0xffE2E8F0),
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(
                              color: Color(0xffE2E8F0),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(
                              color: Color(0xff8A6514),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      // Two Dropdown Filters in Row
                      Row(
                        children: [
                          // Unit Filter
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xffF8FAFC),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: const Color(0xffE2E8F0),
                                ),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: controller.selectedUserUnit.value,
                                  isExpanded: true,
                                  icon: const Icon(
                                    Icons.arrow_drop_down_rounded,
                                    color: Colors.grey,
                                  ),
                                  style: GoogleFonts.kantumruyPro(
                                    fontSize: 12,
                                    color: const Color(0xff0F172A),
                                  ),
                                  items: controller.uniqueUserUnits.map((
                                    String val,
                                  ) {
                                    return DropdownMenuItem<String>(
                                      value: val,
                                      child: Text(val),
                                    );
                                  }).toList(),
                                  onChanged: (val) {
                                    if (val != null) {
                                      controller.selectedUserUnit.value = val;
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Status Filter
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xffF8FAFC),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: const Color(0xffE2E8F0),
                                ),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: controller.selectedUserStatus.value,
                                  isExpanded: true,
                                  icon: const Icon(
                                    Icons.arrow_drop_down_rounded,
                                    color: Colors.grey,
                                  ),
                                  style: GoogleFonts.kantumruyPro(
                                    fontSize: 12,
                                    color: const Color(0xff0F172A),
                                  ),
                                  items:
                                      <String>[
                                        'ស្ថានភាពទាំងអស់',
                                        'ដំណើរការ',
                                        'ផ្អាក',
                                      ].map((String val) {
                                        return DropdownMenuItem<String>(
                                          value: val,
                                          child: Text(val),
                                        );
                                      }).toList(),
                                  onChanged: (val) {
                                    if (val != null) {
                                      controller.selectedUserStatus.value = val;
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                /// Users list items
                if (list.isEmpty)
                  Container(
                    margin: const EdgeInsets.all(16),
                    padding: const EdgeInsets.symmetric(vertical: 40),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xffE2E8F0)),
                    ),
                    child: Center(
                      child: Text(
                        "មិនទាន់មានអ្នកប្រើប្រាស់ឡើយ",
                        style: GoogleFonts.kantumruyPro(color: Colors.grey),
                      ),
                    ),
                  )
                else
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: list.length,
                    itemBuilder: (context, index) {
                      return _buildUserItemCard(context, list[index], index);
                    },
                  ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        );
      }),
    );
  }

  Widget _buildUsersStatsScroll(
    int total,
    int active,
    int suspended,
    int assigned,
  ) {
    final double screenWidth = Get.width;
    final int crossAxisCount = screenWidth > 600 ? 4 : 2;
    final double childAspectRatio = screenWidth > 600
        ? 2.5
        : (screenWidth < 360 ? 1.6 : 1.9);

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: crossAxisCount,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: childAspectRatio,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      children: [
        _buildUserStatCard(
          "អ្នកប្រើប្រាស់សរុប",
          total.toString(),
          "ក្នុងអង្គភាពទាំងអស់",
          Icons.people_alt_rounded,
          const Color(0xffEFF6FF),
          const Color(0xff2563EB),
        ),
        _buildUserStatCard(
          "អ្នកប្រើដំណើរការ",
          active.toString(),
          "${total > 0 ? (active / total * 100).toStringAsFixed(0) : 0}% នៃចំនួនសរុប",
          Icons.check_circle_rounded,
          const Color(0xffECFDF5),
          const Color(0xff10B981),
        ),
        _buildUserStatCard(
          "អ្នកប្រើផ្អាក",
          suspended.toString(),
          "${total > 0 ? (suspended / total * 100).toStringAsFixed(0) : 0}% នៃចំនួនសរុប",
          Icons.pause_circle_rounded,
          const Color(0xffFEF3C7),
          const Color(0xffF59E0B),
        ),
        _buildUserStatCard(
          "បានកំណត់ក្រុម",
          assigned.toString(),
          "${total > 0 ? (assigned / total * 100).toStringAsFixed(0) : 0}% នៃចំនួនសរុប",
          Icons.verified_user_rounded,
          const Color(0xffF5F3FF),
          const Color(0xff8B5CF6),
        ),
      ],
    );
  }

  Widget _buildUserStatCard(
    String title,
    String value,
    String subtitle,
    IconData icon,
    Color bgIconColor,
    Color accentColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xffE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.01),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: bgIconColor,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: accentColor, size: 20),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: GoogleFonts.kantumruyPro(
                    color: const Color(0xff64748B),
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: GoogleFonts.poppins(
                    color: const Color(0xff0F172A),
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.kantumruyPro(
                    color: Colors.grey,
                    fontSize: 9,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserItemCard(
    BuildContext context,
    Map<String, dynamic> user,
    int index,
  ) {
    final username = user['username'] ?? 'User';
    final email = user['email'] ?? '';
    final String status = user['status'] ?? 'ACTIVE';
    final String unit = user['unit'] ?? '—';
    final initial = username.isNotEmpty
        ? username.substring(0, username.length > 2 ? 2 : 1).toUpperCase()
        : 'U';

    final bool isActive = status.toUpperCase() == 'ACTIVE';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xffE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.01),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row 1: Avatar + Name info + Actions
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: const Color(0xffEFF6FF),
                child: Text(
                  initial,
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff2563EB),
                    fontSize: 13,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      username,
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xff0F172A),
                      ),
                    ),
                    Text(
                      username,
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 11,
                        color: const Color(0xff64748B),
                      ),
                    ),
                  ],
                ),
              ),
              // Action Buttons Row (Eye, Edit, Three-dots)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.visibility_outlined,
                      size: 18,
                      color: Color(0xff64748B),
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () => _showUserDetailDialog(context, user),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    icon: const Icon(
                      Icons.edit_outlined,
                      size: 18,
                      color: Color(0xff64748B),
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () => Get.to(() => SuperAdminEditUserGroupsView(user: user)),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    icon: const Icon(
                      Icons.more_vert_rounded,
                      size: 18,
                      color: Color(0xff64748B),
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () => _showUserActionsMenu(context, user, index),
                  ),
                ],
              ),
            ],
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Divider(color: Color(0xffE2E8F0), height: 1),
          ),
          // Row 2: Unit + Email + Status
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Unit/Group
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "អង្គភាព (ក្រុម)",
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 10,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      unit,
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xff0F172A),
                      ),
                    ),
                  ],
                ),
              ),
              // Email
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "អ៊ីមែល",
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 10,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      email.isNotEmpty ? email : "-",
                      style: GoogleFonts.poppins(
                        fontSize: 11,
                        color: email.isNotEmpty
                            ? const Color(0xff334155)
                            : Colors.grey,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              // Status Badge
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: isActive
                      ? const Color(0xffECFDF5)
                      : const Color(0xffFEE2E2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isActive
                        ? const Color(0xffA7F3D0)
                        : const Color(0xffFCA5A5),
                    width: 0.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: isActive
                            ? const Color(0xff10B981)
                            : const Color(0xffEF4444),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      isActive ? "ដំណើរការ" : "ផ្អាក",
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: isActive
                            ? const Color(0xff065F46)
                            : const Color(0xff991B1B),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showUserDetailDialog(BuildContext context, Map<String, dynamic> user) {
    final username = user['username'] ?? 'User';
    final email = user['email'] ?? '';
    final role = user['role'] ?? 'User';
    final status = user['status'] ?? 'ACTIVE';
    final unit = user['unit'] ?? 'GDDTM';
    final bool isActive = status.toUpperCase() == 'ACTIVE';

    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "ព័ត៌មានអ្នកប្រើប្រាស់",
                      style: GoogleFonts.kantumruyPro(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: const Color(0xff0F172A),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _buildUserDetailRow("ឈ្មោះគណនី", username),
                _buildUserDetailRow("អ៊ីមែល", email.isNotEmpty ? email : "-"),
                _buildUserDetailRow("តួនាទី", role),
                _buildUserDetailRow("អង្គភាព (ក្រុម)", unit),
                _buildUserDetailRow(
                  "ស្ថានភាព",
                  isActive ? "កំពុងដំណើរការ (ACTIVE)" : "ផ្អាក (INACTIVE)",
                  textColor: isActive
                      ? const Color(0xff10B981)
                      : const Color(0xffEF4444),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildUserDetailRow(String label, String value, {Color? textColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: GoogleFonts.kantumruyPro(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: GoogleFonts.kantumruyPro(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: textColor ?? const Color(0xff0F172A),
            ),
          ),
          const SizedBox(height: 4),
          const Divider(color: Color(0xffE2E8F0), height: 1),
        ],
      ),
    );
  }

  void _showUserActionsMenu(
    BuildContext context,
    Map<String, dynamic> user,
    int index,
  ) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(
                  Icons.visibility_outlined,
                  color: Colors.blue,
                ),
                title: Text(
                  "មើលព័ត៌មានលម្អិត",
                  style: GoogleFonts.kantumruyPro(fontSize: 14),
                ),
                onTap: () {
                  Navigator.of(context).pop();
                  _showUserDetailDialog(context, user);
                },
              ),
              ListTile(
                leading: const Icon(Icons.edit_outlined, color: Colors.orange),
                title: Text(
                  "កែប្រែគណនី",
                  style: GoogleFonts.kantumruyPro(fontSize: 14),
                ),
                onTap: () {
                  Navigator.of(context).pop();
                  Get.to(() => SuperAdminEditUserGroupsView(user: user));
                },
              ),
              ListTile(
                leading: const Icon(
                  Icons.delete_outline_rounded,
                  color: Colors.red,
                ),
                title: Text(
                  "លុបគណនី",
                  style: GoogleFonts.kantumruyPro(fontSize: 14),
                ),
                onTap: () {
                  Navigator.of(context).pop();
                  _confirmDeleteUser(context, index);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _confirmDeleteUser(BuildContext context, int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            "លុបគណនី",
            style: GoogleFonts.kantumruyPro(fontWeight: FontWeight.bold),
          ),
          content: Text(
            "តើអ្នកប្រាកដជាចង់លុបគណនីអ្នកប្រើប្រាស់នេះមែនទេ?",
            style: GoogleFonts.kantumruyPro(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                "បោះបង់",
                style: GoogleFonts.kantumruyPro(color: Colors.grey),
              ),
            ),
            TextButton(
              onPressed: () {
                controller.deleteUser(index);
                Navigator.of(context).pop();
              },
              child: Text(
                "លុប",
                style: GoogleFonts.kantumruyPro(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  /// ==========================================
  /// 4. DEDICATED ADMIN SETTINGS (setting_admin)
  /// ==========================================
  Widget _buildAdminSettingsTab(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        title: Text(
          "ការកំណត់ Admin",
          style: GoogleFonts.kantumruyPro(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: const Color(0xff0F172A),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Admin Profile Welcomer Header
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xffF1F5F9)),
              ),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundColor: Color(0xffF6EBC2),
                    child: Icon(
                      Icons.admin_panel_settings_rounded,
                      color: Color(0xff8A6514),
                      size: 36,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "admin admin",
                          style: GoogleFonts.kantumruyPro(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xff0F172A),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xffFEF3C7),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            "ADMIN",
                            style: GoogleFonts.poppins(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xffD97706),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            /// Category 1: System Management
            Text(
              "ប្រព័ន្ធគ្រប់គ្រង",
              style: GoogleFonts.kantumruyPro(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: const Color(0xff64748B),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xffF1F5F9)),
              ),
              child: Column(
                children: [
                  _buildSettingTile(
                    icon: Icons.home_rounded,
                    title: "ទៅកាន់ទំព័រដើម (Client Home)",
                    iconColor: const Color(0xff8A6514),
                    onTap: () {
                      Get.offAllNamed(AppRoutes.mainPage);
                    },
                  ),
                  const Divider(height: 1, color: Color(0xffF1F5F9)),
                  _buildSettingTile(
                    icon: Icons.backup_rounded,
                    title: "បម្រុងទុកទិន្នន័យ (Backup)",
                    iconColor: const Color(0xff2563EB),
                    onTap: () => controller.backupDatabase(),
                  ),
                  const Divider(height: 1, color: Color(0xffF1F5F9)),
                  _buildSettingTile(
                    icon: Icons.cleaning_services_rounded,
                    title: "សម្អាត Cache ប្រព័ន្ធ",
                    iconColor: const Color(0xff10B981),
                    onTap: () => controller.clearSystemCache(),
                  ),
                  const Divider(height: 1, color: Color(0xffF1F5F9)),
                  _buildSettingTile(
                    icon: Icons.api_rounded,
                    title: "ឯកសារបច្ចេកទេស API (Docs)",
                    iconColor: const Color(0xff7C3AED),
                    onTap: () => controller.openApiDocs(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            /// Category 2: Security & Account
            Text(
              "គណនី និងសន្តិសុខ",
              style: GoogleFonts.kantumruyPro(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: const Color(0xff64748B),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xffF1F5F9)),
              ),
              child: Column(
                children: [
                  _buildSettingTile(
                    icon: Icons.lock_rounded,
                    title: "ផ្លាស់ប្តូរពាក្យសម្ងាត់",
                    iconColor: const Color(0xffD97706),
                    onTap: () {
                      // Navigate to change password helper
                    },
                  ),
                  const Divider(height: 1, color: Color(0xffF1F5F9)),
                  _buildSettingTile(
                    icon: Icons.logout_rounded,
                    title: "ចាកចេញពីគណនី",
                    iconColor: const Color(0xffEF4444),
                    textColor: const Color(0xffEF4444),
                    onTap: () => _confirmLogout(context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingTile({
    required IconData icon,
    required String title,
    required Color iconColor,
    required VoidCallback onTap,
    Color textColor = const Color(0xff1E293B),
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: GoogleFonts.kantumruyPro(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: textColor,
                ),
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              color: Colors.grey[400],
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBackupOverlay() {
    return Container(
      color: Colors.black.withOpacity(0.6),
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Container(
          width: 280,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xff8A6514)),
              ),
              const SizedBox(height: 24),
              Text(
                "កំពុងបម្រុងទុកទិន្នន័យ...",
                style: GoogleFonts.kantumruyPro(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: const Color(0xff1E293B),
                ),
              ),
              const SizedBox(height: 12),
              LinearProgressIndicator(
                value: controller.backupProgress.value,
                backgroundColor: const Color(0xffE2E8F0),
                valueColor: const AlwaysStoppedAnimation<Color>(
                  Color(0xff8A6514),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "${(controller.backupProgress.value * 100).toInt()}%",
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff8A6514),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddUserSheet(BuildContext context) {
    final nameCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    String selectedRole = 'User';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 20,
            right: 20,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "បង្កើតគណនីអ្នកប្រើប្រាស់ថ្មី",
                style: GoogleFonts.kantumruyPro(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff1E293B),
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: nameCtrl,
                decoration: InputDecoration(
                  labelText: "ឈ្មោះអ្នកប្រើប្រាស់",
                  labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: "អ៊ីមែល",
                  labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedRole,
                decoration: InputDecoration(
                  labelText: "តួនាទី",
                  labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                items: ['User', 'Moderator', 'Admin']
                    .map(
                      (role) =>
                          DropdownMenuItem(value: role, child: Text(role)),
                    )
                    .toList(),
                onChanged: (val) {
                  if (val != null) selectedRole = val;
                },
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xff8A6514),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: () {
                    final name = nameCtrl.text.trim();
                    final email = emailCtrl.text.trim();
                    if (name.isEmpty || email.isEmpty) {
                      CustomSnackbar.showError(
                        message: 'សូមបំពេញព័ត៌មានអោយបានគ្រប់គ្រាន់',
                      );
                      return;
                    }
                    controller.addNewUser(name, email, selectedRole);
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    "បង្កើតគណនី",
                    style: GoogleFonts.kantumruyPro(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  void _confirmLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'ចាកចេញពីគណនី',
          style: GoogleFonts.kantumruyPro(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'តើអ្នកពិតជាចង់ចាកចេញពីគណនី Admin នេះមែនទេ?',
          style: GoogleFonts.kantumruyPro(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'បោះបង់',
              style: GoogleFonts.kantumruyPro(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xff8A6514),
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              Navigator.of(context).pop();
              controller.logout();
            },
            child: Text('ចាកចេញ', style: GoogleFonts.kantumruyPro()),
          ),
        ],
      ),
    );
  }
}

class AdminAppsListView extends GetView<AdminController> {
  const AdminAppsListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Navigator.canPop(context)
            ? IconButton(
                icon: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: Color(0xff8A6514),
                ),
                onPressed: () => Navigator.of(context).pop(),
              )
            : null,
        title: Text(
          "កម្មវិធីប្រើប្រាស់",
          style: GoogleFonts.kantumruyPro(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: const Color(0xff0F172A),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.add_rounded,
              color: Color(0xff8A6514),
              size: 24,
            ),
            onPressed: () => Get.to(() => const AdminAppCreateView()),
          ),
        ],
      ),
      body: Obx(() {
        final list = controller.filteredApps;

        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildAppsStatsRow(controller),

              /// Search Bar and Filters Row
              Container(
                color: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        // Search Input
                        Expanded(
                          child: TextField(
                            onChanged: (val) =>
                                controller.appSearchQuery.value = val,
                            decoration: InputDecoration(
                              hintText: "ស្វែងរកកម្មវិធី...",
                              hintStyle: GoogleFonts.kantumruyPro(
                                fontSize: 13,
                                color: Colors.grey,
                              ),
                              prefixIcon: const Icon(
                                Icons.search_rounded,
                                color: Colors.grey,
                                size: 20,
                              ),
                              filled: true,
                              fillColor: const Color(0xffF1F5F9),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        // Status Filter Dropdown
                        Obx(() {
                          final currentStatus =
                              controller.appStatusFilter.value;
                          String statusLabel = "ស្ថានភាពទាំងអស់";
                          if (currentStatus == 'active') {
                            statusLabel = "កំពុងដំណើរការ";
                          } else if (currentStatus == 'inactive') {
                            statusLabel = "មិនដំណើរការ";
                          }

                          return Theme(
                            data: Theme.of(context).copyWith(
                              hoverColor: Colors.transparent,
                              splashColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                            ),
                            child: PopupMenuButton<String>(
                              onSelected: (value) =>
                                  controller.appStatusFilter.value = value,
                              itemBuilder: (context) => [
                                PopupMenuItem(
                                  value: 'all',
                                  child: Text(
                                    "ស្ថានភាពទាំងអស់",
                                    style: GoogleFonts.kantumruyPro(
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                                PopupMenuItem(
                                  value: 'active',
                                  child: Text(
                                    "កំពុងដំណើរការ",
                                    style: GoogleFonts.kantumruyPro(
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                                PopupMenuItem(
                                  value: 'inactive',
                                  child: Text(
                                    "មិនដំណើរការ",
                                    style: GoogleFonts.kantumruyPro(
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ],
                              child: Container(
                                height: 38,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xffEFF6FF),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: const Color(0xff3B82F6),
                                    width: 1,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(
                                      Icons.filter_alt_outlined,
                                      size: 16,
                                      color: Color(0xff2563EB),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      statusLabel,
                                      style: GoogleFonts.kantumruyPro(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: const Color(0xff2563EB),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                    const SizedBox(height: 12),
                    // List Title & Sorting Row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "បញ្ជីកម្មវិធី",
                          style: GoogleFonts.kantumruyPro(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xff1E293B),
                          ),
                        ),
                        Obx(() {
                          final currentSort = controller.appSortFilter.value;
                          String sortLabel = "ថ្មីបំផុត";
                          if (currentSort == 'name_az') {
                            sortLabel = "ឈ្មោះ: ក-អ";
                          } else if (currentSort == 'name_za') {
                            sortLabel = "ឈ្មោះ: អ-ក";
                          } else if (currentSort == 'oldest') {
                            sortLabel = "ចាស់បំផុត";
                          }

                          return PopupMenuButton<String>(
                            onSelected: (value) =>
                                controller.appSortFilter.value = value,
                            itemBuilder: (context) => [
                              PopupMenuItem(
                                value: 'name_az',
                                child: Text(
                                  "ឈ្មោះ: ក-អ",
                                  style: GoogleFonts.kantumruyPro(fontSize: 13),
                                ),
                              ),
                              PopupMenuItem(
                                value: 'name_za',
                                child: Text(
                                  "ឈ្មោះ: អ-ក",
                                  style: GoogleFonts.kantumruyPro(fontSize: 13),
                                ),
                              ),
                              PopupMenuItem(
                                value: 'newest',
                                child: Text(
                                  "ថ្មីបំផុត",
                                  style: GoogleFonts.kantumruyPro(fontSize: 13),
                                ),
                              ),
                              PopupMenuItem(
                                value: 'oldest',
                                child: Text(
                                  "ចាស់បំផុត",
                                  style: GoogleFonts.kantumruyPro(fontSize: 13),
                                ),
                              ),
                            ],
                            child: Container(
                              height: 32,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xffF8FAFC),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: const Color(0xffE2E8F0),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    sortLabel,
                                    style: GoogleFonts.kantumruyPro(
                                      fontSize: 11,
                                      color: const Color(0xff475569),
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  const Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    size: 14,
                                    color: Color(0xff475569),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  ],
                ),
              ),

              /// Card list
              list.isEmpty
                  ? SizedBox(
                      height: 200,
                      child: Center(
                        child: Text(
                          "មិនមានទិន្នន័យឡើយ",
                          style: GoogleFonts.kantumruyPro(color: Colors.grey),
                        ),
                      ),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      itemCount: list.length,
                      itemBuilder: (context, index) {
                        final app = list[index];
                        final originalIndex = controller.appsList.indexOf(app);
                        return _buildAppMobileCard(context, originalIndex, app);
                      },
                    ),
            ],
          ),
        );
      }),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xff2563EB),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onPressed: () => Get.to(() => const AdminAppCreateView()),
        child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
      ),
    );
  }

  Widget _buildAppsStatsRow(AdminController controller) {
    final list = controller.appsList;
    final total = list.length;
    final active = list.where((app) => app['isActive'] == true).length;
    final inactive = list.where((app) => app['isActive'] != true).length;
    final users = controller.totalUsers.value;

    final activePct = total > 0 ? (active / total * 100) : 0.0;
    final inactivePct = total > 0 ? (inactive / total * 100) : 0.0;

    final double screenWidth = Get.width;
    final int crossAxisCount = screenWidth > 600 ? 4 : 2;
    final double childAspectRatio = screenWidth > 600
        ? 2.5
        : (screenWidth < 360 ? 1.6 : 1.9);

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: crossAxisCount,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: childAspectRatio,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      children: [
        _buildStatCardItem(
          title: "កម្មវិធីសរុប",
          value: total.toString(),
          subtitle: "កម្មវិធីក្នុងប្រព័ន្ធ",
          icon: Icons.apps_rounded,
          iconColor: const Color(0xff2563EB),
          bgIconColor: const Color(0xffEFF6FF),
        ),
        _buildStatCardItem(
          title: "កម្មវិធីដំណើរការ",
          value: active.toString(),
          subtitle: "${activePct.toStringAsFixed(1)}% នៃចំនួនសរុប",
          icon: Icons.check_circle_rounded,
          iconColor: const Color(0xff10B981),
          bgIconColor: const Color(0xffECFDF5),
        ),
        _buildStatCardItem(
          title: "កម្មវិធីមិនដំណើរការ",
          value: inactive.toString(),
          subtitle: "${inactivePct.toStringAsFixed(1)}% នៃចំនួនសរុប",
          icon: Icons.watch_later_outlined,
          iconColor: const Color(0xffD97706),
          bgIconColor: const Color(0xffFEF3C7),
        ),
        _buildStatCardItem(
          title: "អ្នកប្រើប្រាស់សរុប",
          value: users.toString(),
          subtitle: "សិទ្ធិចូលកម្មវិធី",
          icon: Icons.people_alt_rounded,
          iconColor: const Color(0xff7C3AED),
          bgIconColor: const Color(0xffF3E8FF),
        ),
      ],
    );
  }

  Widget _buildStatCardItem({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required Color bgIconColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: bgIconColor,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: iconColor, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff64748B),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff0F172A),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 9,
                    color: const Color(0xff94A3B8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppMobileCard(
    BuildContext context,
    int originalIndex,
    Map<String, dynamic> app,
  ) {
    final titleKh = app['titleKh'] ?? 'កម្មវិធី';
    final titleEn = app['titleEn'] ?? 'App';
    final route = app['route'] ?? '';
    final bool isActive = app['isActive'] ?? true;
    final ruleType = app['ruleType'] ?? 'អគ្គនាយកដ្ឋាន';
    final ruleValue = app['ruleValue'] ?? 'GDDTM';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _showAppDetailDialog(context, app),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildAppIconAvatar(app),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              titleKh,
                              style: GoogleFonts.kantumruyPro(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xff0F172A),
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              titleEn,
                              style: GoogleFonts.poppins(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xff64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildStatusBadge(isActive),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Divider(height: 1, color: Color(0xffF1F5F9)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Icon(
                        Icons.link_rounded,
                        size: 16,
                        color: Color(0xff2563EB),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          route,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.poppins(
                            fontSize: 11,
                            color: const Color(0xff2563EB),
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(
                        Icons.security_rounded,
                        size: 16,
                        color: Color(0xff64748B),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        "ច្បាប់: $ruleType ($ruleValue)",
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 11,
                          color: const Color(0xff64748B),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      _buildMobileActionBtn(
                        icon: Icons.visibility_outlined,
                        label: "មើល",
                        color: const Color(0xff2563EB),
                        onTap: () => _showAppDetailDialog(context, app),
                      ),
                      const SizedBox(width: 8),
                      _buildMobileActionBtn(
                        icon: Icons.edit_outlined,
                        label: "កែប្រែ",
                        color: const Color(0xff475569),
                        onTap: () => Get.to(
                          () => AdminAppCreateView(
                            isEdit: true,
                            appIndex: originalIndex,
                            appData: app,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _buildMobileActionBtn(
                        icon: Icons.delete_outline_rounded,
                        label: "លុប",
                        color: const Color(0xffEF4444),
                        onTap: () =>
                            _confirmDeleteApp(context, originalIndex, titleKh),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBadge(bool isActive) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isActive ? const Color(0xffECFDF5) : const Color(0xffFEE2E2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isActive ? const Color(0xffA7F3D0) : const Color(0xffFECACA),
        ),
      ),
      child: Text(
        isActive ? "ដំណើរការ" : "ផ្អាក",
        style: GoogleFonts.kantumruyPro(
          fontSize: 9,
          fontWeight: FontWeight.bold,
          color: isActive ? const Color(0xff065F46) : const Color(0xff991B1B),
        ),
      ),
    );
  }

  Widget _buildMobileActionBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.12)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 4),
            Text(
              label,
              style: GoogleFonts.kantumruyPro(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppIconAvatar(Map<String, dynamic> app) {
    final String iconPath = app['icon'] ?? 'assets/img/about-moi-logo.png';
    final String iconUrl = app['iconUrl'] ?? '';

    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: const Color(0xffF8FAFC),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: iconUrl.isNotEmpty
            ? Image.network(
                iconUrl,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset(
                    'assets/img/about-moi-logo.png',
                    fit: BoxFit.contain,
                  );
                },
              )
            : Image.asset(
                iconPath,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset(
                    'assets/img/about-moi-logo.png',
                    fit: BoxFit.contain,
                  );
                },
              ),
      ),
    );
  }

  void _showAppDetailDialog(BuildContext context, Map<String, dynamic> app) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          app['titleKh'] ?? 'ព័ត៌មានកម្មវិធី',
          style: GoogleFonts.kantumruyPro(fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow("ឈ្មោះភាសាអង់គ្លេស", app['titleEn'] ?? ''),
            _buildDetailRow("លីង URL", app['route'] ?? ''),
            _buildDetailRow("ប្រភេទច្បាប់", app['ruleType'] ?? 'អគ្គនាយកដ្ឋាន'),
            _buildDetailRow("តម្លៃច្បាប់", app['ruleValue'] ?? 'GDDTM'),
            _buildDetailRow(
              "ស្ថានភាព",
              (app['isActive'] ?? true) ? "ដំណើរការ" : "ផ្អាក",
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xff8A6514),
              minimumSize: const Size(80, 36),
            ),
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "បិទ",
              style: GoogleFonts.kantumruyPro(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          style: GoogleFonts.kantumruyPro(color: Colors.black, fontSize: 13),
          children: [
            TextSpan(
              text: "$label: ",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: val),
          ],
        ),
      ),
    );
  }

  void _confirmDeleteApp(BuildContext context, int originalIndex, String name) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          "លុបកម្មវិធី",
          style: GoogleFonts.kantumruyPro(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'តើអ្នកពិតជាចង់លុបកម្មវិធី "$name" នេះចេញពីប្រព័ន្ធមែនទេ?',
          style: GoogleFonts.kantumruyPro(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "បោះបង់",
              style: GoogleFonts.kantumruyPro(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              minimumSize: const Size(80, 36),
            ),
            onPressed: () {
              Navigator.of(context).pop();
              controller.deleteApp(originalIndex);
            },
            child: Text(
              "លុប",
              style: GoogleFonts.kantumruyPro(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

class AdminAppCreateView extends StatefulWidget {
  final bool isEdit;
  final int? appIndex;
  final Map<String, dynamic>? appData;

  const AdminAppCreateView({
    super.key,
    this.isEdit = false,
    this.appIndex,
    this.appData,
  });

  @override
  State<AdminAppCreateView> createState() => _AdminAppCreateViewState();
}

class _AdminAppCreateViewState extends State<AdminAppCreateView> {
  final _controller = Get.find<AdminController>();
  late final TextEditingController nameKhCtrl;
  late final TextEditingController nameEnCtrl;
  late final TextEditingController urlCtrl;
  late final TextEditingController ruleTypeCtrl;
  late final TextEditingController ruleValueCtrl;
  late bool isActive;

  @override
  void initState() {
    super.initState();
    String nameKh = '';
    String nameEn = '';
    String url = '';
    String ruleType = 'អគ្គនាយកដ្ឋាន';
    String ruleValue = 'GDDTM';
    if (widget.isEdit && widget.appData != null) {
      nameKh = widget.appData!['titleKh'] ?? '';
      nameEn = widget.appData!['titleEn'] ?? '';
      url = widget.appData!['route'] ?? '';
      ruleType = widget.appData!['ruleType'] ?? 'អគ្គនាយកដ្ឋាន';
      ruleValue = widget.appData!['ruleValue'] ?? 'GDDTM';
    }
    nameKhCtrl = TextEditingController(text: nameKh);
    nameEnCtrl = TextEditingController(text: nameEn);
    urlCtrl = TextEditingController(text: url);
    ruleTypeCtrl = TextEditingController(text: ruleType);
    ruleValueCtrl = TextEditingController(text: ruleValue);
    isActive = widget.isEdit ? (widget.appData?['isActive'] ?? true) : true;
  }

  @override
  void dispose() {
    nameKhCtrl.dispose();
    nameEnCtrl.dispose();
    urlCtrl.dispose();
    ruleTypeCtrl.dispose();
    ruleValueCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Color(0xff8A6514),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          widget.isEdit
              ? "កែប្រែកម្មវិធីប្រើប្រាស់"
              : "បង្កើតកម្មវិធីប្រើប្រាស់ថ្មី",
          style: GoogleFonts.kantumruyPro(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: const Color(0xff0F172A),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Sub Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(bottom: BorderSide(color: Color(0xffE2E8F0))),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.isEdit
                        ? "កែប្រែកម្មវិធីប្រើប្រាស់"
                        : "បង្កើតកម្មវិធីប្រើប្រាស់ថ្មី",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff0F172A),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "បញ្ចូលព័ត៌មានកម្មវិធី URL រូបតំណាង និងស្ថានភាពប្រើប្រាស់",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 12,
                      color: const Color(0xff64748B),
                    ),
                  ),
                ],
              ),
            ),

            /// Input Fields form card
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildInputLabel("ឈ្មោះកម្មវិធី (ខ្មែរ) *"),
                            TextField(
                              controller: nameKhCtrl,
                              decoration: _buildInputDecoration(
                                "បញ្ចូលឈ្មោះកម្មវិធីជាភាសាខ្មែរ",
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildInputLabel("ឈ្មោះកម្មវិធី (អង់គ្លេស) *"),
                            TextField(
                              controller: nameEnCtrl,
                              decoration: _buildInputDecoration(
                                "បញ្ចូលឈ្មោះកម្មវិធីជាភាសាអង់គ្លេស",
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  _buildInputLabel("URL *"),
                  TextField(
                    controller: urlCtrl,
                    decoration: _buildInputDecoration(
                      "បញ្ចូល URL (ឧ. https://example.moi.gov.kh)",
                    ),
                  ),
                  const SizedBox(height: 16),

                  /// Access Rules
                  _buildInputLabel("ច្បាប់ចូលប្រើ *"),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildSubInputLabel("ប្រភេទច្បាប់"),
                            TextField(
                              controller: ruleTypeCtrl,
                              decoration: _buildInputDecoration(
                                "អគ្គនាយកដ្ឋាន",
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildSubInputLabel("តម្លៃច្បាប់"),
                            TextField(
                              controller: ruleValueCtrl,
                              decoration: _buildInputDecoration("ឧ. GDDTM"),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  /// Status Select Radio box style
                  _buildInputLabel("ស្ថានភាព *"),
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatusRadioCard("កំពុងដំណើរការ", true),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildStatusRadioCard("មិនដំណើរការ", false),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),

                  /// Action Buttons Save and Cancel
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: const Color(0xff475569),
                          elevation: 0,
                          side: const BorderSide(color: Color(0xffCBD5E1)),
                          minimumSize: const Size(100, 40),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 14,
                          ),
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                        child: Text(
                          "បោះបង់",
                          style: GoogleFonts.kantumruyPro(
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xff2563EB),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          minimumSize: const Size(100, 40),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 14,
                          ),
                        ),
                        onPressed: _saveForm,
                        icon: const Icon(Icons.save_rounded, size: 18),
                        label: Text(
                          "រក្សាទុក",
                          style: GoogleFonts.kantumruyPro(
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: GoogleFonts.kantumruyPro(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: const Color(0xff334155),
        ),
      ),
    );
  }

  Widget _buildSubInputLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        text,
        style: GoogleFonts.kantumruyPro(
          fontSize: 11,
          color: const Color(0xff64748B),
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: GoogleFonts.kantumruyPro(
        fontSize: 13,
        color: Colors.grey[400],
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xffE2E8F0)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xffE2E8F0)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xff2563EB), width: 1.5),
      ),
    );
  }

  Widget _buildStatusRadioCard(String label, bool value) {
    final isSelected = isActive == value;

    return GestureDetector(
      onTap: () {
        setState(() {
          isActive = value;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xffFEF3C7).withOpacity(0.3)
              : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected
                ? const Color(0xffD97706)
                : const Color(0xffE2E8F0),
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 16,
              height: 16,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSelected ? const Color(0xffD97706) : Colors.grey,
                  width: 2,
                ),
              ),
              child: isSelected
                  ? Container(
                      margin: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(
                        color: Color(0xffD97706),
                        shape: BoxShape.circle,
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: GoogleFonts.kantumruyPro(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected
                    ? const Color(0xff92400E)
                    : const Color(0xff1E293B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveForm() {
    final nameKh = nameKhCtrl.text.trim();
    final nameEn = nameEnCtrl.text.trim();
    final url = urlCtrl.text.trim();
    final ruleType = ruleTypeCtrl.text.trim();
    final ruleValue = ruleValueCtrl.text.trim();

    if (nameKh.isEmpty ||
        nameEn.isEmpty ||
        url.isEmpty ||
        ruleType.isEmpty ||
        ruleValue.isEmpty) {
      CustomSnackbar.showError(message: 'សូមបំពេញព័ត៌មានអោយបានគ្រប់គ្រាន់');
      return;
    }

    if (widget.isEdit) {
      _controller.updateApp(
        index: widget.appIndex!,
        nameKh: nameKh,
        nameEn: nameEn,
        url: url,
        ruleType: ruleType,
        ruleValue: ruleValue,
        isActive: isActive,
      );
    } else {
      _controller.addNewApp(
        nameKh: nameKh,
        nameEn: nameEn,
        url: url,
        ruleType: ruleType,
        ruleValue: ruleValue,
        isActive: isActive,
      );
    }
    Navigator.of(context).pop();
  }
}
