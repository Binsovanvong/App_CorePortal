import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:core_portal/core/api/services/auth_service.dart';
import 'package:core_portal/core/api/api_config.dart';
import 'package:core_portal/routes/page_route.dart';
import 'package:core_portal/widgets/custom_snackbar.dart';
import 'package:url_launcher/url_launcher.dart';

class AdminController extends GetxController {
  final AuthService _authService = AuthService();

  // Loading and action states
  final isLoading = false.obs;
  final isBackingUp = false.obs;
  final backupProgress = 0.0.obs;

  // Bottom Navigation State
  final currentIndex = 0.obs;
  void changeTab(int index) => currentIndex.value = index;

  // Live Dashboard Stats
  final totalApps = 0.obs;
  final totalUsers = 0.obs;
  final runningApps = 0.obs;
  final announcementsCount = 0.obs;

  // Live Data lists
  final appsList = <Map<String, dynamic>>[].obs;
  final announcementsList = <Map<String, dynamic>>[].obs;
  final usersList = <Map<String, dynamic>>[].obs;

  // Search queries
  final appSearchQuery = ''.obs;
  final userSearchQuery = ''.obs;

  // User filters
  final selectedUserStatus = "ស្ថានភាពទាំងអស់".obs;
  final selectedUserUnit = "អង្គភាពទាំងអស់".obs;

  // App filters and sorting
  final appStatusFilter = 'all'.obs; // 'all', 'active', 'inactive'
  final appSortFilter =
      'newest'.obs; // 'name_az', 'name_za', 'newest', 'oldest'

  // Computed filtered lists
  List<Map<String, dynamic>> get filteredApps {
    List<Map<String, dynamic>> result = List.from(appsList);

    // 1. Search Query
    if (appSearchQuery.value.isNotEmpty) {
      final query = appSearchQuery.value.toLowerCase();
      result = result.where((app) {
        final String kh = (app['titleKh'] ?? '').toString().toLowerCase();
        final String en = (app['titleEn'] ?? '').toString().toLowerCase();
        return kh.contains(query) || en.contains(query);
      }).toList();
    }

    // 2. Status Filter
    if (appStatusFilter.value == 'active') {
      result = result.where((app) => app['isActive'] == true).toList();
    } else if (appStatusFilter.value == 'inactive') {
      result = result.where((app) => app['isActive'] != true).toList();
    }

    // 3. Sorting
    if (appSortFilter.value == 'name_az') {
      result.sort((a, b) {
        final nameA = (a['titleKh'] ?? a['titleEn'] ?? '').toString();
        final nameB = (b['titleKh'] ?? b['titleEn'] ?? '').toString();
        return nameA.compareTo(nameB);
      });
    } else if (appSortFilter.value == 'name_za') {
      result.sort((a, b) {
        final nameA = (a['titleKh'] ?? a['titleEn'] ?? '').toString();
        final nameB = (b['titleKh'] ?? b['titleEn'] ?? '').toString();
        return nameB.compareTo(nameA);
      });
    } else if (appSortFilter.value == 'newest') {
      result.sort((a, b) {
        final idA = int.tryParse(a['id']?.toString() ?? '') ?? 0;
        final idB = int.tryParse(b['id']?.toString() ?? '') ?? 0;
        return idB.compareTo(idA);
      });
    } else if (appSortFilter.value == 'oldest') {
      result.sort((a, b) {
        final idA = int.tryParse(a['id']?.toString() ?? '') ?? 0;
        final idB = int.tryParse(b['id']?.toString() ?? '') ?? 0;
        return idA.compareTo(idB);
      });
    }

    return result;
  }

  List<Map<String, dynamic>> get filteredUsers {
    List<Map<String, dynamic>> result = List.from(usersList);

    // 1. Search Query
    if (userSearchQuery.value.isNotEmpty) {
      final query = userSearchQuery.value.toLowerCase();
      result = result.where((user) {
        final String username = (user['username'] ?? '')
            .toString()
            .toLowerCase();
        final String email = (user['email'] ?? '').toString().toLowerCase();
        return username.contains(query) || email.contains(query);
      }).toList();
    }

    // 2. Status Filter
    if (selectedUserStatus.value != "ស្ថានភាពទាំងអស់") {
      final String statusVal =
          selectedUserStatus.value == "កំពុងដំណើរការ" ||
              selectedUserStatus.value == "ដំណើរការ"
          ? "ACTIVE"
          : "INACTIVE";
      result = result.where((user) {
        final String status = (user['status'] ?? 'ACTIVE')
            .toString()
            .toUpperCase();
        return status == statusVal;
      }).toList();
    }

    // 3. Unit Filter
    if (selectedUserUnit.value != "អង្គភាពទាំងអស់") {
      final String selectedUnit = selectedUserUnit.value;
      final String prefix = selectedUnit.split(' ')[0].toUpperCase();
      result = result.where((user) {
        final String unit = (user['unit'] ?? '').toString().toUpperCase();
        return unit.isNotEmpty &&
            (unit.startsWith(prefix) || prefix.startsWith(unit));
      }).toList();
    }

    return result;
  }

  List<String> get uniqueUserUnits {
    return [
      'អង្គភាពទាំងអស់',
      'GDDTM Admins',
      'GDDTM Users',
      'GDI Admins',
      'GDI Users',
      'GDP Group',
      'GI Admins',
      'GI Users',
      'GIA Admins',
      'GIA Users',
      'GID Admins',
      'GID Users',
      'GLF Admins',
      'GLF Users',
      'GNP Admins',
      'GNP Users',
      'GS Admins',
      'GS Users',
      'LC Admins',
      'LC Users',
      'PAC Admins',
      'PAC Users',
    ];
  }

  // Audit Logs (simulated list of recent events)
  final auditLogs = <Map<String, String>>[
    {
      'title': 'ការចូលប្រើប្រាស់របស់ Admin',
      'desc': 'គណនី Admin បានចូលប្រើប្រាស់ប្រព័ន្ធពី IP: 127.0.0.1',
      'time': 'មុននេះបន្តិច',
      'status': 'info',
    },
    {
      'title': 'ប្រព័ន្ធបម្រុងទិន្នន័យ (Backup)',
      'desc': 'បានរក្សាទុកទិន្នន័យដោយជោគជ័យទៅកាន់ Cloud Server',
      'time': '10 នាទីមុន',
      'status': 'success',
    },
  ].obs;

  @override
  void onInit() {
    super.onInit();
    fetchDashboardData();
  }

  Future<void> fetchDashboardData() async {
    try {
      isLoading.value = true;

      // 1. Fetch live apps
      try {
        final appsResponse = await _authService.fetchAdminApps();
        // Admin endpoint returns { "value": [...], "Count": N }
        List rawApps = [];
        if (appsResponse != null) {
          if (appsResponse is List) {
            rawApps = appsResponse;
          } else if (appsResponse is Map) {
            rawApps = appsResponse['value'] ?? appsResponse['data'] ?? [];
          }
        }
        if (rawApps.isNotEmpty) {
          final parsedApps = rawApps.map<Map<String, dynamic>>((app) {
            // API fields: nameKh, nameEn, appUrl, iconUrl, enabled
            final String titleKh =
                app['nameKh'] ??
                app['title_kh'] ??
                app['name_kh'] ??
                app['name'] ??
                'កម្មវិធី';
            final String titleEn =
                app['nameEn'] ??
                app['title_en'] ??
                app['name_en'] ??
                app['name'] ??
                'App';
            final String route =
                app['appUrl'] ??
                app['route'] ??
                app['path'] ??
                app['url'] ??
                '/';
            final bool isActive =
                app['enabled'] ?? app['active'] ?? app['is_active'] ?? true;
            final String icon =
                app['iconUrl'] ?? app['icon'] ?? app['logo'] ?? '';
            final String code = app['code'] ?? '';
            final List accessRules = app['accessRules'] ?? [];
            final String ruleTypeRaw = accessRules.isNotEmpty
                ? (accessRules[0]['ruleType'] ?? '')
                : '';
            final String ruleType = _mapRuleTypeToKhmer(ruleTypeRaw);
            final String ruleValue = accessRules.isNotEmpty
                ? (accessRules[0]['ruleValue'] ?? '')
                : '';

            String iconPath = 'assets/img/about-moi-logo.png';
            String iconUrl = '';

            if (icon.isNotEmpty) {
              if (icon.startsWith('assets/')) {
                iconPath = icon;
              } else if (icon.startsWith('http')) {
                iconUrl = icon;
              } else {
                final box = GetStorage();
                final String? token = box.read('token');

                String cleanedIcon = icon;
                if (cleanedIcon.startsWith('/uploads/')) {
                  cleanedIcon = cleanedIcon.substring(9);
                } else if (cleanedIcon.startsWith('uploads/')) {
                  cleanedIcon = cleanedIcon.substring(8);
                }

                final separator = cleanedIcon.startsWith('/') ? '' : '/';
                iconUrl =
                    '${ApiConfig.baseUrl}/api/mobile/portals/uploads$separator$cleanedIcon?token=$token';
              }
            }

            return {
              'titleKh': titleKh,
              'titleEn': titleEn,
              'route': route,
              'isActive': isActive,
              'icon': iconPath,
              'iconUrl': iconUrl,
              'code': code,
              'ruleType': ruleType,
              'ruleValue': ruleValue,
            };
          }).toList();

          appsList.assignAll(parsedApps);
          totalApps.value = parsedApps.length;
          runningApps.value = parsedApps
              .where((app) => app['isActive'] == true)
              .length;
        }
      } catch (e) {
        debugPrint("Failed to load apps dashboard: $e");
      }

      // 2. Fetch announcements
      try {
        final annResponse = await _authService.fetchAdminAnnouncements();
        List rawAnnouncements = [];
        if (annResponse != null) {
          if (annResponse is List) {
            rawAnnouncements = annResponse;
          } else if (annResponse is Map) {
            rawAnnouncements =
                annResponse['value'] ?? annResponse['data'] ?? [];
          }
        }

        final parsedAnnouncements = rawAnnouncements.map<Map<String, dynamic>>((
          item,
        ) {
          final String title =
              item['title'] ??
              item['titleKh'] ??
              item['title_kh'] ??
              'សេចក្តីប្រកាស';
          final String date =
              item['created_at'] ?? item['createdAt'] ?? item['date'] ?? '';
          final String description =
              item['content'] ?? item['description'] ?? '';

          return {'title': title, 'date': date, 'description': description};
        }).toList();

        // Sort by date descending
        parsedAnnouncements.sort((a, b) {
          final DateTime? dtA = DateTime.tryParse(a['date'] ?? '');
          final DateTime? dtB = DateTime.tryParse(b['date'] ?? '');
          if (dtA == null && dtB == null) return 0;
          if (dtA == null) return 1;
          if (dtB == null) return -1;
          return dtB.compareTo(dtA);
        });

        announcementsList.assignAll(parsedAnnouncements);
        announcementsCount.value = parsedAnnouncements.length;
      } catch (e) {
        debugPrint("Failed to load announcements dashboard: $e");
      }

      // 3. Query local users endpoint
      try {
        final box = GetStorage();
        final String? token = box.read('token');
        final usersResponse = await _authService.apiService.get(
          endpoint: '/api/mobile/gateway/user-profile/users',
          headers: {'authorization': 'Bearer $token'},
        );
        if (usersResponse != null) {
          List rawUsers = [];
          if (usersResponse is List) {
            rawUsers = usersResponse;
          } else if (usersResponse is Map) {
            final data =
                usersResponse['value'] ??
                usersResponse['data'] ??
                usersResponse['items'] ??
                [];
            if (data is List) {
              rawUsers = data;
            }
          }

          final parsedUsers = rawUsers.map<Map<String, dynamic>>((usr) {
            final String username =
                usr['username'] ?? usr['name'] ?? 'អ្នកប្រើប្រាស់';
            final String email = usr['email'] ?? '';
            final String role = usr['role'] ?? usr['roleName'] ?? 'User';

            // Resolve status correctly using string or boolean fields (enabled/active/status)
            String status = 'ACTIVE';
            if (usr['status'] != null) {
              status = usr['status'].toString().toUpperCase();
            } else {
              final bool isEnabled = usr['enabled'] ?? usr['active'] ?? usr['isActive'] ?? usr['is_active'] ?? true;
              status = isEnabled ? 'ACTIVE' : 'INACTIVE';
            }

            // Default unit to '—' (no unit) to match web dashboard instead of hardcoding 'GDDTM'
            String unit = '—';
            final List empInfos = usr['employmentInfos'] ?? [];
            if (empInfos.isNotEmpty) {
              unit = empInfos[0]['generalDepartmentCode'] ?? '—';
            }

            return {
              ...usr,
              'username': username,
              'email': email,
              'role': role,
              'status': status,
              'unit': unit,
            };
          }).toList();

          usersList.assignAll(parsedUsers);
          totalUsers.value = parsedUsers.length;
        }
      } catch (e) {
        debugPrint("Failed to load users dashboard: $e");
        if (totalUsers.value == 0) {
          totalUsers.value =
              7; // Mock default value to match screenshot design if api fails
        }
      }
    } catch (e) {
      debugPrint("Failed to load admin dashboard data: $e");
    } finally {
      isLoading.value = false;
    }
  }

  // Trigger simulated DB backup
  Future<void> backupDatabase() async {
    if (isBackingUp.value) return;

    isBackingUp.value = true;
    backupProgress.value = 0.0;

    for (int i = 1; i <= 10; i++) {
      await Future.delayed(const Duration(milliseconds: 200));
      backupProgress.value = i / 10.0;
    }

    isBackingUp.value = false;

    auditLogs.insert(0, {
      'title': 'ប្រព័ន្ធបម្រុងទិន្នន័យ (Backup)',
      'desc': 'ការបង្កើតប្រព័ន្ធបម្រុងទុកមូលដ្ឋានទិន្នន័យដោយដៃបានបញ្ចប់',
      'time': 'ទើបតែថ្មីៗ',
      'status': 'success',
    });

    CustomSnackbar.showSuccess(
      message: 'ការបម្រុងទុកទិន្នន័យត្រូវបានបញ្ចប់ដោយជោគជ័យ!',
    );
  }

  // Trigger simulated cache cleaning
  Future<void> clearSystemCache() async {
    isLoading.value = true;
    await Future.delayed(const Duration(seconds: 1));
    isLoading.value = false;

    auditLogs.insert(0, {
      'title': 'ការសំអាត Cache ប្រព័ន្ធ',
      'desc': 'បានសំអាត cache ឯកសារបណ្តោះអាសន្នទាំងអស់ក្នុងប្រព័ន្ធ',
      'time': 'ទើបតែថ្មីៗ',
      'status': 'success',
    });

    CustomSnackbar.showSuccess(message: 'បានសំអាត Cache របស់ប្រព័ន្ធរួចរាល់!');
  }

  // Simulate adding a user
  void addNewUser(String name, String email, String role) {
    usersList.insert(0, {
      'username': name,
      'email': email,
      'role': role,
      'status': 'ACTIVE',
      'unit': 'GDDTM',
    });
    totalUsers.value = usersList.length;

    auditLogs.insert(0, {
      'title': 'បង្កើតគណនីថ្មី',
      'desc': 'បានបង្កើតគណនីថ្មី: $name ($role) - $email',
      'time': 'ទើបតែថ្មីៗ',
      'status': 'success',
    });

    CustomSnackbar.showSuccess(
      message: 'បានបង្កើតគណនីអ្នកប្រើប្រាស់ថ្មីដោយជោគជ័យ!',
    );
  }

  void updateUser(
    int index,
    String name,
    String email,
    String role,
    String status,
    String unit,
  ) {
    if (index >= 0 && index < usersList.length) {
      usersList[index] = {
        'username': name,
        'email': email,
        'role': role,
        'status': status,
        'unit': unit,
      };

      auditLogs.insert(0, {
        'title': 'កែប្រែគណនី',
        'desc': 'បានកែប្រែព័ត៌មានគណនី: $name',
        'time': 'ទើបតែថ្មីៗ',
        'status': 'info',
      });

      CustomSnackbar.showSuccess(
        message: 'បានកែប្រែព័ត៌មានអ្នកប្រើប្រាស់ដោយជោគជ័យ!',
      );
    }
  }

  void deleteUser(int index) {
    if (index >= 0 && index < usersList.length) {
      final name = usersList[index]['username'] ?? 'អ្នកប្រើប្រាស់';
      usersList.removeAt(index);
      totalUsers.value = usersList.length;

      auditLogs.insert(0, {
        'title': 'លុបគណនី',
        'desc': 'បានលុបគណនីអ្នកប្រើប្រាស់: $name',
        'time': 'ទើបតែថ្មីៗ',
        'status': 'warning',
      });

      CustomSnackbar.showSuccess(message: 'បានលុបគណនីអ្នកប្រើប្រាស់រួចរាល់!');
    }
  }

  // Open local API documentation in browser
  Future<void> openApiDocs() async {
    final String docsUrl;
    if (GetPlatform.isWeb) {
      docsUrl = 'http://localhost:8000/docs';
    } else if (GetPlatform.isAndroid) {
      docsUrl = 'http://10.0.2.2:8000/docs';
    } else {
      docsUrl = 'http://127.0.0.1:8000/docs';
    }

    final uri = Uri.parse(docsUrl);
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        await launchUrl(uri, mode: LaunchMode.platformDefault);
      }

      auditLogs.insert(0, {
        'title': 'បើកមើល API Docs',
        'desc': 'បានបើកមើលឯកសារបច្ចេកទេស API ($docsUrl)',
        'time': 'ទើបតែថ្មីៗ',
        'status': 'info',
      });

      CustomSnackbar.showSuccess(message: 'កំពុងបើកឯកសារ API...');
    } catch (e) {
      debugPrint("Could not launch API docs: $e");
      CustomSnackbar.showError(message: 'មិនអាចបើកឯកសារ API នេះបានទេ');
    }
  }

  // Logout Admin session
  Future<void> logout() async {
    try {
      final box = GetStorage();
      await box.remove('token');
      await box.remove('isAdmin');

      CustomSnackbar.showSuccess(message: 'ចាកចេញពីប្រព័ន្ធទទួលបានជោគជ័យ');
      Get.offAllNamed(AppRoutes.login);
    } catch (e) {
      debugPrint("Admin logout error: $e");
      Get.offAllNamed(AppRoutes.login);
    }
  }

  void addNewApp({
    required String nameKh,
    required String nameEn,
    required String url,
    required String ruleType,
    required String ruleValue,
    required bool isActive,
  }) {
    final Map<String, dynamic> newApp = {
      'titleKh': nameKh,
      'titleEn': nameEn,
      'route': url,
      'isActive': isActive,
      'icon': 'assets/img/about-moi-logo.png',
      'iconUrl': '',
      'ruleType': ruleType,
      'ruleValue': ruleValue,
    };
    appsList.insert(0, newApp);
    totalApps.value = appsList.length;
    runningApps.value = appsList.where((app) => app['isActive'] == true).length;

    // Add audit log entry
    auditLogs.insert(0, {
      'title': 'បានបង្កើតកម្មវិធីថ្មី',
      'desc': 'កម្មវិធី "$nameKh" ត្រូវបានបង្កើតឡើងដោយជោគជ័យ',
      'time': 'មុននេះបន្តិច',
      'status': 'success',
    });

    CustomSnackbar.showSuccess(message: 'បង្កើតកម្មវិធីទទួលបានជោគជ័យ');
  }

  void updateApp({
    required int index,
    required String nameKh,
    required String nameEn,
    required String url,
    required String ruleType,
    required String ruleValue,
    required bool isActive,
  }) {
    if (index >= 0 && index < appsList.length) {
      appsList[index] = {
        ...appsList[index],
        'titleKh': nameKh,
        'titleEn': nameEn,
        'route': url,
        'isActive': isActive,
        'ruleType': ruleType,
        'ruleValue': ruleValue,
      };
      runningApps.value = appsList
          .where((app) => app['isActive'] == true)
          .length;
      appsList.refresh();

      CustomSnackbar.showSuccess(message: 'កែប្រែកម្មវិធីទទួលបានជោគជ័យ');
    }
  }

  void deleteApp(int index) {
    if (index >= 0 && index < appsList.length) {
      final name = appsList[index]['titleKh'] ?? 'កម្មវិធី';
      appsList.removeAt(index);
      totalApps.value = appsList.length;
      runningApps.value = appsList
          .where((app) => app['isActive'] == true)
          .length;

      // Add audit log entry
      auditLogs.insert(0, {
        'title': 'បានលុបកម្មវិធី',
        'desc': 'កម្មវិធី "$name" ត្រូវបានលុបចេញពីប្រព័ន្ធ',
        'time': 'មុននេះបន្តិច',
        'status': 'warning',
      });

      CustomSnackbar.showSuccess(message: 'លុបកម្មវិធីទទួលបានជោគជ័យ');
    }
  }

  String _mapRuleTypeToKhmer(String english) {
    switch (english.toUpperCase()) {
      case 'GENERAL_DEPARTMENT':
        return 'អគ្គនាយកដ្ឋាន';
      case 'DEPARTMENT':
        return 'នាយកដ្ឋាន';
      case 'BUREAU':
        return 'ការិយាល័យ';
      case 'POSITION':
        return 'មុខតំណែង';
      case 'ROLE':
        return 'តួនាទី';
      case 'GROUP':
        return 'ក្រុម';
      case 'USER':
        return 'អ្នកប្រើប្រាស់';
      case 'DENY_GROUP':
        return 'បដិសេធក្រុម';
      case 'DENY_USER':
        return 'បដិសេធអ្នកប្រើប្រាស់';
      default:
        return english;
    }
  }

  Future<void> assignGroupsToUser(String userIdOrUsername, List<String> groups) async {
    try {
      isLoading.value = true;
      await _authService.assignUserGroups(userIdOrUsername, groups);
      await fetchDashboardData();
    } catch (e) {
      debugPrint("Failed to assign groups to user: $e");
    } finally {
      isLoading.value = false;
    }
  }
}
