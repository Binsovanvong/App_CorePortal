part of 'setting_view.dart';

class SettingViewController extends GetxController {
  final AuthService _authService = AuthService();

  final userName = "Loading...".obs;
  final username = "".obs;
  final userPhoto = "".obs;
  final isLoading = false.obs;

  // Real-time grid metrics split between Institution, Department, and Status
  final userInstitution = "—".obs;
  final userDepartment = "—".obs;
  final employmentStatus = "—".obs;

  final allUsersList = <Map<String, dynamic>>[].obs;

  bool _isAdmin = false;

  @override
  void onInit() {
    super.onInit();
    loadCompleteProfileDashboard();
  }

  Future<void> loadCompleteProfileDashboard() async {
    try {
      isLoading.value = true;

      // Step 1: Download basic profile mapping safely (This gets your Khmer names!)
      await getProfileData();

      // Step 2: Fetch extra details like Employment Status
      if (_isAdmin) {
        await fetchAllBackendUsers();
      } else {
        await fetchNormalUserEmploymentData();
      }
    } catch (e) {
      debugPrint("Error loading profile layout: $e");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> getProfileData() async {
    try {
      final data = await _authService.fetchProfile();

      if (data != null && data is Map) {
        userName.value =
            data['displayName'] ?? data['display_name'] ?? "No Name";
        username.value = data['username'] ?? "";

        // 🟢 FIX: Read the populated Khmer names directly from the profile response
        if (data['generalDepartmentNameKh'] != null &&
            data['generalDepartmentNameKh'].toString().isNotEmpty) {
          userInstitution.value = data['generalDepartmentNameKh'];
        } else if (data['generalDepartmentName'] != null &&
            data['generalDepartmentName'].toString().isNotEmpty) {
          userInstitution.value = data['generalDepartmentName'];
        }

        if (data['departmentNameKh'] != null &&
            data['departmentNameKh'].toString().isNotEmpty) {
          userDepartment.value = data['departmentNameKh'];
        } else if (data['departmentName'] != null &&
            data['departmentName'].toString().isNotEmpty) {
          userDepartment.value = data['departmentName'];
        }

        // Verify clearance roles directly from response structure
        final List rolesList = data['roles'] ?? [];
        _isAdmin =
            rolesList.contains('ADMIN') || rolesList.contains('SUPER_ADMIN');

        final profileMap = data['profile'];
        if (profileMap != null && profileMap is Map) {
          userPhoto.value = profileMap['avatar'] ?? profileMap['photo'] ?? "";
        }
      }
    } catch (e) {
      debugPrint("Failed to load standard account info: $e");
    }
  }

  /// Fetch employment details to get the Status (Active / Suspended)
  Future<void> fetchNormalUserEmploymentData() async {
    try {
      final response = await _authService.fetchMyEmploymentInfos();

      List employmentList = [];
      if (response is List) {
        employmentList = response;
      } else if (response is Map) {
        employmentList =
            response['value'] ?? response['data'] ?? response['items'] ?? [];
      }

      if (employmentList.isNotEmpty) {
        final primaryRecord = employmentList[0];

        // 🟢 Only fallback to employment-infos values if the main profile was empty
        if (userInstitution.value == "—") {
          userInstitution.value =
              primaryRecord['generalDepartmentNameKh'] ??
              primaryRecord['generalDepartmentName'] ??
              "—";
        }

        if (userDepartment.value == "—") {
          userDepartment.value =
              primaryRecord['departmentNameKh'] ??
              primaryRecord['departmentName'] ??
              "—";
        }

        // Map the API status to a clean readable Khmer label
        final rawStatus = primaryRecord['employmentStatus'] ?? "";
        if (rawStatus == "SUSPENDED") {
          employmentStatus.value = "ផ្អាកការងារបណ្តោះអាសន្ន (Suspended)";
        } else if (rawStatus == "ACTIVE") {
          employmentStatus.value = "កំពុងបម្រើការងារ (Active)";
        } else {
          employmentStatus.value = rawStatus.isNotEmpty ? rawStatus : "—";
        }
      } else {
        employmentStatus.value = "—";
      }
    } catch (e) {
      debugPrint(
        "Gracefully intercepted employment API crash. Displaying default '-' indicators.",
      );
      employmentStatus.value = "—";
    }
  }

  Future<void> fetchAllBackendUsers() async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');

      final response = await _authService.apiService.get(
        endpoint: '/api/mobile/gateway/user-profile/users',
        headers: {'authorization': 'Bearer $token'},
      );

      if (response != null) {
        List rawUsers = [];
        if (response is List) {
          rawUsers = response;
        } else if (response is Map) {
          final data =
              response['value'] ?? response['data'] ?? response['items'] ?? [];
          if (data is List) rawUsers = data;
        }

        final parsedUsers = rawUsers.map<Map<String, dynamic>>((usr) {
          final hasEmployment =
              usr['employmentInfos'] != null &&
              (usr['employmentInfos'] as List).isNotEmpty;
          final emp = hasEmployment ? usr['employmentInfos'][0] : null;

          return {
            'username': usr['username'] ?? '',
            'institutionName': emp != null
                ? (emp['generalDepartmentNameKh'] ??
                      emp['generalDepartmentName'] ??
                      '—')
                : '—',
            'departmentName': emp != null
                ? (emp['departmentNameKh'] ?? emp['departmentName'] ?? '—')
                : '—',
          };
        }).toList();

        allUsersList.assignAll(parsedUsers);

        final currentUserRecord = parsedUsers.firstWhere(
          (u) => u['username'] == username.value,
          orElse: () => {},
        );

        if (currentUserRecord.isNotEmpty) {
          userInstitution.value = currentUserRecord['institutionName'];
          userDepartment.value = currentUserRecord['departmentName'];
        }
      }
    } catch (e) {
      debugPrint("Admin directory fetch error: $e");
    }
  }

  final currentPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final isUpdatingPassword = false.obs;

  void changePassword() {
    currentPasswordController.clear();
    newPasswordController.clear();
    confirmPasswordController.clear();
    isUpdatingPassword.value = false;

    final obscureCurrent = true.obs;
    final obscureNew = true.obs;
    final obscureConfirm = true.obs;

    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "ប្តូរលេខសម្ងាត់",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF0F172A),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Get.back(),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                "ការផ្លាស់ប្តូរលេខសម្ងាត់",
                style: GoogleFonts.kantumruyPro(
                  fontSize: 13,
                  color: Colors.grey.shade500,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 24),
              Obx(
                () => TextField(
                  controller: currentPasswordController,
                  obscureText: obscureCurrent.value,
                  style: GoogleFonts.poppins(fontSize: 14),
                  decoration: InputDecoration(
                    labelText: "លេខសម្ងាត់បច្ចុប្បន្ន",
                    labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                    hintText: "បញ្ចូលលេខសម្ងាត់បច្ចុប្បន្ន",
                    hintStyle: GoogleFonts.kantumruyPro(fontSize: 12),
                    prefixIcon: const Icon(
                      Icons.lock_outline_rounded,
                      color: Color(0xFFB08940),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        obscureCurrent.value
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: Colors.grey,
                      ),
                      onPressed: obscureCurrent.toggle,
                    ),
                    filled: true,
                    fillColor: const Color(0xFFF8FAFC),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Obx(
                () => TextField(
                  controller: newPasswordController,
                  obscureText: obscureNew.value,
                  style: GoogleFonts.poppins(fontSize: 14),
                  decoration: InputDecoration(
                    labelText: "លេខសម្ងាត់ថ្មី",
                    labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                    hintText: "បញ្ចូលលេខសម្ងាត់ថ្មី",
                    hintStyle: GoogleFonts.kantumruyPro(fontSize: 12),
                    prefixIcon: const Icon(
                      Icons.lock_outline_rounded,
                      color: Color(0xFFB08940),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        obscureNew.value
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: Colors.grey,
                      ),
                      onPressed: obscureNew.toggle,
                    ),
                    filled: true,
                    fillColor: const Color(0xFFF8FAFC),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Obx(
                () => TextField(
                  controller: confirmPasswordController,
                  obscureText: obscureConfirm.value,
                  style: GoogleFonts.poppins(fontSize: 14),
                  decoration: InputDecoration(
                    labelText: "បញ្ជាក់លេខសម្ងាត់ថ្មី",
                    labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                    hintText: "បញ្ចូលលេខសម្ងាត់ថ្មីឡើងវិញ",
                    hintStyle: GoogleFonts.kantumruyPro(fontSize: 12),
                    prefixIcon: const Icon(
                      Icons.lock_outline_rounded,
                      color: Color(0xFFB08940),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        obscureConfirm.value
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: Colors.grey,
                      ),
                      onPressed: obscureConfirm.toggle,
                    ),
                    filled: true,
                    fillColor: const Color(0xFFF8FAFC),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: Obx(
                  () => ElevatedButton(
                    onPressed: isUpdatingPassword.value
                        ? null
                        : _submitChangePassword,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFB08940),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 0,
                    ),
                    child: isUpdatingPassword.value
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2.5,
                            ),
                          )
                        : Text(
                            "ធ្វើបច្ចុប្បន្នភាពលេខសម្ងាត់",
                            style: GoogleFonts.kantumruyPro(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
      isScrollControlled: true,
    );
  }

  Future<void> _submitChangePassword() async {
    final oldPassword = currentPasswordController.text;
    final newPassword = newPasswordController.text;
    final confirmPassword = confirmPasswordController.text;

    if (oldPassword.isEmpty || newPassword.isEmpty || confirmPassword.isEmpty) {
      Get.snackbar(
        "Error",
        "Please fill in all fields",
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (newPassword != confirmPassword) {
      Get.snackbar(
        "Error",
        "New passwords do not match",
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (newPassword.length < 6) {
      Get.snackbar(
        "Error",
        "Password must be at least 6 characters long",
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    try {
      isUpdatingPassword.value = true;
      await _authService.changePasswordService(
        username: username.value,
        oldPassword: oldPassword,
        newPassword: newPassword,
      );

      Get.back();
      Get.snackbar(
        "Success",
        "Password updated successfully",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green.withOpacity(0.1),
        colorText: Colors.green.shade800,
      );
    } catch (e) {
      Get.snackbar(
        "Error",
        "Failed to update password. Please check current password.",
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isUpdatingPassword.value = false;
    }
  }

  Future<void> logout() async {
    try {
      isLoading.value = true;
      await _authService.logoutService();
    } catch (e) {
      debugPrint("Failed to logout on backend: $e");
    } finally {
      final box = GetStorage();
      box.remove('token');
      isLoading.value = false;
      Get.offAllNamed(AppRoutes.login);
    }
  }
}
