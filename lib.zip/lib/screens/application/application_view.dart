import 'package:core_portal/routes/apppage.dart';
import 'package:core_portal/routes/page_route.dart';
import 'package:core_portal/screens/home/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

part 'application_binding.dart';
part 'application_controller.dart';

class ApplicationView extends GetView<ApplicationViewController> {
  const ApplicationView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF6F6F6),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              TextField(
                controller: controller.searchController,
                decoration: InputDecoration(
                  hintText: "Search",
                  hintStyle: GoogleFonts.poppins(
                    fontSize: 15,
                    color: Colors.grey.shade400,
                  ),
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    color: Colors.grey.shade400,
                    size: 24,
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 20,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(
                      color: Colors.grey.shade100,
                      width: 1,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                "All Apps",
                style: GoogleFonts.poppins(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff1E293B),
                ),
              ),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.homeController.isLoading.value) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 40),
                      child: CircularProgressIndicator(
                        color: Color(0xff0F3C99),
                      ),
                    ),
                  );
                }

                if (controller.filteredServices.isEmpty) {
                  return Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 40),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Center(
                      child: Text(
                        "រកមិនឃើញកម្មវិធីឡើយ",
                        style: GoogleFonts.kantumruyPro(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  );
                }

                return Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: 24,
                    horizontal: 16,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.03),
                        blurRadius: 16,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: GridView.builder(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: controller.filteredServices.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 16,
                          childAspectRatio: 0.62,
                        ),
                    itemBuilder: (context, index) {
                      final item = controller.filteredServices[index];

                      final String route =
                          (item["route"] ?? item["path"] ?? '/').toString();
                      final String displayName =
                          (item["titleKh"] ??
                                  item["title_kh"] ??
                                  item["name"] ??
                                  item["titleEn"] ??
                                  '')
                              .toString();
                      final String imgUrl =
                          (item["iconUrl"] ?? item["icon_url"] ?? '')
                              .toString();
                      final String localImg =
                          (item["icon"] ?? 'assets/img/about-moi-logo.png')
                              .toString();

                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          try {
                            controller.homeController.addRecentActivity(item);

                            // 🟢 ALWAYS create a clean bundle map structure so local/webview controllers don't throw null crashes
                            final Map<String, dynamic> navigationArgs = {
                              'url': route,
                              'title': displayName,
                            };

                            if (route.startsWith('http://') ||
                                route.startsWith('https://')) {
                              Get.toNamed(
                                '/web-view',
                                arguments: navigationArgs,
                              );
                              return;
                            }

                            Get.toNamed(route, arguments: navigationArgs);
                          } catch (e) {
                            debugPrint("Navigation Error: $e");
                          }
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              width: 68,
                              height: 68,
                              decoration: BoxDecoration(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(
                                  color: const Color(0xffE2E8F0),
                                  width: 1.5,
                                ),
                              ),
                              child: Center(
                                child:
                                    imgUrl.isNotEmpty &&
                                        imgUrl.startsWith('http')
                                    ? Image.network(
                                        imgUrl,
                                        width: 44,
                                        height: 44,
                                        fit: BoxFit.contain,
                                        errorBuilder: (c, e, s) => const Icon(
                                          Icons.apps_rounded,
                                          color: Color(0xff0F3C99),
                                          size: 28,
                                        ),
                                      )
                                    : Image.asset(
                                        localImg.isNotEmpty
                                            ? localImg
                                            : 'assets/img/about-moi-logo.png',
                                        width: 44,
                                        height: 44,
                                        fit: BoxFit.contain,
                                        errorBuilder: (c, e, s) => const Icon(
                                          Icons.apps_rounded,
                                          color: Color(0xff0F3C99),
                                          size: 28,
                                        ),
                                      ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Expanded(
                              child: Text(
                                displayName,
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.kantumruyPro(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xff1E293B),
                                  height: 1.25,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
