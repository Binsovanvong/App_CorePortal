part of 'application_view.dart'; // 👈 Connects back to the parent file above. No imports allowed here!

class ApplicationViewController extends GetxController {
  // Access the parent-imported HomeController
  final HomeController homeController = Get.find<HomeController>();

  final searchController = TextEditingController();
  final rxSearchQuery = ''.obs;
  final filteredServices = <Map<String, dynamic>>[].obs;

  @override
  void onInit() {
    super.onInit();

    // បង្កើត listener សម្រាប់រាល់ពេលមានការវាយអក្សរស្វែងរក
    searchController.addListener(() {
      rxSearchQuery.value = searchController.text.trim();
    });

    // ធ្វើការ filter កម្មវិធីរាល់ពេលទិន្នន័យសេវាកម្មពី API ឬអក្សរស្វែងរកមានការប្រែប្រួល
    everAll([homeController.services, rxSearchQuery], (_) {
      _filterApps();
    });

    _filterApps();
  }

  void _filterApps() {
    if (rxSearchQuery.isEmpty) {
      filteredServices.assignAll(homeController.services);
    } else {
      final query = rxSearchQuery.value.toLowerCase();
      final filtered = homeController.services.where((app) {
        final String titleKh = (app['titleKh'] ?? '').toString().toLowerCase();
        final String titleEn = (app['titleEn'] ?? '').toString().toLowerCase();
        return titleKh.contains(query) || titleEn.contains(query);
      }).toList();
      filteredServices.assignAll(filtered);
    }
  }

  @override
  void onClose() {
    searchController.dispose();
    super.onClose();
  }
}
