import 'package:core_portal/routes/apppage.dart';
import 'package:core_portal/routes/page_route.dart';
import 'package:core_portal/screens/home/home_controller.dart';
import 'package:core_portal/controllers/nav_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF6F6F6),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTopWhiteHeader(),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "កម្មវិធីប្រើប្រាស់ថ្មីៗ",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff1E293B),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      if (Get.isRegistered<NavController>()) {
                        Get.find<NavController>().changeTab(1);
                      }
                    },
                    child: Text(
                      "មើលទាំងអស់",
                      style: GoogleFonts.kantumruyPro(
                        color: const Color(0xffD4AF37),
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _buildRecentAppsGrid(),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "សេចក្តីជូនដំណឹងថ្មីៗ",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff1E293B),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      if (Get.isRegistered<NavController>()) {
                        Get.find<NavController>().changeTab(2);
                      }
                    },
                    child: Row(
                      children: [
                        Text(
                          "មើលទាំងអស់",
                          style: GoogleFonts.kantumruyPro(
                            color: const Color(0xffD4AF37),
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 10,
                          color: Color(0xffD4AF37),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _buildNoticeSectionList(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTopWhiteHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 60, 20, 36),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xffD4AF37), width: 2)),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(36),
          bottomRight: Radius.circular(36),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Image.asset(
                    "assets/img/about-moi-logo.png",
                    height: 54,
                    errorBuilder: (c, e, s) => const Icon(
                      Icons.account_balance,
                      color: Color(0xffD4AF37),
                      size: 40,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "ក្រសួងមហាផ្ទៃ",
                        style: GoogleFonts.kantumruyPro(
                          color: const Color(0xffD4AF37),
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "Ministry of Interior",
                        style: GoogleFonts.poppins(
                          color: const Color(0xffD4AF37),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: const Color(0xffD4AF37),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xffD4AF37).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        "KH",
                        style: GoogleFonts.poppins(
                          color: const Color(0xffD4AF37),
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text(
                        "EN",
                        style: GoogleFonts.poppins(
                          color: const Color(0xff94A3B8),
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 40),
          Obx(
            () => Text(
              "សួស្តី ${controller.userDisplayName.value}!",
              style: GoogleFonts.kantumruyPro(
                color: const Color(0xffD4AF37),
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentAppsGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Obx(() {
        if (controller.recentActivities.isEmpty) {
          return Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Center(
              child: Text(
                "មិនទាន់មានប្រវត្តិប្រើប្រាស់កម្មវិធីនៅឡើយទេ",
                style: GoogleFonts.kantumruyPro(
                  color: Colors.grey,
                  fontSize: 12,
                ),
              ),
            ),
          );
        }

        final displayCount = controller.recentActivities.length > 3
            ? 4
            : controller.recentActivities.length;

        return Container(
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: GridView.builder(
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: displayCount,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 12,
              mainAxisSpacing: 16,
              childAspectRatio: 0.62,
            ),
            itemBuilder: (context, index) {
              final item = controller.recentActivities[index];

              final String route = (item["route"] ?? item["path"] ?? '/')
                  .toString();
              final String displayName =
                  (item["titleKh"] ??
                          item["title_kh"] ??
                          item["name"] ??
                          item["titleEn"] ??
                          '')
                      .toString();
              final String imgUrl = (item["iconUrl"] ?? item["icon_url"] ?? '')
                  .toString();
              final String localImg =
                  (item["icon"] ?? 'assets/img/about-moi-logo.png').toString();

              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  try {
                    controller.addRecentActivity(item);

                    // 🟢 ALWAYS send a map argument bundle so target routes don't crash looking for properties
                    final Map<String, dynamic> navigationArgs = {
                      'url': route,
                      'title': displayName,
                    };

                    if (route.startsWith('http://') ||
                        route.startsWith('https://')) {
                      Get.toNamed('/web-view', arguments: navigationArgs);
                      return;
                    }

                    Get.toNamed(route, arguments: navigationArgs);
                  } catch (e) {
                    debugPrint("Navigation Error: $e");
                  }
                },
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: 68,
                      height: 68,
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: const Color(0xffE2E8F0),
                          width: 1.5,
                        ),
                      ),
                      child: Center(
                        child: imgUrl.isNotEmpty && imgUrl.startsWith('http')
                            ? Image.network(
                                imgUrl,
                                width: 44,
                                height: 44,
                                fit: BoxFit.contain,
                                errorBuilder: (c, e, s) => const Icon(
                                  Icons.apps_rounded,
                                  color: Color(0xff0F3C99),
                                  size: 28,
                                ),
                              )
                            : Image.asset(
                                localImg.isNotEmpty
                                    ? localImg
                                    : 'assets/img/about-moi-logo.png',
                                width: 44,
                                height: 44,
                                fit: BoxFit.contain,
                                errorBuilder: (c, e, s) => const Icon(
                                  Icons.apps_rounded,
                                  color: Color(0xff0F3C99),
                                  size: 28,
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: Text(
                        displayName,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xff1E293B),
                          height: 1.25,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      }),
    );
  }

  Widget _buildNoticeSectionList() {
    return Obx(() {
      final list = controller.announcements;
      if (list.isEmpty) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            "គ្មានសេចក្តីជូនដំណឹងនៅឡើយទេ",
            style: GoogleFonts.kantumruyPro(color: Colors.grey),
          ),
        );
      }

      return ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: list.length > 3 ? 3 : list.length,
        itemBuilder: (context, index) {
          final a = list[index];
          final String title = a['title']?.toString() ?? 'សេចក្តីប្រកាស';
          final String content = a['content']?.toString() ?? '';
          final String cleanContent = content
              .replaceAll(RegExp(r'<[^>]*>|&nbsp;'), ' ')
              .replaceAll(RegExp(r'\s+'), ' ')
              .trim();

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.015),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(
                    color: Color(0xffEEEFFA),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.description_outlined,
                    color: Color(0xff0F3C99),
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.kantumruyPro(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xff1E293B),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            "18 កក្កដា\n2026",
                            textAlign: TextAlign.right,
                            style: GoogleFonts.kantumruyPro(
                              fontSize: 9,
                              color: Colors.grey.shade400,
                              height: 1.2,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        cleanContent,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 12,
                          color: const Color(0xff64748B),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: Colors.grey,
                ),
              ],
            ),
          );
        },
      );
    });
  }
}
