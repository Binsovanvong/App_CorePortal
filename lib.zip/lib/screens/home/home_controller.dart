import 'package:core_portal/core/api/api_config.dart';
import 'package:core_portal/core/api/services/auth_service.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class HomeController extends GetxController {
  final isLoading = false.obs;
  final services = <Map<String, dynamic>>[].obs;
  final recentActivities = <Map<String, dynamic>>[].obs;
  final announcements = <Map<String, dynamic>>[].obs;
  final userDisplayName = "ភ្ញៀវ".obs;

  final AuthService _authService = AuthService();
  final _storage = GetStorage();
  final String _recentKey = 'recent_apps_key';

  @override
  void onInit() {
    super.onInit();
    fetchUserProfile();
    fetchPortalApps();
    loadRecentActivities();
    fetchAnnouncements();
  }

  void loadRecentActivities() {
    try {
      final List<dynamic>? stored = _storage.read<List<dynamic>>(_recentKey);
      if (stored != null) {
        final List<Map<String, dynamic>> loadedList = stored
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        recentActivities.assignAll(loadedList);
      }
    } catch (e) {
      debugPrint("Error loading recent activities: $e");
    }
  }

  void addRecentActivity(Map<String, dynamic> app) {
    try {
      final Map<String, dynamic> appToSave = {
        'icon': (app['icon'] ?? 'assets/img/about-moi-logo.png').toString(),
        'iconUrl': (app['iconUrl'] ?? app['icon_url'] ?? '').toString(),
        'titleKh': (app['titleKh'] ?? app['title_kh'] ?? app['name'] ?? '')
            .toString(),
        'titleEn': (app['titleEn'] ?? app['title_en'] ?? '').toString(),
        'route': (app['route'] ?? app['path'] ?? '/').toString(),
      };

      recentActivities.removeWhere(
        (item) =>
            (item['titleKh'].toString() == appToSave['titleKh'].toString()) ||
            (item['route'].toString() == appToSave['route'].toString()),
      );

      recentActivities.insert(0, appToSave);

      if (recentActivities.length > 4) {
        recentActivities.removeLast();
      }

      _storage.write(_recentKey, recentActivities.toList());
    } catch (e) {
      debugPrint("Error adding recent activity: $e");
    }
  }

  void clearRecentActivities() {
    recentActivities.clear();
    _storage.remove(_recentKey);
  }

  Future<void> fetchPortalApps() async {
    try {
      isLoading.value = true;
      final response = await _authService.fetchApps();

      if (response != null && response is List) {
        final parsed = response.map<Map<String, dynamic>>((app) {
          final String titleKh =
              (app['title_kh'] ??
                      app['name_kh'] ??
                      app['titleKh'] ??
                      app['name'] ??
                      'កម្មវិធី')
                  .toString();
          final String titleEn =
              (app['title_en'] ?? app['name_en'] ?? app['titleEn'] ?? 'App')
                  .toString();
          final String icon = (app['icon'] ?? app['logo'] ?? '').toString();
          String route = (app['route'] ?? app['path'] ?? '/').toString();

          if (!route.startsWith('http://') && !route.startsWith('https://')) {
            if (route.contains('.com') ||
                route.contains('.gov.kh') ||
                route.contains('www.')) {
              route = 'https://$route';
            }
          }

          String iconPath = 'assets/img/about-moi-logo.png';
          String iconUrl = '';

          if (icon.isNotEmpty) {
            if (icon.startsWith('assets/')) {
              iconPath = icon;
            } else if (icon.startsWith('http')) {
              iconUrl = icon;
            } else {
              final String? token = _storage.read('token');
              String cleanedIcon = icon.startsWith('/')
                  ? icon.substring(1)
                  : icon;
              iconUrl =
                  '${ApiConfig.baseUrl}/api/mobile/portals/uploads/$cleanedIcon?token=$token';
            }
          }

          return {
            'icon': iconPath,
            'iconUrl': iconUrl,
            'titleKh': titleKh,
            'titleEn': titleEn,
            'route': route,
          };
        }).toList();

        services.assignAll(parsed);
      }
    } catch (e) {
      debugPrint("Failed to fetch portal apps: $e");
    } finally {
      // 🟢 FIXED: Changed 'final' typo back to 'finally' to remove syntax warning
      isLoading.value = false;
    }
  }

  void fetchUserProfile() {
    try {
      final String? name = _storage.read('user_display_name');
      if (name != null && name.isNotEmpty) {
        userDisplayName.value = name;
      } else {
        userDisplayName.value = "មន្ត្រី";
      }
    } catch (e) {
      userDisplayName.value = "មន្ត្រី";
    }
  }

  Future<void> fetchAnnouncements() async {
    try {
      final response = await _authService.fetchAnnouncements();

      if (response != null && response is List) {
        final parsed = response.map<Map<String, dynamic>>((ann) {
          final String title =
              (ann['title'] ??
                      ann['titleKh'] ??
                      ann['subject'] ??
                      'សេចក្តីប្រកាស')
                  .toString();
          final String content =
              (ann['content'] ?? ann['contentKh'] ?? ann['description'] ?? '')
                  .toString();
          final String date =
              (ann['created_at'] ??
                      ann['createdAt'] ??
                      ann['date'] ??
                      '១៨ កក្កដា ២០២៦')
                  .toString();

          return {'title': title, 'content': content, 'date': date};
        }).toList();

        announcements.assignAll(parsed);
      }
    } catch (e) {
      debugPrint("Failed to fetch announcements in HomeController: $e");
    }
  }
}
