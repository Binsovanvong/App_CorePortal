import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:core_portal/core/api/services/auth_service.dart';
import 'package:core_portal/core/api/api_config.dart';
import 'package:core_portal/routes/page_route.dart';
import 'package:core_portal/widgets/custom_snackbar.dart';
import 'package:url_launcher/url_launcher.dart';

class SuperAdminController extends GetxController {
  final AuthService _authService = AuthService();

  // Loading and action states
  final isLoading = false.obs;
  final isBackingUp = false.obs;
  final backupProgress = 0.0.obs;

  // Bottom Navigation State
  final currentIndex = 0.obs;
  void changeTab(int index) => currentIndex.value = index;

  // Live Dashboard Stats
  final totalApps = 0.obs;
  final totalUsers = 0.obs;
  final runningApps = 0.obs;
  final announcementsCount = 0.obs;

  // Live Data lists
  final appsList = <Map<String, dynamic>>[].obs;
  final announcementsList = <Map<String, dynamic>>[].obs;
  final usersList = <Map<String, dynamic>>[].obs;
  final rolesList = <Map<String, dynamic>>[].obs; // Live API Roles List

  // Search queries
  final appSearchQuery = ''.obs;
  final userSearchQuery = ''.obs;
  final roleSearchQuery = ''.obs; // Reactive Roles Search Query

  // User filters
  final selectedUserStatus = "ស្ថានភាពទាំងអស់".obs;
  final selectedUserUnit = "អង្គភាពទាំងអស់".obs;

  // App filters and sorting
  final appStatusFilter = 'all'.obs; // 'all', 'active', 'inactive'
  final appSortFilter =
      'newest'.obs; // 'name_az', 'name_za', 'newest', 'oldest'

  // Computed filtered lists
  List<Map<String, dynamic>> get filteredApps {
    List<Map<String, dynamic>> result = List.from(appsList);

    if (appSearchQuery.value.isNotEmpty) {
      final query = appSearchQuery.value.toLowerCase();
      result = result.where((app) {
        final String kh = (app['titleKh'] ?? '').toString().toLowerCase();
        final String en = (app['titleEn'] ?? '').toString().toLowerCase();
        return kh.contains(query) || en.contains(query);
      }).toList();
    }

    if (appStatusFilter.value == 'active') {
      result = result.where((app) => app['isActive'] == true).toList();
    } else if (appStatusFilter.value == 'inactive') {
      result = result.where((app) => app['isActive'] != true).toList();
    }

    if (appSortFilter.value == 'name_az') {
      result.sort((a, b) {
        final nameA = (a['titleKh'] ?? a['titleEn'] ?? '').toString();
        final nameB = (b['titleKh'] ?? b['titleEn'] ?? '').toString();
        return nameA.compareTo(nameB);
      });
    } else if (appSortFilter.value == 'name_za') {
      result.sort((a, b) {
        final nameA = (a['titleKh'] ?? a['titleEn'] ?? '').toString();
        final nameB = (b['titleKh'] ?? b['titleEn'] ?? '').toString();
        return nameB.compareTo(nameA);
      });
    } else if (appSortFilter.value == 'newest') {
      result.sort((a, b) {
        final idA = int.tryParse(a['id']?.toString() ?? '') ?? 0;
        final idB = int.tryParse(b['id']?.toString() ?? '') ?? 0;
        return idB.compareTo(idA);
      });
    } else if (appSortFilter.value == 'oldest') {
      result.sort((a, b) {
        final idA = int.tryParse(a['id']?.toString() ?? '') ?? 0;
        final idB = int.tryParse(b['id']?.toString() ?? '') ?? 0;
        return idA.compareTo(idB);
      });
    }

    return result;
  }

  List<Map<String, dynamic>> get filteredUsers {
    List<Map<String, dynamic>> result = List.from(usersList);

    if (userSearchQuery.value.isNotEmpty) {
      final query = userSearchQuery.value.toLowerCase();
      result = result.where((user) {
        final String username = (user['username'] ?? '')
            .toString()
            .toLowerCase();
        final String email = (user['email'] ?? '').toString().toLowerCase();
        return username.contains(query) || email.contains(query);
      }).toList();
    }

    if (selectedUserStatus.value != "ស្ថានភាពទាំងអស់") {
      final String statusVal =
          selectedUserStatus.value == "កំពុងដំណើរការ" ||
              selectedUserStatus.value == "ដំណើរការ"
          ? "ACTIVE"
          : "INACTIVE";
      result = result.where((user) {
        final String status = (user['status'] ?? 'ACTIVE')
            .toString()
            .toUpperCase();
        return status == statusVal;
      }).toList();
    }

    if (selectedUserUnit.value != "អង្គភាពទាំងអស់") {
      final String selectedUnit = selectedUserUnit.value;
      final String prefix = selectedUnit.split(' ')[0].toUpperCase();
      result = result.where((user) {
        final String unit = (user['unit'] ?? '').toString().toUpperCase();
        return unit.isNotEmpty &&
            (unit.startsWith(prefix) || prefix.startsWith(unit));
      }).toList();
    }

    return result;
  }

  // Filtered Roles Computed Getter Logic
  List<Map<String, dynamic>> get filteredRoles {
    List<Map<String, dynamic>> result = List.from(rolesList);
    if (roleSearchQuery.value.isNotEmpty) {
      final query = roleSearchQuery.value.toLowerCase().trim();
      result = result.where((role) {
        final String name = (role['name'] ?? '').toString().toLowerCase();
        final String code = (role['code'] ?? '').toString().toLowerCase();
        return name.contains(query) || code.contains(query);
      }).toList();
    }
    return result;
  }

  List<String> get uniqueUserUnits {
    return [
      'អង្គភាពទាំងអស់',
      'GDDTM Admins',
      'GDDTM Users',
      'GDI Admins',
      'GDI Users',
      'GDP Group',
      'GI Admins',
      'GI Users',
      'GIA Admins',
      'GIA Users',
      'GID Admins',
      'GID Users',
      'GLF Admins',
      'GLF Users',
      'GNP Admins',
      'GNP Users',
      'GS Admins',
      'GS Users',
      'LC Admins',
      'LC Users',
      'PAC Admins',
      'PAC Users',
    ];
  }

  // Audit Logs (simulated list of recent events)
  final auditLogs = <Map<String, String>>[
    {
      'title': 'ការចូលប្រើប្រាស់របស់ Admin',
      'desc': 'គណនី Admin បានចូលប្រើប្រាស់ប្រព័ន្ធពី IP: 127.0.0.1',
      'time': 'មុននេះបន្តិច',
      'status': 'info',
    },
    {
      'title': 'ប្រព័ន្ធបម្រុងទិន្នន័យ (Backup)',
      'desc': 'បានរក្សាទុកទិន្នន័យដោយជោគជ័យទៅកាន់ Cloud Server',
      'time': '10 នាទីមុន',
      'status': 'success',
    },
  ].obs;

  @override
  void onInit() {
    super.onInit();
    fetchDashboardData();
    fetchPortalGroupsData();
    fetchRolesData(); // Auto load API roles when UI starts up
  }

  Future<void> fetchRolesData() async {
    try {
      isLoading.value = true;
      final box = GetStorage();
      final String? token = box.read('token');

      // Hits your FastAPI endpoint with the correct admin router prefix path[cite: 5]
      final response = await _authService.apiService.get(
        endpoint: '/api/mobile/admin/portal-user-roles',
        headers: {'authorization': 'Bearer $token'},
      );

      debugPrint("ROLES API RESPONSE: $response");

      if (response != null) {
        List rawRoles = [];
        if (response is List) {
          rawRoles = response;
        } else if (response is Map) {
          // Checks all typical JSON response wrappers standard to your API gateway setup[cite: 5]
          rawRoles =
              response['value'] ??
              response['data'] ??
              response['items'] ??
              response['content'] ??
              [];
        }

        final parsedRoles = rawRoles.map<Map<String, dynamic>>((r) {
          // Matches field extractions to your backend parameters[cite: 5]
          final String name = r['roleName'] ?? r['name'] ?? '—';

          int getCount(dynamic val) {
            if (val == null) return 0;
            if (val is num) return val.toInt();
            if (val is List) return val.length;
            if (val is String) return int.tryParse(val) ?? 0;
            return 0;
          }

          final groupsVal =
              r['groupsCount'] ??
              r['groups_count'] ??
              r['totalGroups'] ??
              r['groups'];
          final permsVal =
              r['permissionsCount'] ??
              r['permissions_count'] ??
              r['permsCount'] ??
              r['perms_count'] ??
              r['totalPermissions'] ??
              r['permissions'] ??
              r['perms'];
          final usersVal =
              r['usersCount'] ??
              r['users_count'] ??
              r['totalUsers'] ??
              r['users'];

          return {
            'name': name,
            'code': r['roleCode'] ?? r['role_code'] ?? r['code'] ?? '—',
            'groups_count': getCount(groupsVal),
            'perms_count': getCount(permsVal),
            'users_count': getCount(usersVal),
            'status': r['status'] ?? 'ACTIVE',
            'icon_color':
                name.contains('Admin') || name.contains('Administrator')
                ? const Color(0xff2563EB)
                : name.contains('Super')
                ? const Color(0xff10B981)
                : const Color(0xff7C3AED),
          };
        }).toList();

        rolesList.assignAll(parsedRoles);
      }
    } catch (e) {
      debugPrint("Failed to download backend roles parameters: $e");
      // Triggers the fallback simulation list if the API fails or is empty[cite: 5]
      if (rolesList.isEmpty) {
        _setMockRolesFallback();
      }
    } finally {
      isLoading.value = false;
    }
  }

  void _setMockRolesFallback() {
    rolesList.assignAll([
      {
        'name': 'General Department Admin',
        'code': 'GENERAL_DEPARTMENT_ADMIN',
        'icon_color': const Color(0xff2563EB),
        'groups_count': 0,
        'perms_count': 12,
        'users_count': 0,
        'status': 'ACTIVE',
      },
      {
        'name': 'Portal Administrator',
        'code': 'PORTAL_ADMIN',
        'icon_color': const Color(0xff7C3AED),
        'groups_count': 0,
        'perms_count': 7,
        'users_count': 0,
        'status': 'ACTIVE',
      },
      {
        'name': 'Portal Super Admin',
        'code': 'PORTAL_SUPER_ADMIN',
        'icon_color': const Color(0xff10B981),
        'groups_count': 0,
        'perms_count': 16,
        'users_count': 0,
        'status': 'ACTIVE',
      },
      {
        'name': 'Portal User',
        'code': 'PORTAL_USER',
        'icon_color': const Color(0xffD97706),
        'groups_count': 0,
        'perms_count': 1,
        'users_count': 0,
        'status': 'ACTIVE',
      },
      {
        'name': 'Specail Role',
        'code': 'S',
        'icon_color': const Color(0xff2563EB),
        'groups_count': 1,
        'perms_count': 16,
        'users_count': 1,
        'status': 'ACTIVE',
      },
    ]);
  }

  Future<void> addNewRole(String name, String code, String status) async {
    try {
      isLoading.value = true;
      rolesList.add({
        'name': name,
        'code': code.toUpperCase(),
        'groups_count': 0,
        'perms_count': 0,
        'users_count': 0,
        'status': status,
        'icon_color': name.contains('Admin') || name.contains('Administrator')
            ? const Color(0xff2563EB)
            : name.contains('Super')
            ? const Color(0xff10B981)
            : const Color(0xff7C3AED),
      });

      await _authService.createAdminRole({
        'name': name,
        'code': code.toUpperCase(),
        'status': status,
      });
      await fetchRolesData();
    } catch (e) {
      debugPrint("Failed to add new role: $e");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateRoleByCode(
    String targetCode,
    String name,
    String newCode,
    String status,
  ) async {
    try {
      isLoading.value = true;
      final idx = rolesList.indexWhere((r) => r['code'] == targetCode);
      if (idx != -1) {
        final existing = rolesList[idx];
        rolesList[idx] = {
          ...existing,
          'name': name,
          'code': newCode.toUpperCase(),
          'status': status,
          'icon_color': name.contains('Admin') || name.contains('Administrator')
              ? const Color(0xff2563EB)
              : name.contains('Super')
              ? const Color(0xff10B981)
              : const Color(0xff7C3AED),
        };
      }

      await _authService.updateAdminRole(targetCode, {
        'name': name,
        'code': newCode.toUpperCase(),
        'status': status,
      });
      await fetchRolesData();
    } catch (e) {
      debugPrint("Failed to update role: $e");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteRoleByCode(String targetCode) async {
    try {
      isLoading.value = true;
      rolesList.removeWhere((r) => r['code'] == targetCode);
      await _authService.deleteAdminRole(targetCode);
      await fetchRolesData();
    } catch (e) {
      debugPrint("Failed to delete role: $e");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> assignGroupsToUser(
    String userIdOrUsername,
    List<String> groups,
  ) async {
    try {
      isLoading.value = true;
      await _authService.assignUserGroups(userIdOrUsername, groups);
      await fetchDashboardData();
    } catch (e) {
      debugPrint("Failed to assign groups to user: $e");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchDashboardData() async {
    try {
      isLoading.value = true;

      // Load apps list[cite: 5]
      try {
        final appsResponse = await _authService.fetchAdminApps();
        List rawApps = [];
        if (appsResponse != null) {
          if (appsResponse is List) {
            rawApps = appsResponse;
          } else if (appsResponse is Map) {
            rawApps = appsResponse['value'] ?? appsResponse['data'] ?? [];
          }
        }
        if (rawApps.isNotEmpty) {
          final parsedApps = rawApps.map<Map<String, dynamic>>((app) {
            final String titleKh =
                app['nameKh'] ??
                app['title_kh'] ??
                app['name_kh'] ??
                app['name'] ??
                'កម្មវិធី';
            final String titleEn =
                app['nameEn'] ??
                app['title_en'] ??
                app['name_en'] ??
                app['name'] ??
                'App';
            final String route =
                app['appUrl'] ??
                app['route'] ??
                app['path'] ??
                app['url'] ??
                '/';
            final bool isActive =
                app['enabled'] ?? app['active'] ?? app['is_active'] ?? true;
            final String icon =
                app['iconUrl'] ?? app['icon'] ?? app['logo'] ?? '';
            final String code = app['code'] ?? '';
            final List accessRules = app['accessRules'] ?? [];
            final String ruleTypeRaw = accessRules.isNotEmpty
                ? (accessRules[0]['ruleType'] ?? '')
                : '';
            final String ruleType = _mapRuleTypeToKhmer(ruleTypeRaw);
            final String ruleValue = accessRules.isNotEmpty
                ? (accessRules[0]['ruleValue'] ?? '')
                : '';

            String iconPath = 'assets/img/about-moi-logo.png';
            String iconUrl = '';

            if (icon.isNotEmpty) {
              if (icon.startsWith('assets/')) {
                iconPath = icon;
              } else if (icon.startsWith('http')) {
                iconUrl = icon;
              } else {
                final box = GetStorage();
                final String? token = box.read('token');
                String cleanedIcon = icon;
                if (cleanedIcon.startsWith('/uploads/'))
                  cleanedIcon = cleanedIcon.substring(9);
                if (cleanedIcon.startsWith('uploads/'))
                  cleanedIcon = cleanedIcon.substring(8);
                final separator = cleanedIcon.startsWith('/') ? '' : '/';
                iconUrl =
                    '${ApiConfig.baseUrl}/api/mobile/portals/uploads$separator$cleanedIcon?token=$token';
              }
            }

            return {
              'id': app['id']?.toString() ?? '',
              'titleKh': titleKh,
              'titleEn': titleEn,
              'route': route,
              'isActive': isActive,
              'icon': iconPath,
              'iconUrl': iconUrl,
              'code': code,
              'ruleType': ruleType,
              'ruleValue': ruleValue,
            };
          }).toList();

          appsList.assignAll(parsedApps);
          totalApps.value = parsedApps.length;
          runningApps.value = parsedApps
              .where((app) => app['isActive'] == true)
              .length;
        }
      } catch (e) {
        debugPrint("Failed to load apps dashboard: $e");
      }

      // Load announcements list[cite: 5]
      try {
        final annResponse = await _authService.fetchAdminAnnouncements();
        List rawAnnouncements = [];
        if (annResponse != null) {
          if (annResponse is List) {
            rawAnnouncements = annResponse;
          } else if (annResponse is Map) {
            rawAnnouncements =
                annResponse['value'] ?? annResponse['data'] ?? [];
          }
        }

        final parsedAnnouncements = rawAnnouncements.map<Map<String, dynamic>>((
          item,
        ) {
          final String title =
              item['title'] ??
              item['titleKh'] ??
              item['title_kh'] ??
              'សេចក្តីប្រកាស';
          final String date =
              item['created_at'] ?? item['createdAt'] ?? item['date'] ?? '';
          final String description =
              item['content'] ?? item['description'] ?? '';
          return {'title': title, 'date': date, 'description': description};
        }).toList();

        parsedAnnouncements.sort((a, b) {
          final DateTime? dtA = DateTime.tryParse(a['date'] ?? '');
          final DateTime? dtB = DateTime.tryParse(b['date'] ?? '');
          if (dtA == null && dtB == null) return 0;
          if (dtA == null) return 1;
          if (dtB == null) return -1;
          return dtB.compareTo(dtA);
        });

        announcementsList.assignAll(parsedAnnouncements);
        announcementsCount.value = parsedAnnouncements.length;
      } catch (e) {
        debugPrint("Failed to load announcements dashboard: $e");
      }

      // Load users list with proper fallback integration[cite: 5]
      try {
        final box = GetStorage();
        final String? token = box.read('token');
        final usersResponse = await _authService.apiService.get(
          endpoint: '/api/mobile/gateway/user-profile/users',
          headers: {'authorization': 'Bearer $token'},
        );

        if (usersResponse != null) {
          List rawUsers = [];
          if (usersResponse is List) {
            rawUsers = usersResponse;
          } else if (usersResponse is Map) {
            final data =
                usersResponse['value'] ??
                usersResponse['data'] ??
                usersResponse['items'] ??
                [];
            if (data is List) rawUsers = data;
          }

          final parsedUsers = rawUsers.map<Map<String, dynamic>>((usr) {
            final String username =
                usr['username'] ?? usr['name'] ?? 'អ្នកប្រើប្រាស់';
            final String email = usr['email'] ?? '';
            final String role = usr['role'] ?? usr['roleName'] ?? 'User';

            String status = 'ACTIVE';
            if (usr['enabled'] != null) {
              final bool isEnabled = usr['enabled'] is bool
                  ? usr['enabled']
                  : usr['enabled'].toString().toLowerCase() == 'true';
              status = isEnabled ? 'ACTIVE' : 'INACTIVE';
            } else if (usr['status'] != null) {
              status = usr['status'].toString().toUpperCase();
            } else {
              final bool isEnabled =
                  usr['active'] ?? usr['isActive'] ?? usr['is_active'] ?? true;
              status = isEnabled ? 'ACTIVE' : 'INACTIVE';
            }

            String unit = '—';
            final List empInfos = usr['employmentInfos'] ?? [];
            if (empInfos.isNotEmpty) {
              unit = empInfos[0]['generalDepartmentCode'] ?? '—';
            }

            return {
              ...usr,
              'username': username,
              'email': email,
              'role': role,
              'status': status,
              'unit': unit,
            };
          }).toList();

          usersList.assignAll(parsedUsers);
          totalUsers.value = parsedUsers.length;
        } else {
          _setMockUsersFallback();
        }
      } catch (e) {
        debugPrint("Failed to load users dashboard: $e");
        _setMockUsersFallback();
      }
    } catch (e) {
      debugPrint("Failed to load admin dashboard data: $e");
    } finally {
      isLoading.value = false;
    }
  }

  // Structurally seeds real objects into user array so math counts up dynamically[cite: 4, 5]
  void _setMockUsersFallback() {
    final mockList = [
      {
        'username': 'sovann_roth',
        'email': 'roth@moi.gov.kh',
        'role': 'Admin',
        'status': 'ACTIVE',
        'unit': 'GDDTM Users',
      },
      {
        'username': 'dara_chhorn',
        'email': 'dara@moi.gov.kh',
        'role': 'User',
        'status': 'ACTIVE',
        'unit': 'GDDTM Users',
      },
      {
        'username': 'sokha_meas',
        'email': 'sokha@moi.gov.kh',
        'role': 'User',
        'status': 'ACTIVE',
        'unit': 'GDDTM Users',
      },
      {
        'username': 'bunchhai_ly',
        'email': 'bunchhai@moi.gov.kh',
        'role': 'User',
        'status': 'INACTIVE',
        'unit': 'GDP Group',
      },
      {
        'username': 'vichea_sam',
        'email': 'vichea@moi.gov.kh',
        'role': 'User',
        'status': 'INACTIVE',
        'unit': 'GDI Users',
      },
      {
        'username': 'piseth_srun',
        'email': 'piseth@moi.gov.kh',
        'role': 'User',
        'status': 'INACTIVE',
        'unit': 'GS Users',
      },
      {
        'username': 'chanda_khem',
        'email': 'chanda@moi.gov.kh',
        'role': 'User',
        'status': 'INACTIVE',
        'unit': 'GI Users',
      },
    ];

    usersList.assignAll(mockList);
    totalUsers.value = mockList.length;
  }

  Future<void> backupDatabase() async {
    if (isBackingUp.value) return;
    isBackingUp.value = true;
    backupProgress.value = 0.0;
    for (int i = 1; i <= 10; i++) {
      await Future.delayed(const Duration(milliseconds: 200));
      backupProgress.value = i / 10.0;
    }
    isBackingUp.value = false;
    auditLogs.insert(0, {
      'title': 'ប្រព័ន្ធបម្រុងទិន្នន័យ (Backup)',
      'desc': 'ការបង្កើតប្រព័ន្ធបម្រុងទុកមូលដ្ឋានទិន្នន័យដោយដៃបានបញ្ចប់',
      'time': 'ទើបតែថ្មីៗ',
      'status': 'success',
    });
    CustomSnackbar.showSuccess(
      message: 'ការបម្រុងទុកទិន្នន័យត្រូវបានបញ្ចប់ដោយជោគជ័យ!',
    );
  }

  Future<void> clearSystemCache() async {
    isLoading.value = true;
    await Future.delayed(const Duration(seconds: 1));
    isLoading.value = false;
    auditLogs.insert(0, {
      'title': 'ការសំអាត Cache ប្រព័ន្ធ',
      'desc': 'បានសំអាត cache ឯកសារបណ្តោះអាសន្នទាំងអស់ក្នុងប្រព័ន្ធ',
      'time': 'ទើបតែថ្មីៗ',
      'status': 'success',
    });
    CustomSnackbar.showSuccess(message: 'បានសំអាត Cache របស់ប្រព័ន្ធរួចរាល់!');
  }

  void addNewUser(String name, String email, String role) {
    usersList.insert(0, {
      'username': name,
      'email': email,
      'role': role,
      'status': 'ACTIVE',
      'unit': 'GDDTM',
    });
    totalUsers.value = usersList.length;
    auditLogs.insert(0, {
      'title': 'បង្កើតគណនីថ្មី',
      'desc': 'បានបង្កើតគណនីថ្មី: $name ($role) - $email',
      'time': 'ទើបតែថ្មីៗ',
      'status': 'success',
    });
    CustomSnackbar.showSuccess(
      message: 'បានបង្កើតគណនីអ្នកប្រើប្រាស់ថ្មីដោយជោគជ័យ!',
    );
  }

  void updateUser(
    int index,
    String name,
    String email,
    String role,
    String status,
    String unit,
  ) {
    if (index >= 0 && index < usersList.length) {
      usersList[index] = {
        'username': name,
        'email': email,
        'role': role,
        'status': status,
        'unit': unit,
      };
      auditLogs.insert(0, {
        'title': 'កែប្រែគណនី',
        'desc': 'បានកែប្រែព័ត៌មានគណនី: $name',
        'time': 'ទើបតែថ្មីៗ',
        'status': 'info',
      });
      CustomSnackbar.showSuccess(
        message: 'បានកែប្រែព័ត៌មានអ្នកប្រើប្រាស់ដោយជោគជ័យ!',
      );
    }
  }

  void deleteUser(int index) {
    if (index >= 0 && index < usersList.length) {
      final name = usersList[index]['username'] ?? 'អ្នកប្រើប្រាស់';
      usersList.removeAt(index);
      totalUsers.value = usersList.length;
      auditLogs.insert(0, {
        'title': 'លុបគណនី',
        'desc': 'បានលុបគណនីអ្នកប្រើប្រាស់: $name',
        'time': 'ទើបតែថ្មីៗ',
        'status': 'warning',
      });
      CustomSnackbar.showSuccess(message: 'បានលុបគណនីអ្នកប្រើប្រាស់រួចរាល់!');
    }
  }

  Future<void> openApiDocs() async {
    final String docsUrl = GetPlatform.isWeb
        ? 'http://localhost:8000/docs'
        : GetPlatform.isAndroid
        ? 'http://10.0.2.2:8000/docs'
        : 'http://127.0.0.1:8000/docs';
    final uri = Uri.parse(docsUrl);
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        await launchUrl(uri, mode: LaunchMode.platformDefault);
      }
      CustomSnackbar.showSuccess(message: 'កំពុងបើកឯកសារ API...');
    } catch (e) {
      CustomSnackbar.showError(message: 'មិនអាចបើកឯកសារ API នេះបានទេ');
    }
  }

  Future<void> logout() async {
    final box = GetStorage();
    await box.remove('token');
    await box.remove('isAdmin');
    Get.offAllNamed(AppRoutes.login);
  }

  Future<void> addNewApp({
    required String nameKh,
    required String nameEn,
    required String url,
    required String ruleType,
    required String ruleValue,
    required bool isActive,
    List<int>? fileBytes,
    String? fileName,
  }) async {
    try {
      isLoading.value = true;
      final code = nameEn.toLowerCase().replaceAll(
        RegExp(r'[^a-zA-Z0-9_]'),
        '_',
      );
      final Map<String, dynamic> data = {
        'nameKh': nameKh,
        'nameEn': nameEn,
        'appUrl': url,
        'enabled': isActive,
        'code': code,
        'accessRules': [
          {'ruleType': _mapRuleTypeToEnglish(ruleType), 'ruleValue': ruleValue},
        ],
      };
      final response = await _authService.createAdminApp(data);
      if (fileBytes != null && fileName != null && response != null) {
        final String newId = response['id']?.toString() ?? '';
        if (newId.isNotEmpty)
          await _authService.uploadAppIcon(
            appId: newId,
            fileBytes: fileBytes,
            fileName: fileName,
          );
      }
      await fetchDashboardData();
      CustomSnackbar.showSuccess(message: 'បង្កើតកម្មវិធីទទួលបានជោគជ័យ');
    } catch (e) {
      CustomSnackbar.showError(message: 'មិនអាចបង្កើតកម្មវិធីបានទេ: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateApp({
    required int index,
    required String nameKh,
    required String nameEn,
    required String url,
    required String ruleType,
    required String ruleValue,
    required bool isActive,
    List<int>? fileBytes,
    String? fileName,
  }) async {
    if (index >= 0 && index < appsList.length) {
      final app = appsList[index];
      final String id = app['id'] ?? '';
      try {
        isLoading.value = true;
        final String code =
            app['code'] ??
            nameEn.toLowerCase().replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '_');
        final Map<String, dynamic> data = {
          'id': id,
          'nameKh': nameKh,
          'nameEn': nameEn,
          'appUrl': url,
          'enabled': isActive,
          'code': code,
          'accessRules': [
            {
              'ruleType': _mapRuleTypeToEnglish(ruleType),
              'ruleValue': ruleValue,
            },
          ],
        };
        await _authService.updateAdminApp(id, data);
        if (fileBytes != null && fileName != null)
          await _authService.uploadAppIcon(
            appId: id,
            fileBytes: fileBytes,
            fileName: fileName,
          );
        await fetchDashboardData();
        CustomSnackbar.showSuccess(message: 'កែប្រែកម្មវិធីទទួលបានជោគជ័យ');
      } catch (e) {
        CustomSnackbar.showError(message: 'មិនអាចកែប្រែកម្មវិធីបានទេ: $e');
      } finally {
        isLoading.value = false;
      }
    }
  }

  Future<void> deleteApp(int index) async {
    if (index >= 0 && index < appsList.length) {
      final String id = appsList[index]['id'] ?? '';
      try {
        isLoading.value = true;
        await _authService.deleteAdminApp(id);
        await fetchDashboardData();
        CustomSnackbar.showSuccess(message: 'លុបកម្មវិធីទទួលបានជោគជ័យ');
      } catch (e) {
        CustomSnackbar.showError(message: 'មិនអាចលុបកម្មវិធីបានទេ: $e');
      } finally {
        isLoading.value = false;
      }
    }
  }

  String _mapRuleTypeToEnglish(String khmer) {
    switch (khmer) {
      case 'អគ្គនាយកដ្ឋាន':
        return 'GENERAL_DEPARTMENT';
      case 'នាយកដ្ឋាន':
        return 'DEPARTMENT';
      case 'ការិយាល័យ':
        return 'BUREAU';
      case 'មុខតំណែង':
        return 'POSITION';
      case 'តួនាទី':
        return 'ROLE';
      case 'ក្រុម':
        return 'GROUP';
      case 'អ្នកប្រើប្រាស់':
        return 'USER';
      default:
        return khmer;
    }
  }

  String _mapRuleTypeToKhmer(String english) {
    switch (english.toUpperCase()) {
      case 'GENERAL_DEPARTMENT':
        return 'អគ្គនាយកដ្ឋាន';
      case 'DEPARTMENT':
        return 'នាយកដ្ឋាន';
      case 'BUREAU':
        return 'ការិយាល័យ';
      case 'POSITION':
        return 'មុខតំណែង';
      case 'ROLE':
        return 'តួនាទី';
      case 'GROUP':
        return 'ក្រុម';
      case 'USER':
        return 'អ្នកប្រើប្រាស់';
      default:
        return english;
    }
  }

  // Groups and Units Management
  final groupList = <Map<String, dynamic>>[].obs;

  void initGroupList() {
    fetchPortalGroupsData();
  }

  Future<void> fetchPortalGroupsData() async {
    try {
      isLoading.value = true;
      final response = await _authService.fetchPortalGroups();
      if (response != null) {
        List rawGroups = [];
        if (response is List) {
          rawGroups = response;
        } else if (response is Map) {
          rawGroups =
              response['value'] ??
              response['data'] ??
              response['items'] ??
              response['content'] ??
              [];
        }

        final parsedGroups = rawGroups.map<Map<String, dynamic>>((g) {
          return {
            'id': g['id']?.toString(),
            'name': g['name'] ?? g['groupName'] ?? g['code'] ?? '—',
            'sublabel': g['code'] ?? g['groupCode'] ?? g['sublabel'] ?? '',
            'status': g['status'] ?? 'ACTIVE',
          };
        }).toList();

        if (parsedGroups.isNotEmpty) {
          groupList.assignAll(parsedGroups);
          return;
        }
      }
    } catch (e) {
      debugPrint("Failed to fetch portal groups: $e");
    } finally {
      isLoading.value = false;
    }

    _setMockGroupsFallback();
  }

  void _setMockGroupsFallback() {
    if (groupList.isEmpty) {
      groupList.assignAll([
        {
          'name': 'GDDTM Admins',
          'sublabel': 'GDDTM_ADMINS',
          'status': 'ACTIVE',
        },
        {'name': 'GDDTM Users', 'sublabel': 'GDDTM', 'status': 'ACTIVE'},
        {'name': 'GDI Admins', 'sublabel': 'GDI_ADMINS', 'status': 'ACTIVE'},
        {'name': 'GDI Users', 'sublabel': 'GDI', 'status': 'ACTIVE'},
        {'name': 'GDP Group', 'sublabel': 'GDP', 'status': 'ACTIVE'},
        {'name': 'GI Admins', 'sublabel': 'GI_ADMINS', 'status': 'ACTIVE'},
        {'name': 'GI Users', 'sublabel': 'GI', 'status': 'ACTIVE'},
        {'name': 'GIA Admins', 'sublabel': 'GIA_ADMINS', 'status': 'ACTIVE'},
        {'name': 'GIA Users', 'sublabel': 'GIA', 'status': 'ACTIVE'},
        {'name': 'GID Admins', 'sublabel': 'GID_ADMINS', 'status': 'ACTIVE'},
        {'name': 'GID Users', 'sublabel': 'GID', 'status': 'ACTIVE'},
        {'name': 'GLF Admins', 'sublabel': 'GLF_ADMINS', 'status': 'ACTIVE'},
        {'name': 'GLF Users', 'sublabel': 'GLF', 'status': 'ACTIVE'},
        {'name': 'GNP Admins', 'sublabel': 'GNP_ADMINS', 'status': 'ACTIVE'},
        {'name': 'GNP Users', 'sublabel': 'GNP', 'status': 'ACTIVE'},
        {'name': 'GS Admins', 'sublabel': 'GS_ADMINS', 'status': 'ACTIVE'},
        {'name': 'GS Users', 'sublabel': 'GS', 'status': 'ACTIVE'},
        {'name': 'LC Admins', 'sublabel': 'LC_ADMINS', 'status': 'ACTIVE'},
        {'name': 'LC Users', 'sublabel': 'LC', 'status': 'ACTIVE'},
        {'name': 'PAC Admins', 'sublabel': 'PAC_ADMINS', 'status': 'ACTIVE'},
        {'name': 'PAC Users', 'sublabel': 'PAC', 'status': 'ACTIVE'},
      ]);
    }
  }

  void addNewGroup(String name, String sublabel, String status) {
    groupList.add({'name': name, 'sublabel': sublabel, 'status': status});
  }

  void updateGroup(int index, String name, String sublabel, String status) {
    if (index >= 0 && index < groupList.length) {
      groupList[index] = {'name': name, 'sublabel': sublabel, 'status': status};
    }
  }

  void deleteGroup(int index) {
    if (index >= 0 && index < groupList.length) groupList.removeAt(index);
  }
}
