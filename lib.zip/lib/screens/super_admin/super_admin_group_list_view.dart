import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:core_portal/screens/super_admin/super_admin_controller.dart';
import 'package:core_portal/widgets/custom_snackbar.dart';

class SuperAdminGroupListView extends StatefulWidget {
  const SuperAdminGroupListView({super.key});

  @override
  State<SuperAdminGroupListView> createState() =>
      _SuperAdminGroupListViewState();
}

class _SuperAdminGroupListViewState extends State<SuperAdminGroupListView> {
  final SuperAdminController controller = Get.find<SuperAdminController>();

  final searchQuery = ''.obs;
  final statusFilter = 'ស្ថានភាពទាំងអស់'.obs;
  final currentPage = 1.obs;
  static const int itemsPerPage = 10;

  // ── Helpers ──────────────────────────────────────────────────────────────

  int getUserCountForGroup(String groupName, String sublabel) {
    int count = 0;

    // 1. Try counting based on actual user group assignments from the API
    for (var u in controller.usersList) {
      final List? userGroups = u['groups'];
      if (userGroups != null) {
        final hasGroup = userGroups.any((g) {
          if (g is String) {
            final cleaned = g.startsWith('/') ? g.substring(1) : g;
            return cleaned.toLowerCase().trim() ==
                    groupName.toLowerCase().trim() ||
                cleaned.toLowerCase().trim() == sublabel.toLowerCase().trim();
          } else if (g is Map) {
            final name = (g['name'] ?? g['groupName'] ?? g['code'] ?? '')
                .toString();
            return name.toLowerCase().trim() ==
                    groupName.toLowerCase().trim() ||
                name.toLowerCase().trim() == sublabel.toLowerCase().trim();
          }
          return false;
        });
        if (hasGroup) {
          count++;
        }
      }
    }

    if (count > 0) return count;

    // 2. Fallback to matching by unit and role if no groups are present in API data
    if (sublabel.endsWith('_ADMINS')) {
      final code = sublabel.replaceFirst('_ADMINS', '');
      count = controller.usersList
          .where(
            (u) =>
                (u['unit'] ?? '').toString().toUpperCase() ==
                    code.toUpperCase() &&
                (u['role'] ?? '').toString().toUpperCase() == 'ADMIN',
          )
          .length;
    } else {
      count = controller.usersList
          .where(
            (u) =>
                (u['unit'] ?? '').toString().toUpperCase() ==
                    sublabel.toUpperCase() &&
                (u['role'] ?? '').toString().toUpperCase() != 'ADMIN',
          )
          .length;
    }
    return count;
  }

  List<Map<String, dynamic>> getFilteredGroups() {
    return controller.groupList.where((group) {
      final name = (group['name'] ?? '').toString().toLowerCase();
      final sub = (group['sublabel'] ?? '').toString().toLowerCase();
      final query = searchQuery.value.toLowerCase().trim();

      final matchesSearch =
          query.isEmpty || name.contains(query) || sub.contains(query);

      bool matchesStatus = true;
      if (statusFilter.value != 'ស្ថានភាពទាំងអស់') {
        final st = group['status'] ?? 'ACTIVE';
        matchesStatus = statusFilter.value == 'ដំណើរការ'
            ? st == 'ACTIVE'
            : st != 'ACTIVE';
      }

      return matchesSearch && matchesStatus;
    }).toList();
  }

  List<Map<String, dynamic>> getPagedGroups(
    List<Map<String, dynamic>> filtered,
  ) {
    final start = (currentPage.value - 1) * itemsPerPage;
    final end = (start + itemsPerPage).clamp(0, filtered.length);
    if (start >= filtered.length) return [];
    return filtered.sublist(start, end);
  }

  int getTotalPages(int total) => (total / itemsPerPage).ceil().clamp(1, 999);

  void _onSearchChanged(String val) {
    searchQuery.value = val;
    currentPage.value = 1;
  }

  void _onStatusChanged(String? val) {
    if (val != null) {
      statusFilter.value = val;
      currentPage.value = 1;
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Color(0xff0F172A),
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'បញ្ជីអង្គភាព',
          style: GoogleFonts.kantumruyPro(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: const Color(0xff0F172A),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xffE29D11),
                foregroundColor: Colors.white,
                elevation: 0,
                minimumSize: const Size(0, 36),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              icon: const Icon(Icons.add_rounded, size: 16),
              label: Text(
                'បង្កើតអង្គភាព',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
              onPressed: () => _showAddGroupSheet(context),
            ),
          ),
        ],
      ),
      body: Obx(() {
        final allFiltered = getFilteredGroups();
        final groups = getPagedGroups(allFiltered);
        final totalPages = getTotalPages(allFiltered.length);

        final totalGroupsCount = controller.groupList.length;
        final activeGroupsCount = controller.groupList
            .where((g) => g['status'] == 'ACTIVE')
            .length;
        final suspendedGroupsCount = totalGroupsCount - activeGroupsCount;

        int totalUsersInGroups = 0;
        for (final g in controller.groupList) {
          totalUsersInGroups += getUserCountForGroup(
            g['name'] ?? '',
            g['sublabel'] ?? '',
          );
        }

        final int startIndex = allFiltered.isEmpty
            ? 0
            : (currentPage.value - 1) * itemsPerPage + 1;
        final int endIndex =
            ((currentPage.value - 1) * itemsPerPage + groups.length).clamp(
              0,
              allFiltered.length,
            );

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Stats Grid ────────────────────────────────────────────────
              LayoutBuilder(
                builder: (context, constraints) {
                  final isWide = constraints.maxWidth > 700;
                  return GridView.count(
                    crossAxisCount: isWide ? 4 : 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: isWide ? 1.5 : 1.3,
                    children: [
                      _buildStatCard(
                        'អង្គភាពសរុប',
                        '$totalGroupsCount',
                        'អង្គភាពទាំងអស់ក្នុងប្រព័ន្ធ',
                        Icons.groups_outlined,
                        const Color(0xff6366F1),
                      ),
                      _buildStatCard(
                        'អង្គភាពដំណើរការ',
                        '$activeGroupsCount',
                        '100% នៃចំនួនសរុប',
                        Icons.check_circle_outline_rounded,
                        const Color(0xff10B981),
                      ),
                      _buildStatCard(
                        'អង្គភាពផ្អាក',
                        '$suspendedGroupsCount',
                        '0% នៃចំនួនសរុប',
                        Icons.pause_circle_outline_rounded,
                        const Color(0xffF59E0B),
                      ),
                      _buildStatCard(
                        'អ្នកប្រើប្រាស់សរុប',
                        '$totalUsersInGroups',
                        'ក្នុងអង្គភាពទាំងអស់',
                        Icons.person_outline_rounded,
                        const Color(0xff3B82F6),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),

              // ── Search / Filter + List Card ───────────────────────────────
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xffE2E8F0)),
                ),
                child: Column(
                  children: [
                    // Search + dropdown
                    LayoutBuilder(
                      builder: (context, c) {
                        if (c.maxWidth < 600) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              _buildSearchField(),
                              const SizedBox(height: 12),
                              _buildStatusDropdown(),
                            ],
                          );
                        }
                        return Row(
                          children: [
                            Expanded(child: _buildSearchField()),
                            const SizedBox(width: 12),
                            SizedBox(width: 180, child: _buildStatusDropdown()),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 16),

                    // List
                    if (groups.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 40),
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.people_outline_rounded,
                                size: 48,
                                color: Colors.grey,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'រកមិនឃើញអង្គភាពដែលអ្នកស្វែងរកទេ',
                                style: GoogleFonts.kantumruyPro(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffF1F5F9)),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: groups.length,
                          separatorBuilder: (context, index) => const Divider(
                            height: 1,
                            color: Color(0xffF1F5F9),
                          ),
                          itemBuilder: (context, idx) {
                            final group = groups[idx];
                            final groupName = group['name'] ?? '';
                            final sublabel = group['sublabel'] ?? '';
                            final status = group['status'] ?? 'ACTIVE';
                            final isActive = status == 'ACTIVE';
                            final memberCount = getUserCountForGroup(
                              groupName,
                              sublabel,
                            );
                            final masterIdx = controller.groupList.indexOf(
                              group,
                            );
                            // Global row number across pages
                            final globalNo =
                                (currentPage.value - 1) * itemsPerPage +
                                idx +
                                1;

                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 10,
                              ),
                              child: Row(
                                children: [
                                  // No.
                                  SizedBox(
                                    width: 24,
                                    child: Text(
                                      '$globalNo',
                                      style: GoogleFonts.poppins(
                                        fontSize: 12,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ),

                                  // Group icon + name
                                  Expanded(
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 36,
                                          height: 36,
                                          decoration: BoxDecoration(
                                            color: const Color(0xff2563EB),
                                            borderRadius: BorderRadius.circular(
                                              8,
                                            ),
                                          ),
                                          child: const Icon(
                                            Icons.people_alt_rounded,
                                            color: Colors.white,
                                            size: 18,
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                groupName,
                                                style: GoogleFonts.kantumruyPro(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 13,
                                                  color: const Color(
                                                    0xff0F172A,
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                sublabel,
                                                style: GoogleFonts.poppins(
                                                  fontSize: 10,
                                                  color: Colors.grey,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(width: 8),

                                  // Member count badge
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: const Color(0xffF8FAFC),
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        color: const Color(0xffE2E8F0),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Icon(
                                          Icons.person_outline_rounded,
                                          size: 13,
                                          color: Colors.grey,
                                        ),
                                        const SizedBox(width: 3),
                                        Text(
                                          '$memberCount',
                                          style: GoogleFonts.poppins(
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(width: 12),

                                  // Actions & Status Stack
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          IconButton(
                                            visualDensity:
                                                VisualDensity.compact,
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(),
                                            icon: const Icon(
                                              Icons.visibility_outlined,
                                              size: 18,
                                              color: Colors.grey,
                                            ),
                                            onPressed: () => _viewGroupMembers(
                                              context,
                                              groupName,
                                              sublabel,
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          IconButton(
                                            visualDensity:
                                                VisualDensity.compact,
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(),
                                            icon: const Icon(
                                              Icons.edit_outlined,
                                              size: 18,
                                              color: Colors.grey,
                                            ),
                                            onPressed: () =>
                                                _showEditGroupSheet(
                                                  context,
                                                  masterIdx,
                                                  groupName,
                                                  sublabel,
                                                  status,
                                                ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: isActive
                                              ? const Color(0xffECFDF5)
                                              : const Color(0xffFEF3C7),
                                          borderRadius: BorderRadius.circular(
                                            6,
                                          ),
                                        ),
                                        child: Text(
                                          isActive ? '• ដំណើរការ' : '• ផ្អាក',
                                          style: GoogleFonts.kantumruyPro(
                                            color: isActive
                                                ? const Color(0xff10B981)
                                                : const Color(0xffD97706),
                                            fontSize: 9,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),

                    // ── Pagination Footer ─────────────────────────────────
                    if (allFiltered.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'បង្ហាញ $startIndex ដល់ $endIndex នៃ ${allFiltered.length} ធាតុ',
                            style: GoogleFonts.kantumruyPro(
                              fontSize: 11,
                              color: Colors.grey,
                            ),
                          ),
                          Row(
                            children: [
                              _buildPageBtn(
                                icon: Icons.chevron_left_rounded,
                                onTap: currentPage.value > 1
                                    ? () => currentPage.value--
                                    : null,
                              ),
                              const SizedBox(width: 4),
                              ...List.generate(totalPages, (i) {
                                final page = i + 1;
                                final isSel = page == currentPage.value;
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 2,
                                  ),
                                  child: GestureDetector(
                                    onTap: () => currentPage.value = page,
                                    child: Container(
                                      width: 32,
                                      height: 32,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: isSel
                                            ? const Color(0xffE29D11)
                                            : Colors.transparent,
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: isSel
                                              ? const Color(0xffE29D11)
                                              : const Color(0xffE2E8F0),
                                        ),
                                      ),
                                      child: Text(
                                        '$page',
                                        style: GoogleFonts.poppins(
                                          fontSize: 12,
                                          fontWeight: isSel
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                          color: isSel
                                              ? Colors.white
                                              : const Color(0xff475569),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }),
                              const SizedBox(width: 4),
                              _buildPageBtn(
                                icon: Icons.chevron_right_rounded,
                                onTap: currentPage.value < totalPages
                                    ? () => currentPage.value++
                                    : null,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  // ── Helper Widgets ────────────────────────────────────────────────────────

  Widget _buildPageBtn({required IconData icon, VoidCallback? onTap}) {
    final enabled = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xffE2E8F0)),
        ),
        child: Icon(
          icon,
          size: 18,
          color: enabled ? const Color(0xff475569) : Colors.grey.shade300,
        ),
      ),
    );
  }

  Widget _buildStatCard(
    String title,
    String count,
    String subtitle,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const Spacer(),
              Text(
                count,
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff0f172a),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: GoogleFonts.kantumruyPro(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: GoogleFonts.kantumruyPro(fontSize: 9, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchField() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xffF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: TextField(
        onChanged: _onSearchChanged,
        decoration: InputDecoration(
          hintText: 'ស្វែងរកតាមឈ្មោះក្រុម...',
          hintStyle: GoogleFonts.kantumruyPro(fontSize: 13, color: Colors.grey),
          prefixIcon: const Icon(
            Icons.search_rounded,
            color: Colors.grey,
            size: 18,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 12,
          ),
        ),
      ),
    );
  }

  Widget _buildStatusDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xffF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: statusFilter.value,
          isExpanded: true,
          items: ['ស្ថានភាពទាំងអស់', 'ដំណើរការ', 'ផ្អាក'].map((v) {
            return DropdownMenuItem<String>(
              value: v,
              child: Text(v, style: GoogleFonts.kantumruyPro(fontSize: 13)),
            );
          }).toList(),
          onChanged: _onStatusChanged,
        ),
      ),
    );
  }

  // ── Sheets / Dialogs ──────────────────────────────────────────────────────

  void _showAddGroupSheet(BuildContext context) {
    final nameCtrl = TextEditingController();
    final sublabelCtrl = TextEditingController();
    String selectedStatus = 'ACTIVE';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 20,
          right: 20,
          top: 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'បង្កើតអង្គភាពថ្មី',
              style: GoogleFonts.kantumruyPro(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: const Color(0xff1E293B),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: nameCtrl,
              decoration: InputDecoration(
                labelText: 'ឈ្មោះអង្គភាព (ក្រុម)',
                labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: sublabelCtrl,
              decoration: InputDecoration(
                labelText: 'លេខសម្គាល់អង្គភាព (Sublabel/Code)',
                labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: selectedStatus,
              decoration: InputDecoration(
                labelText: 'ស្ថានភាព',
                labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              items: [
                DropdownMenuItem(
                  value: 'ACTIVE',
                  child: Text(
                    'ដំណើរការ',
                    style: GoogleFonts.kantumruyPro(fontSize: 13),
                  ),
                ),
                DropdownMenuItem(
                  value: 'INACTIVE',
                  child: Text(
                    'ផ្អាក',
                    style: GoogleFonts.kantumruyPro(fontSize: 13),
                  ),
                ),
              ],
              onChanged: (val) {
                if (val != null) selectedStatus = val;
              },
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xffE29D11),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onPressed: () {
                  final name = nameCtrl.text.trim();
                  final sublabel = sublabelCtrl.text.trim();
                  if (name.isEmpty || sublabel.isEmpty) {
                    CustomSnackbar.showError(
                      message: 'សូមបំពេញព័ត៌មានអោយបានគ្រប់គ្រាន់',
                    );
                    return;
                  }
                  controller.addNewGroup(name, sublabel, selectedStatus);
                  Navigator.of(context).pop();
                  CustomSnackbar.showSuccess(
                    message: 'បានបង្កើតអង្គភាពដោយជោគជ័យ!',
                  );
                },
                child: Text(
                  'បង្កើតអង្គភាព',
                  style: GoogleFonts.kantumruyPro(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _showEditGroupSheet(
    BuildContext context,
    int masterIndex,
    String currentName,
    String currentSublabel,
    String currentStatus,
  ) {
    final nameCtrl = TextEditingController(text: currentName);
    final sublabelCtrl = TextEditingController(text: currentSublabel);
    String selectedStatus = currentStatus;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 20,
          right: 20,
          top: 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'កែប្រែព័ត៌មានអង្គភាព',
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff1E293B),
                  ),
                ),
                IconButton(
                  icon: const Icon(
                    Icons.delete_outline_rounded,
                    color: Colors.red,
                  ),
                  onPressed: () {
                    Navigator.of(context).pop();
                    _confirmDeleteGroup(context, masterIndex, currentName);
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
            TextField(
              controller: nameCtrl,
              decoration: InputDecoration(
                labelText: 'ឈ្មោះអង្គភាព (ក្រុម)',
                labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: sublabelCtrl,
              decoration: InputDecoration(
                labelText: 'លេខសម្គាល់អង្គភាព (Sublabel/Code)',
                labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: selectedStatus,
              decoration: InputDecoration(
                labelText: 'ស្ថានភាព',
                labelStyle: GoogleFonts.kantumruyPro(fontSize: 13),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              items: [
                DropdownMenuItem(
                  value: 'ACTIVE',
                  child: Text(
                    'ដំណើរការ',
                    style: GoogleFonts.kantumruyPro(fontSize: 13),
                  ),
                ),
                DropdownMenuItem(
                  value: 'INACTIVE',
                  child: Text(
                    'ផ្អាក',
                    style: GoogleFonts.kantumruyPro(fontSize: 13),
                  ),
                ),
              ],
              onChanged: (val) {
                if (val != null) selectedStatus = val;
              },
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xffE29D11),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onPressed: () {
                  final name = nameCtrl.text.trim();
                  final sublabel = sublabelCtrl.text.trim();
                  if (name.isEmpty || sublabel.isEmpty) {
                    CustomSnackbar.showError(
                      message: 'សូមបំពេញព័ត៌មានអោយបានគ្រប់គ្រាន់',
                    );
                    return;
                  }
                  controller.updateGroup(
                    masterIndex,
                    name,
                    sublabel,
                    selectedStatus,
                  );
                  Navigator.of(context).pop();
                  CustomSnackbar.showSuccess(
                    message: 'បានរក្សាទុកការកែប្រែដោយជោគជ័យ!',
                  );
                },
                child: Text(
                  'រក្សាទុក',
                  style: GoogleFonts.kantumruyPro(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _confirmDeleteGroup(
    BuildContext context,
    int masterIndex,
    String groupName,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'លុបអង្គភាព',
          style: GoogleFonts.kantumruyPro(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'តើអ្នកពិតជាចង់លុបអង្គភាព "$groupName" នេះមែនទេ?',
          style: GoogleFonts.kantumruyPro(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'បោះបង់',
              style: GoogleFonts.kantumruyPro(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              minimumSize: const Size(0, 0),
            ),
            onPressed: () {
              controller.deleteGroup(masterIndex);
              Navigator.of(context).pop();
              CustomSnackbar.showSuccess(message: 'បានលុបអង្គភាពដោយជោគជ័យ!');
            },
            child: Text('លុប', style: GoogleFonts.kantumruyPro()),
          ),
        ],
      ),
    );
  }

  void _viewGroupMembers(
    BuildContext context,
    String groupName,
    String sublabel,
  ) {
    final List<dynamic> members = [];

    // 1. Try finding by group name in user's groups list from the API
    for (var u in controller.usersList) {
      final List? userGroups = u['groups'];
      if (userGroups != null) {
        final hasGroup = userGroups.any((g) {
          if (g is String) {
            final cleaned = g.startsWith('/') ? g.substring(1) : g;
            return cleaned.toLowerCase().trim() ==
                    groupName.toLowerCase().trim() ||
                cleaned.toLowerCase().trim() == sublabel.toLowerCase().trim();
          } else if (g is Map) {
            final name = (g['name'] ?? g['groupName'] ?? g['code'] ?? '')
                .toString();
            return name.toLowerCase().trim() ==
                    groupName.toLowerCase().trim() ||
                name.toLowerCase().trim() == sublabel.toLowerCase().trim();
          }
          return false;
        });
        if (hasGroup) {
          members.add(u);
        }
      }
    }

    // 2. Fallback to matching by unit and role if no members found via group list
    if (members.isEmpty) {
      final searchKey = sublabel.endsWith('_ADMINS')
          ? sublabel.replaceFirst('_ADMINS', '')
          : sublabel;

      final matched = controller.usersList.where((u) {
        final unitCode = (u['unit'] ?? '').toString().toUpperCase();
        final userRole = (u['role'] ?? '').toString().toUpperCase();
        return sublabel.endsWith('_ADMINS')
            ? unitCode == searchKey.toUpperCase() && userRole == 'ADMIN'
            : unitCode == searchKey.toUpperCase() && userRole != 'ADMIN';
      }).toList();
      members.addAll(matched);
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'សមាជិកក្នុងក្រុម',
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xff0F172A),
                        ),
                      ),
                      Text(
                        '$groupName ($sublabel)',
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close_rounded),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'បញ្ជីសមាជិក (${members.length})',
              style: GoogleFonts.kantumruyPro(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: members.isEmpty
                  ? Center(
                      child: Text(
                        'គ្មានអ្នកប្រើប្រាស់នៅក្នុងក្រុមនេះទេ',
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: members.length,
                      itemBuilder: (context, idx) {
                        final m = members[idx];
                        final name = m['username'] ?? '—';
                        final email = m['email'] ?? '—';
                        final mStatus = m['status'] ?? 'ACTIVE';
                        final isActive = mStatus == 'ACTIVE';
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xffF1F5F9),
                            child: Text(
                              name.isNotEmpty
                                  ? name.substring(0, 1).toUpperCase()
                                  : 'U',
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.bold,
                                color: const Color(0xff475569),
                              ),
                            ),
                          ),
                          title: Text(
                            name,
                            style: GoogleFonts.kantumruyPro(
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                          subtitle: Text(
                            email,
                            style: GoogleFonts.poppins(fontSize: 11),
                          ),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: isActive
                                  ? const Color(0xffECFDF5)
                                  : const Color(0xffFEF3C7),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              isActive ? 'ដំណើរការ' : 'ផ្អាក',
                              style: GoogleFonts.kantumruyPro(
                                color: isActive
                                    ? const Color(0xff10B981)
                                    : const Color(0xffD97706),
                                fontSize: 8,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
