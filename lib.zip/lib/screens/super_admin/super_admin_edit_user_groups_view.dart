import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:core_portal/screens/super_admin/super_admin_controller.dart';
import 'package:core_portal/screens/admin/admin_controller.dart';
import 'package:core_portal/widgets/custom_snackbar.dart';

class SuperAdminEditUserGroupsView extends StatefulWidget {
  final Map<String, dynamic> user;

  const SuperAdminEditUserGroupsView({super.key, required this.user});

  @override
  State<SuperAdminEditUserGroupsView> createState() =>
      _SuperAdminEditUserGroupsViewState();
}

class _SuperAdminEditUserGroupsViewState
    extends State<SuperAdminEditUserGroupsView> {
  late dynamic controller;
  late Map<String, dynamic> _selectedUser;

  final leftSearchQuery = "".obs;
  final leftChecked = <String>{}.obs;
  final rightChecked = <String>{}.obs;

  final availableGroups = <String>[].obs;
  final assignedGroups = <String>[].obs;
  final filteredAvailableGroups = <String>[].obs;

  @override
  void initState() {
    super.initState();
    _selectedUser = widget.user;

    // Resolve controller dynamically
    if (Get.isRegistered<SuperAdminController>()) {
      controller = Get.find<SuperAdminController>();
    } else if (Get.isRegistered<AdminController>()) {
      controller = Get.find<AdminController>();
    }

    _loadUserGroups(_selectedUser);

    ever(availableGroups, (_) => _updateFiltered());
    ever(leftSearchQuery, (_) => _updateFiltered());
    _updateFiltered();
  }

  void _loadUserGroups(Map<String, dynamic> user) {
    final String unit = user['unit'] ?? 'GDDTM';

    final List<String> groupNames = [];
    try {
      if (controller != null && controller.groupList != null) {
        for (var group in controller.groupList) {
          final String name = (group['name'] ?? '').toString();
          if (name.isNotEmpty) {
            groupNames.add(name);
          }
        }
      }
    } catch (e) {
      debugPrint("Could not load groupList from controller: $e");
    }

    if (groupNames.isEmpty) {
      groupNames.addAll([
        'GDDTM Admins',
        'GDDTM Users',
        'GDI Admins',
        'GDI Users',
        'GDP Group',
        'GI Admins',
        'GI Users',
        'GIA Admins',
        'GIA Users',
        'GID Admins',
        'GID Users',
        'GLF Admins',
        'GLF Users',
        'GNP Admins',
        'GNP Users',
        'GS Admins',
        'GS Users',
        'LC Admins',
        'LC Users',
        'PAC Admins',
        'PAC Users',
      ]);
    }

    // Try to extract user groups from the user profile data from the API
    final List<String> assignedFromApi = [];
    if (user['groups'] != null) {
      if (user['groups'] is List) {
        for (var g in user['groups']) {
          if (g is String) {
            final cleaned = g.startsWith('/') ? g.substring(1) : g;
            assignedFromApi.add(cleaned);
          } else if (g is Map && g['name'] != null) {
            assignedFromApi.add(g['name'].toString());
          } else if (g is Map && g['groupName'] != null) {
            assignedFromApi.add(g['groupName'].toString());
          } else if (g is Map && g['code'] != null) {
            final String code = g['code'].toString();
            final matchedGroup = controller.groupList.firstWhereOrNull((cg) => cg['sublabel'] == code);
            if (matchedGroup != null) {
              assignedFromApi.add((matchedGroup['name'] ?? '').toString());
            } else {
              assignedFromApi.add(code);
            }
          }
        }
      }
    }

    final List<String> initialAssigned = [];
    if (assignedFromApi.isNotEmpty) {
      for (var apiGroup in assignedFromApi) {
        final matched = groupNames.firstWhereOrNull(
          (gn) => gn.toLowerCase().trim() == apiGroup.toLowerCase().trim()
        );
        if (matched != null) {
          initialAssigned.add(matched);
        }
      }
    }

    // Fallback if no groups are resolved from the API data:
    if (initialAssigned.isEmpty) {
      initialAssigned.addAll(
        groupNames.where((g) => g.toLowerCase().startsWith(unit.toLowerCase()))
      );
    }

    assignedGroups.assignAll(initialAssigned);
    availableGroups.assignAll(
      groupNames.where((g) => !initialAssigned.contains(g)).toList(),
    );

    leftChecked.clear();
    rightChecked.clear();
  }

  void _updateFiltered() {
    if (leftSearchQuery.value.isEmpty) {
      filteredAvailableGroups.assignAll(availableGroups);
    } else {
      filteredAvailableGroups.assignAll(
        availableGroups
            .where(
              (g) =>
                  g.toLowerCase().contains(leftSearchQuery.value.toLowerCase()),
            )
            .toList(),
      );
    }
  }

  void _onUserChanged(Map<String, dynamic>? newUser) {
    if (newUser != null) {
      setState(() {
        _selectedUser = newUser;
      });
      _loadUserGroups(newUser);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isDesktop = screenWidth > 900;

    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 24),
              _buildUserSelector(),
              const SizedBox(height: 16),
              _buildUserDetailsCard(isDesktop),
              const SizedBox(height: 24),
              _buildTransferMatrix(isDesktop),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
                  onPressed: () => Get.back(),
                ),
                const SizedBox(width: 8),
                Text(
                  'កែសម្រួលក្រុមរបស់អ្នកប្រើ',
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff1E293B),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 44),
              child: Text(
                'គ្រប់គ្រងក្រុម និងសិទ្ធិក្រុមរបស់អ្នកប្រើ។',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  color: const Color(0xff64748B),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildUserSelector() {
    final List<Map<String, dynamic>> users = controller.usersList;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "ជ្រើសរើសគណនីអ្នកប្រើប្រាស់",
            style: GoogleFonts.kantumruyPro(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: const Color(0xff64748B),
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: const Color(0xffF8FAFC),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xffE2E8F0)),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<Map<String, dynamic>>(
                value:
                    users.firstWhereOrNull(
                      (u) => u['username'] == _selectedUser['username'],
                    ) ??
                    _selectedUser,
                isExpanded: true,
                items: users.map((user) {
                  return DropdownMenuItem<Map<String, dynamic>>(
                    value: user,
                    child: Text(
                      "${user['username']} - ${user['email'].isNotEmpty ? user['email'] : 'គ្មានអ៊ីមែល'}",
                      style: GoogleFonts.poppins(fontSize: 13),
                    ),
                  );
                }).toList(),
                onChanged: _onUserChanged,
                dropdownColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserDetailsCard(bool isDesktop) {
    final username = _selectedUser['username'] ?? 'User';
    final email = _selectedUser['email'] ?? '';
    final String status = _selectedUser['status'] ?? 'ACTIVE';
    final String unit = _selectedUser['unit'] ?? 'GDDTM';
    final String uuid =
        _selectedUser['id']?.toString() ??
        '87fad8ed-58d3-4b63-a360-3e557cd3f583';
    final bool isActive = status.toUpperCase() == 'ACTIVE';

    final initial = username.isNotEmpty
        ? username.substring(0, username.length > 2 ? 2 : 1).toUpperCase()
        : 'U';

    Widget profileSection = Row(
      children: [
        CircleAvatar(
          radius: 36,
          backgroundColor: const Color(0xffEFF6FF),
          child: Text(
            initial,
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              color: const Color(0xff2563EB),
              fontSize: 22,
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    username,
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff0F172A),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: isActive
                          ? const Color(0xffECFDF5)
                          : const Color(0xffFEE2E2),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isActive
                            ? const Color(0xffA7F3D0)
                            : const Color(0xffFCA5A5),
                        width: 0.5,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: isActive
                                ? const Color(0xff10B981)
                                : const Color(0xffEF4444),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          isActive ? "ដំណើរការ" : "ផ្អាក",
                          style: GoogleFonts.kantumruyPro(
                            fontSize: 10,
                            color: isActive
                                ? const Color(0xff047857)
                                : const Color(0xffB91C1C),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  const Icon(
                    Icons.mail_outline_rounded,
                    size: 14,
                    color: Colors.grey,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    email.isNotEmpty ? email : "—",
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  const Icon(
                    Icons.phone_outlined,
                    size: 14,
                    color: Colors.grey,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "—",
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );

    Widget infoTable = Table(
      columnWidths: const {0: IntrinsicColumnWidth(), 1: FlexColumnWidth()},
      children: [
        _buildTableRow("លេខសម្គាល់អ្នកប្រើប្រាស់", uuid, isUuid: true),
        _buildTableRow("នាយកដ្ឋាន", unit),
        _buildTableRow("មុខតំណែង", "—"),
      ],
    );

    Widget datesTable = Table(
      columnWidths: const {0: IntrinsicColumnWidth(), 1: FlexColumnWidth()},
      children: [
        _buildTableRow("កាលបរិច្ឆេទបង្កើត", "—"),
        _buildTableRow("ស្រាវជ្រាវចុងក្រោយ", "—"),
        _buildTableRow("ប្រភេទ", isActive ? "ដំណើរការ" : "ផ្អាក"),
      ],
    );

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: isDesktop
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 3, child: profileSection),
                const SizedBox(width: 24),
                Expanded(flex: 4, child: infoTable),
                const SizedBox(width: 24),
                Expanded(flex: 3, child: datesTable),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                profileSection,
                const SizedBox(height: 20),
                const Divider(color: Color(0xffE2E8F0)),
                const SizedBox(height: 12),
                infoTable,
                const SizedBox(height: 12),
                datesTable,
              ],
            ),
    );
  }

  TableRow _buildTableRow(String label, String value, {bool isUuid = false}) {
    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
          child: Text(
            label,
            style: GoogleFonts.kantumruyPro(fontSize: 12, color: Colors.grey),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
          child: Text(
            value,
            style: isUuid
                ? GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff0F172A),
                  )
                : GoogleFonts.kantumruyPro(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff0F172A),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildTransferMatrix(bool isDesktop) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.group_add_outlined,
                color: Color(0xffE29D11),
                size: 20,
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "កំណត់ក្រុមអ្នកប្រើប្រាស់",
                    style: GoogleFonts.kantumruyPro(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: const Color(0xff0F172A),
                    ),
                  ),
                  Text(
                    "ភ្ជាប់គណនីអ្នកប្រើប្រាស់ ទៅនឹងសិទ្ធិក្រុមផ្សេងៗ។",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 11,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          Obx(() {
            Widget leftColumn = _buildAvailableColumn();
            Widget rightColumn = _buildAssignedColumn();
            Widget middleButtons = _buildTransferButtons(isDesktop);

            return isDesktop
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(child: leftColumn),
                      middleButtons,
                      Expanded(child: rightColumn),
                    ],
                  )
                : Column(
                    children: [
                      leftColumn,
                      const SizedBox(height: 12),
                      middleButtons,
                      const SizedBox(height: 12),
                      rightColumn,
                    ],
                  );
          }),
          const SizedBox(height: 24),
          _buildActionRow(),
        ],
      ),
    );
  }

  Widget _buildAvailableColumn() {
    return Container(
      height: 400,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              "ក្រុមដែលអាចជ្រើសរើស (${availableGroups.length})",
              style: GoogleFonts.kantumruyPro(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: const Color(0xff0F172A),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: TextField(
              onChanged: (val) => leftSearchQuery.value = val,
              decoration: InputDecoration(
                hintText: "ស្វែងរកក្រុម...",
                hintStyle: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  color: Colors.grey,
                ),
                prefixIcon: const Icon(
                  Icons.search_rounded,
                  size: 16,
                  color: Colors.grey,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                filled: true,
                fillColor: const Color(0xffF8FAFC),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Color(0xffE2E8F0)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Color(0xffE2E8F0)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: filteredAvailableGroups.isEmpty
                ? Center(
                    child: Text(
                      "គ្មានក្រុមដែលអាចជ្រើសរើសឡើយ",
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 11,
                        color: Colors.grey,
                      ),
                    ),
                  )
                : ListView.builder(
                    itemCount: filteredAvailableGroups.length,
                    itemBuilder: (context, idx) {
                      final group = filteredAvailableGroups[idx];
                      final isChecked = leftChecked.contains(group);
                      return CheckboxListTile(
                        title: Text(
                          group,
                          style: GoogleFonts.poppins(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          group.split(" ").first,
                          style: GoogleFonts.poppins(
                            fontSize: 9,
                            color: Colors.grey,
                          ),
                        ),
                        value: isChecked,
                        dense: true,
                        controlAffinity: ListTileControlAffinity.leading,
                        onChanged: (val) {
                          if (val == true) {
                            leftChecked.add(group);
                          } else {
                            leftChecked.remove(group);
                          }
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildAssignedColumn() {
    return Container(
      height: 400,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              "ក្រុមដែលបានកំណត់ (${assignedGroups.length})",
              style: GoogleFonts.kantumruyPro(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: const Color(0xff0F172A),
              ),
            ),
          ),
          const SizedBox(
            height: 38,
          ), // space to match left side height with textfield
          Expanded(
            child: assignedGroups.isEmpty
                ? Center(
                    child: Text(
                      "មិនទាន់មានការកំណត់ក្រុម",
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 11,
                        color: Colors.grey,
                      ),
                    ),
                  )
                : ListView.builder(
                    itemCount: assignedGroups.length,
                    itemBuilder: (context, idx) {
                      final group = assignedGroups[idx];
                      final isChecked = rightChecked.contains(group);
                      return CheckboxListTile(
                        title: Text(
                          group,
                          style: GoogleFonts.poppins(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          group.split(" ").first,
                          style: GoogleFonts.poppins(
                            fontSize: 9,
                            color: Colors.grey,
                          ),
                        ),
                        value: isChecked,
                        dense: true,
                        controlAffinity: ListTileControlAffinity.leading,
                        onChanged: (val) {
                          if (val == true) {
                            rightChecked.add(group);
                          } else {
                            rightChecked.remove(group);
                          }
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransferButtons(bool isDesktop) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: isDesktop ? 12 : 0,
        vertical: isDesktop ? 0 : 8,
      ),
      child: isDesktop
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(
                    Icons.chevron_right_rounded,
                    color: Color(0xffE29D11),
                    size: 28,
                  ),
                  onPressed: leftChecked.isEmpty
                      ? null
                      : () {
                          assignedGroups.addAll(leftChecked);
                          availableGroups.removeWhere(
                            (g) => leftChecked.contains(g),
                          );
                          leftChecked.clear();
                        },
                ),
                const SizedBox(height: 12),
                IconButton(
                  icon: const Icon(
                    Icons.chevron_left_rounded,
                    color: Color(0xffE29D11),
                    size: 28,
                  ),
                  onPressed: rightChecked.isEmpty
                      ? null
                      : () {
                          availableGroups.addAll(rightChecked);
                          assignedGroups.removeWhere(
                            (g) => rightChecked.contains(g),
                          );
                          rightChecked.clear();
                        },
                ),
              ],
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: Color(0xffE29D11),
                    size: 28,
                  ),
                  onPressed: leftChecked.isEmpty
                      ? null
                      : () {
                          assignedGroups.addAll(leftChecked);
                          availableGroups.removeWhere(
                            (g) => leftChecked.contains(g),
                          );
                          leftChecked.clear();
                        },
                ),
                const SizedBox(width: 24),
                IconButton(
                  icon: const Icon(
                    Icons.keyboard_arrow_up_rounded,
                    color: Color(0xffE29D11),
                    size: 28,
                  ),
                  onPressed: rightChecked.isEmpty
                      ? null
                      : () {
                          availableGroups.addAll(rightChecked);
                          assignedGroups.removeWhere(
                            (g) => rightChecked.contains(g),
                          );
                          rightChecked.clear();
                        },
                ),
              ],
            ),
    );
  }

  Widget _buildActionRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        OutlinedButton(
          style: OutlinedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            side: const BorderSide(color: Color(0xffCBD5E1)),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
          onPressed: () => Get.back(),
          child: Text(
            "បោះបង់",
            style: GoogleFonts.kantumruyPro(
              fontSize: 13,
              color: const Color(0xff64748B),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(width: 12),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xffE29D11),
            foregroundColor: Colors.white,
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            minimumSize: const Size(0, 0),
          ),
          onPressed: () async {
            final String username =
                _selectedUser['username'] ?? _selectedUser['name'] ?? '';
            await controller.assignGroupsToUser(
              username,
              assignedGroups.toList(),
            );
            CustomSnackbar.showSuccess(
              message: "បានរក្សាទុកការភ្ជាប់ក្រុមសម្រាប់ $username ដោយជោគជ័យ!",
            );
            Get.back();
          },
          child: Text(
            "រក្សាទុកការភ្ជាប់ក្រុម",
            style: GoogleFonts.kantumruyPro(
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
