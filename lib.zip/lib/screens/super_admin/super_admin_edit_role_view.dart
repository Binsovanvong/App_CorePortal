import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:core_portal/screens/super_admin/super_admin_controller.dart';
import 'package:core_portal/widgets/custom_snackbar.dart';

class SuperAdminEditRoleView extends StatefulWidget {
  final Map<String, dynamic> role;

  const SuperAdminEditRoleView({super.key, required this.role});

  @override
  State<SuperAdminEditRoleView> createState() => _SuperAdminEditRoleViewState();
}

class _SuperAdminEditRoleViewState extends State<SuperAdminEditRoleView> {
  final SuperAdminController controller = Get.find<SuperAdminController>();

  late TextEditingController _nameCtrl;
  late String _code;
  late String _status;

  // Permission levels (0 = No, 1 = View, 2 = Edit, 3 = Manage)
  int auditLevel = 3;
  int permissionLevel = 1;
  int roleLevel = 1;
  int userLevel = 3;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.role['name'] ?? '');
    _code = widget.role['code'] ?? '';
    _status = (widget.role['status'] ?? 'ACTIVE').toString().toUpperCase();

    // Dynamically set based on fallback or live counts
    // Let's seed initial level values for mockup display matching the role code
    if (_code == 'GENERAL_DEPARTMENT_ADMIN') {
      auditLevel = 3; // Manage
      permissionLevel = 1; // View
      roleLevel = 1; // View
      userLevel = 3; // Manage
    } else if (_code == 'PORTAL_SUPER_ADMIN') {
      auditLevel = 3;
      permissionLevel = 3;
      roleLevel = 3;
      userLevel = 3;
    } else if (_code == 'PORTAL_ADMIN') {
      auditLevel = 2; // Edit
      permissionLevel = 2;
      roleLevel = 1;
      userLevel = 2;
    } else if (_code == 'PORTAL_USER') {
      auditLevel = 1; // View
      permissionLevel = 0; // No
      roleLevel = 0;
      userLevel = 1;
    } else {
      auditLevel = 1;
      permissionLevel = 1;
      roleLevel = 1;
      userLevel = 1;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  int getSelectedPermissionsCount() {
    int count = 0;
    // Audit Log (1 total)
    count += (auditLevel == 0 ? 0 : 1);
    // Permission (2 total)
    count += (permissionLevel == 0 ? 0 : (permissionLevel == 3 ? 2 : 1));
    // Role (4 total)
    count += (roleLevel == 0 ? 0 : (roleLevel == 1 ? 1 : (roleLevel == 2 ? 2 : 4)));
    // User (5 total)
    count += (userLevel == 0 ? 0 : (userLevel == 1 ? 1 : (userLevel == 2 ? 3 : 5)));
    return count;
  }

  void _selectAllPermissions() {
    setState(() {
      auditLevel = 3;
      permissionLevel = 3;
      roleLevel = 3;
      userLevel = 3;
    });
  }

  void _saveRole() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      CustomSnackbar.showError(message: 'សូមបំពេញឈ្មោះតួនាទី');
      return;
    }

    // Call update on the controller
    controller.updateRoleByCode(_code, name, _code, _status);
    Get.back();
    CustomSnackbar.showSuccess(message: 'បានកែប្រែតួនាទីដោយជោគជ័យ!');
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isWideLayout = screenWidth > 950;

    return Scaffold(
      backgroundColor: const Color(0xffF8FAFC),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Header Row
              _buildHeader(),
              const SizedBox(height: 24),

              // Main Body Columns (Side-by-side or Stacked)
              isWideLayout
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width: 320, child: _buildLeftColumn()),
                        const SizedBox(width: 24),
                        Expanded(child: _buildRightColumn()),
                      ],
                    )
                  : Column(
                      children: [
                        _buildLeftColumn(),
                        const SizedBox(height: 24),
                        _buildRightColumn(),
                      ],
                    ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
              onPressed: () => Get.back(),
            ),
            const SizedBox(width: 8),
            Text(
              'កែប្រែតួនាទី',
              style: GoogleFonts.kantumruyPro(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: const Color(0xff1E293B),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(left: 44),
          child: Text(
            'គ្រប់គ្រងតួនាទី និងសិទ្ធិក្នុងប្រព័ន្ធ។',
            style: GoogleFonts.kantumruyPro(
              fontSize: 12,
              color: const Color(0xff64748B),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLeftColumn() {
    final bool isActive = _status == 'ACTIVE';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Card 1: 01 ព័ត៌មានតួនាទី
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xffE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    '01 ',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xffE29D11),
                    ),
                  ),
                  Text(
                    'ព័ត៌មានតួនាទី',
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff1E293B),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                'ឈ្មោះតួនាទី',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  color: const Color(0xff64748B),
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _nameCtrl,
                style: GoogleFonts.kantumruyPro(fontSize: 13, fontWeight: FontWeight.bold),
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xffE2E8F0)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xffE2E8F0)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xffE29D11)),
                  ),
                  fillColor: const Color(0xffF8FAFC),
                  filled: true,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'ស្ថានភាព',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  color: const Color(0xff64748B),
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  // Active Button
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _status = 'ACTIVE';
                        });
                      },
                      child: Container(
                        height: 44,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: isActive ? const Color(0xffECFDF5) : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isActive ? const Color(0xff10B981) : const Color(0xffE2E8F0),
                            width: 1.5,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: isActive ? const Color(0xff10B981) : const Color(0xff94A3B8),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'ដំណើរការ',
                              style: GoogleFonts.kantumruyPro(
                                fontSize: 13,
                                color: isActive ? const Color(0xff047857) : const Color(0xff64748B),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Inactive Button
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _status = 'INACTIVE';
                        });
                      },
                      child: Container(
                        height: 44,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: !isActive ? const Color(0xffF8FAFC) : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: !isActive ? const Color(0xff64748B) : const Color(0xffE2E8F0),
                            width: 1.5,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xff64748B),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'ផ្អាក',
                              style: GoogleFonts.kantumruyPro(
                                fontSize: 13,
                                color: const Color(0xff64748B),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Card 2: សង្ខេបតួនាទី
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xffE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'សង្ខេបតួនាទី',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff1E293B),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(
                      color: Color(0xffECFDF5),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.vpn_key_outlined,
                      color: Color(0xff10B981),
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'សិទ្ធិដែលបានកំណត់',
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 12,
                          color: const Color(0xff64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Text(
                            '${getSelectedPermissionsCount()} ',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xff1E293B),
                            ),
                          ),
                          Text(
                            'បានជ្រើសរើស',
                            style: GoogleFonts.kantumruyPro(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xff64748B),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),

        // Action Buttons: Save & Back
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  side: const BorderSide(color: Color(0xffCBD5E1)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () => Get.back(),
                child: Text(
                  'បោះបង់',
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 14,
                    color: const Color(0xff64748B),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xffE29D11),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: _saveRole,
                child: Text(
                  'រក្សាទុក',
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRightColumn() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Subtitle and Select All Action
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        '02 ',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xffE29D11),
                        ),
                      ),
                      Text(
                        'កំណត់សិទ្ធិ',
                        style: GoogleFonts.kantumruyPro(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xff1E293B),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ជ្រើសរើសកម្រិតចូលប្រើសម្រាប់ម៉ូឌុលនីមួយៗ។',
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 12,
                      color: const Color(0xff64748B),
                    ),
                  ),
                ],
              ),
              GestureDetector(
                onTap: _selectAllPermissions,
                child: Row(
                  children: [
                    const Icon(Icons.check_rounded, size: 16, color: Color(0xffE29D11)),
                    const SizedBox(width: 4),
                    Text(
                      'ជ្រើសរើសទាំងអស់',
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xffE29D11),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Table Headers Row
          _buildTableHeaderRow(),
          const Divider(height: 1, color: Color(0xffEDF2F7)),

          // Rows
          _buildPermissionRow('AUDIT LOG', '1 សិទ្ធិ (សរុប)', auditLevel, (val) {
            setState(() => auditLevel = val);
          }),
          _buildPermissionRow('PERMISSION', '2 សិទ្ធិ (សរុប)', permissionLevel, (val) {
            setState(() => permissionLevel = val);
          }),
          _buildPermissionRow('ROLE', '4 សិទ្ធិ (សរុប)', roleLevel, (val) {
            setState(() => roleLevel = val);
          }),
          _buildPermissionRow('USER', '5 សិទ្ធិ (សរុប)', userLevel, (val) {
            setState(() => userLevel = val);
          }),
        ],
      ),
    );
  }

  Widget _buildTableHeaderRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              'សិទ្ធិ',
              style: GoogleFonts.kantumruyPro(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: const Color(0xff64748B),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Center(
              child: Text(
                'គ្មានសិទ្ធិ',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff64748B),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Center(
              child: Text(
                'មើល',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff64748B),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Center(
              child: Text(
                'កែប្រែ',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff64748B),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Center(
              child: Text(
                'គ្រប់គ្រង',
                style: GoogleFonts.kantumruyPro(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff64748B),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPermissionRow(String title, String subtitle, int currentLevel, Function(int) onChange) {
    return Container(
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xffEDF2F7))),
      ),
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Row(
        children: [
          // Module text description
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff1E293B),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 10,
                    color: const Color(0xff94A3B8),
                  ),
                ),
              ],
            ),
          ),
          // level 0: គ្មានសិទ្ធិ
          Expanded(
            flex: 2,
            child: Center(
              child: _buildRadioButton(currentLevel == 0, () => onChange(0)),
            ),
          ),
          // level 1: មើល
          Expanded(
            flex: 2,
            child: Center(
              child: _buildRadioButton(currentLevel == 1, () => onChange(1)),
            ),
          ),
          // level 2: កែប្រែ
          Expanded(
            flex: 2,
            child: Center(
              child: _buildRadioButton(currentLevel == 2, () => onChange(2)),
            ),
          ),
          // level 3: គ្រប់គ្រង
          Expanded(
            flex: 2,
            child: Center(
              child: _buildRadioButton(currentLevel == 3, () => onChange(3)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRadioButton(bool selected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 18,
        height: 18,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: selected ? const Color(0xffE29D11) : const Color(0xffCBD5E1),
            width: 2,
          ),
        ),
        padding: const EdgeInsets.all(3),
        child: selected
            ? Container(
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xffE29D11),
                ),
              )
            : null,
      ),
    );
  }
}
