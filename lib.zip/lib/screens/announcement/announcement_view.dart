import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:core_portal/screens/announcement/announcement_controller.dart';

class AnnouncementView extends GetView<AnnouncementController> {
  const AnnouncementView({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isAdmin = Get.arguments == 'admin';
    final TextEditingController searchController = TextEditingController(
      text: controller.searchQuery.value,
    );

    return Scaffold(
      backgroundColor: const Color(0xffF5F6F8),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(context, isAdmin),
            Expanded(
              child: isAdmin
                  ? _buildAdminBody(context, searchController)
                  : _buildUserBody(context),
            ),
          ],
        ),
      ),
    );
  }

  // --- Header Layout ---
  Widget _buildHeader(BuildContext context, bool isAdmin) {
    final bool canPop = Navigator.of(context).canPop();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: Border(
          bottom: BorderSide(
            color: const Color(0xffD4AF37).withOpacity(0.15),
            width: 1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          if (canPop) ...[
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: const Color(0xffFCFAF3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xffE9D8A6).withOpacity(0.5),
                  width: 1,
                ),
              ),
              child: IconButton(
                onPressed: () => Get.back(),
                icon: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  size: 16,
                  color: Color(0xff8A6514),
                ),
                padding: EdgeInsets.zero,
              ),
            ),
            const SizedBox(width: 14),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "សេចក្តីប្រកាស",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff8A6514),
                  ),
                ),
                if (isAdmin)
                  Text(
                    "បញ្ជីសេចក្តីប្រកាសទាំងអស់",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                    ),
                  ),
              ],
            ),
          ),
          if (isAdmin) ...[
            const SizedBox(width: 12),
            ElevatedButton.icon(
              onPressed: () => _showAddEditAnnouncementDialog(context),
              icon: const Icon(Icons.add_rounded, size: 18),
              label: Text(
                "បង្កើតថ្មី",
                style: GoogleFonts.kantumruyPro(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(0, 0),
                backgroundColor: const Color(0xff8A6514),
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // --- Category Chip Widget ---
  Widget _buildCustomChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xff8A6514) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? const Color(0xff8A6514) : Colors.grey.shade200,
            width: 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: const Color(0xff8A6514).withOpacity(0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.01),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Text(
          label,
          style: GoogleFonts.kantumruyPro(
            color: isSelected ? Colors.white : Colors.grey.shade700,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  // --- Category Horizontal List ---
  Widget _buildCategoryChips() {
    final categories = [
      "ប្រភេទទាំងអស់",
      "បន្ទាន់",
      "គោលការណ៍",
      "ព្រឹត្តិការណ៍",
      "ទូទៅ",
    ];
    return Obx(() {
      final selectedCategory = controller.selectedCategory.value;
      return Container(
        height: 48,
        margin: const EdgeInsets.only(top: 16, bottom: 8),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: categories.length,
          itemBuilder: (context, index) {
            final category = categories[index];
            final isSelected = selectedCategory == category;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: _buildCustomChip(
                label: category,
                isSelected: isSelected,
                onTap: () => controller.selectedCategory.value = category,
              ),
            );
          },
        ),
      );
    });
  }

  // --- Status Horizontal List ---
  Widget _buildStatusChips() {
    final statuses = ["ស្ថានភាពទាំងអស់", "ផ្សព្វផ្សាយ", "ព្រាង"];
    return Obx(() {
      final selectedStatus = controller.selectedStatus.value;
      return Container(
        height: 38,
        margin: const EdgeInsets.only(bottom: 12),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: statuses.length,
          itemBuilder: (context, index) {
            final status = statuses[index];
            final isSelected = selectedStatus == status;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () => controller.selectedStatus.value = status,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? const Color(0xffFCFAF3)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isSelected
                          ? const Color(0xffE9D8A6).withOpacity(0.5)
                          : Colors.grey.shade300,
                      width: 1,
                    ),
                  ),
                  child: Text(
                    status,
                    style: GoogleFonts.kantumruyPro(
                      color: isSelected
                          ? const Color(0xff8A6514)
                          : Colors.grey.shade600,
                      fontWeight: isSelected
                          ? FontWeight.bold
                          : FontWeight.normal,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      );
    });
  }

  // --- Normal User Body Layout ---
  Widget _buildUserBody(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () => controller.fetchAnnouncements(),
      color: const Color(0xff8A6514),
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          children: [
            _buildCategoryChips(),
            _buildStatusChips(),

            // List View of Announcements
            Obx(() {
              if (controller.isLoading.value) {
                return const SizedBox(
                  height: 200,
                  child: Center(
                    child: CircularProgressIndicator(color: Color(0xff8A6514)),
                  ),
                );
              }

              if (controller.errorMessage.value.isNotEmpty) {
                return _buildErrorState();
              }

              final paginatedList = controller.paginatedAnnouncements;
              if (paginatedList.isEmpty) {
                return _buildEmptyState();
              }

              return Column(
                children: [
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.only(
                      left: 16,
                      right: 16,
                      bottom: 20,
                    ),
                    itemCount: paginatedList.length,
                    itemBuilder: (context, index) {
                      final announcement = paginatedList[index];
                      if (index == 0 && controller.currentPage.value == 1) {
                        return _buildFeaturedCard(context, announcement);
                      }

                      final String category =
                          announcement['category']?.toString() ?? 'OFFICIAL';
                      final String title =
                          announcement['title']?.toString() ??
                          announcement['titleEn']?.toString() ??
                          'គ្មានចំណងជើង';
                      final String time =
                          announcement['createdAt']?.toString() ??
                          announcement['time']?.toString() ??
                          '';

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: _newsCard(
                          category: category.toUpperCase(),
                          title: title,
                          time: _formatKhmerDate(time, short: true),
                          onTap: () =>
                              _showAnnouncementDialog(context, announcement),
                        ),
                      );
                    },
                  ),
                  _buildPaginationControls(),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  // --- Admin Body Layout (Mobile App Design) ---
  Widget _buildAdminBody(
    BuildContext context,
    TextEditingController searchController,
  ) {
    return RefreshIndicator(
      onRefresh: () => controller.fetchAdminAnnouncements(),
      color: const Color(0xff8A6514),
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          children: [
            _buildStatsCardsRow(),
            // Search & Filters Row
            Container(
              margin: const EdgeInsets.only(left: 16, right: 16, top: 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.02),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Search Input
                  TextField(
                    controller: searchController,
                    onChanged: (val) => controller.searchQuery.value = val,
                    style: GoogleFonts.kantumruyPro(fontSize: 14),
                    decoration: InputDecoration(
                      hintText: "ស្វែងរកសេចក្តីប្រកាស...",
                      hintStyle: GoogleFonts.kantumruyPro(
                        color: Colors.grey,
                        fontSize: 14,
                      ),
                      prefixIcon: const Icon(
                        Icons.search_rounded,
                        color: Colors.grey,
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 12),
                      filled: true,
                      fillColor: const Color(0xffF8FAFC),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide(color: Colors.grey.shade200),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xff8A6514)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Dropdowns
                  Row(
                    children: [
                      Expanded(
                        child: Obx(
                          () => _buildCustomDropdown(
                            label: "ប្រភេទ",
                            value: controller.selectedCategory.value,
                            items: const [
                              "ប្រភេទទាំងអស់",
                              "បន្ទាន់",
                              "គោលការណ៍",
                              "ព្រឹត្តិការណ៍",
                              "ទូទៅ",
                            ],
                            onChanged: (val) {
                              if (val != null) {
                                controller.selectedCategory.value = val;
                              }
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Obx(
                          () => _buildCustomDropdown(
                            label: "ស្ថានភាព",
                            value: controller.selectedStatus.value,
                            items: const [
                              "ស្ថានភាពទាំងអស់",
                              "ផ្សព្វផ្សាយ",
                              "ព្រាង",
                            ],
                            onChanged: (val) {
                              if (val != null) {
                                controller.selectedStatus.value = val;
                              }
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  // Date range pickers
                  Row(
                    children: [
                      Expanded(
                        child: Obx(
                          () => _buildDatePickerField(
                            context,
                            label: "ចាប់ផ្តើម",
                            selectedDate: controller.startDate.value,
                            onTap: () async {
                              final picked = await showDatePicker(
                                context: context,
                                initialDate:
                                    controller.startDate.value ??
                                    DateTime.now(),
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2100),
                              );
                              if (picked != null) {
                                controller.startDate.value = picked;
                              }
                            },
                          ),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 8, right: 8, top: 22),
                        child: Text(
                          "→",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Obx(
                          () => _buildDatePickerField(
                            context,
                            label: "បញ្ចប់",
                            selectedDate: controller.endDate.value,
                            onTap: () async {
                              final picked = await showDatePicker(
                                context: context,
                                initialDate:
                                    controller.endDate.value ?? DateTime.now(),
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2100),
                              );
                              if (picked != null) {
                                controller.endDate.value = picked;
                              }
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                  // Clear filters button
                  Obx(() {
                    final hasFilter =
                        controller.searchQuery.value.isNotEmpty ||
                        controller.selectedCategory.value != "ប្រភេទទាំងអស់" ||
                        controller.selectedStatus.value != "ស្ថានភាពទាំងអស់" ||
                        controller.startDate.value != null ||
                        controller.endDate.value != null;
                    if (!hasFilter) return const SizedBox.shrink();

                    return Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () {
                            controller.clearFilters();
                            searchController.clear();
                          },
                          icon: const Icon(
                            Icons.close_rounded,
                            size: 16,
                            color: Colors.red,
                          ),
                          label: Text(
                            "សម្អាតតម្រង",
                            style: GoogleFonts.kantumruyPro(
                              color: Colors.red,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
            const SizedBox(height: 8),

            // List View of Announcements for Admin
            Obx(() {
              if (controller.isLoading.value) {
                return const SizedBox(
                  height: 200,
                  child: Center(
                    child: CircularProgressIndicator(color: Color(0xff8A6514)),
                  ),
                );
              }

              if (controller.errorMessage.value.isNotEmpty) {
                return _buildErrorState();
              }

              final paginatedList = controller.paginatedAnnouncements;
              if (paginatedList.isEmpty) {
                return _buildEmptyState();
              }

              return Column(
                children: [
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    itemCount: paginatedList.length,
                    itemBuilder: (context, index) {
                      final announcement = paginatedList[index];
                      final globalIndex =
                          (controller.currentPage.value - 1) *
                              controller.itemsPerPage +
                          index +
                          1;
                      return _buildAdminAnnouncementCard(
                        context,
                        globalIndex,
                        announcement,
                      );
                    },
                  ),
                  _buildPaginationControls(),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  // --- Admin Announcement Card (Mobile App Design) ---
  Widget _buildAdminAnnouncementCard(
    BuildContext context,
    int index,
    Map<String, dynamic> announcement,
  ) {
    final String title =
        announcement['title']?.toString() ??
        announcement['titleEn']?.toString() ??
        'គ្មានចំណងជើង';
    final String content =
        announcement['content']?.toString() ??
        announcement['body']?.toString() ??
        '';
    final String cleanContent = content
        .replaceAll(RegExp(r'<[^>]*>|&nbsp;'), ' ')
        .trim();
    final String category = (announcement['category'] ??
            announcement['priority'] ??
            'GENERAL')
        .toString()
        .toUpperCase();
    final String status = (announcement['status'] ?? 'DRAFT')
        .toString()
        .toUpperCase();
    final String time = announcement['createdAt']?.toString() ?? '';

    // Category style
    Color categoryBgColor = const Color(0xffCCFBF1);
    Color categoryTextColor = const Color(0xff0D9488);
    String khmerCategory = "ទូទៅ";

    if (category == 'URGENT' || category == 'IMPORTANT') {
      categoryBgColor = const Color(0xffFEE2E2);
      categoryTextColor = const Color(0xffEF4444);
      khmerCategory = "បន្ទាន់";
    } else if (category == 'POLICY') {
      categoryBgColor = const Color(0xffF3E8FF);
      categoryTextColor = const Color(0xff9333EA);
      khmerCategory = "គោលការណ៍";
    } else if (category == 'EVENT') {
      categoryBgColor = const Color(0xffFEF3C7);
      categoryTextColor = const Color(0xffD97706);
      khmerCategory = "ព្រឹត្តិការណ៍";
    }

    // Status style
    Color statusBgColor = const Color(0xffF1F5F9);
    Color statusTextColor = const Color(0xff64748B);
    String khmerStatus = "ព្រាង";

    if (status == 'PUBLISHED' || status == 'ACTIVE') {
      statusBgColor = const Color(0xffDCFCE7);
      statusTextColor = const Color(0xff16A34A);
      khmerStatus = "ផ្សព្វផ្សាយ";
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Index, Category & Status Top Row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            child: Row(
              children: [
                // Index
                Text(
                  "ល.រ $index",
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade700,
                  ),
                ),
                const Spacer(),
                // Category Chip
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: categoryBgColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    khmerCategory,
                    style: GoogleFonts.kantumruyPro(
                      color: categoryTextColor,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Status Chip
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: statusBgColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    khmerStatus,
                    style: GoogleFonts.kantumruyPro(
                      color: statusTextColor,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Title & Body
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff0F172A),
                  ),
                ),
                if (cleanContent.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(
                    cleanContent,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 13,
                      color: Colors.grey.shade600,
                      height: 1.4,
                    ),
                  ),
                ],
              ],
            ),
          ),

          const Divider(height: 1, color: Color(0xffF1F5F9)),

          // Date & Actions Row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Date
                Text(
                  _formatKhmerDate(time, short: true),
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 12,
                    color: Colors.grey.shade500,
                  ),
                ),
                // Action Buttons
                Row(
                  children: [
                    // View Button
                    _buildAdminActionButton(
                      icon: Icons.visibility_rounded,
                      color: const Color(0xff8A6514),
                      onTap: () =>
                          _showAnnouncementDialog(context, announcement),
                    ),
                    const SizedBox(width: 10),
                    // Edit Button
                    _buildAdminActionButton(
                      icon: Icons.edit_rounded,
                      color: const Color(0xffD97706),
                      onTap: () => _showAddEditAnnouncementDialog(
                        context,
                        announcement: announcement,
                      ),
                    ),
                    const SizedBox(width: 10),
                    // Delete Button
                    _buildAdminActionButton(
                      icon: Icons.delete_rounded,
                      color: const Color(0xffEF4444),
                      onTap: () =>
                          _showConfirmDeleteDialog(context, announcement),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdminActionButton({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        shape: BoxShape.circle,
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(icon, size: 16, color: color),
        padding: EdgeInsets.zero,
      ),
    );
  }

  // --- Add / Edit Announcement Dialog (Mobile Form) ---
  void _showAddEditAnnouncementDialog(
    BuildContext context, {
    Map<String, dynamic>? announcement,
  }) {
    final bool isEdit = announcement != null;
    final titleCtrl = TextEditingController(
      text: announcement != null
          ? (announcement['title'] ?? announcement['titleEn'] ?? '').toString()
          : '',
    );
    final contentCtrl = TextEditingController(
      text: announcement != null
          ? (announcement['content'] ?? announcement['body'] ?? '').toString()
          : '',
    );

    // Initial category mapping
    String selectedCat = "ទូទៅ";
    if (isEdit) {
      final cat = (announcement['category'] ?? announcement['priority'] ?? '')
          .toString()
          .toUpperCase();
      if (cat == 'URGENT' || cat == 'IMPORTANT') {
        selectedCat = "បន្ទាន់";
      } else if (cat == 'POLICY') {
        selectedCat = "គោលការណ៍";
      } else if (cat == 'EVENT') {
        selectedCat = "ព្រឹត្តិការណ៍";
      }
    }

    // Initial status mapping
    String selectedStat = "ផ្សព្វផ្សាយ";
    if (isEdit) {
      final stat = (announcement['status'] ?? '').toString().toUpperCase();
      if (stat == 'DRAFT' || stat == 'INACTIVE') {
        selectedStat = "ព្រាង";
      }
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          backgroundColor: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title Header
                  Text(
                    isEdit
                        ? "កែសម្រួលសេចក្តីប្រកាស"
                        : "បង្កើតសេចក្តីប្រកាសថ្មី",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff0F172A),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Title Text Field
                  Text(
                    "ចំណងជើង *",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff0F172A),
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextField(
                    controller: titleCtrl,
                    style: GoogleFonts.kantumruyPro(fontSize: 14),
                    decoration: InputDecoration(
                      hintText: "បញ្ចូលចំណងជើង...",
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(
                          color: Color(0xff8A6514),
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Category & Status dropdown fields side-by-side
                  Row(
                    children: [
                      // Category
                      Expanded(
                        child: StatefulBuilder(
                          builder: (context, setState) {
                            return DropdownButtonFormField<String>(
                              value: selectedCat,
                              items:
                                  const [
                                        "បន្ទាន់",
                                        "គោលការណ៍",
                                        "ព្រឹត្តិការណ៍",
                                        "ទូទៅ",
                                      ]
                                      .map(
                                        (item) => DropdownMenuItem(
                                          value: item,
                                          child: Text(item),
                                        ),
                                      )
                                      .toList(),
                              onChanged: (val) {
                                if (val != null) {
                                  setState(() => selectedCat = val);
                                }
                              },
                              style: GoogleFonts.kantumruyPro(
                                fontSize: 13,
                                color: const Color(0xff0F172A),
                              ),
                              decoration: InputDecoration(
                                labelText: "ប្រភេទ *",
                                labelStyle: GoogleFonts.kantumruyPro(
                                  fontSize: 12,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: BorderSide(
                                    color: Colors.grey.shade300,
                                  ),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      // Status
                      Expanded(
                        child: StatefulBuilder(
                          builder: (context, setState) {
                            return DropdownButtonFormField<String>(
                              value: selectedStat,
                              items: const ["ផ្សព្វផ្សាយ", "ព្រាង"]
                                  .map(
                                    (item) => DropdownMenuItem(
                                      value: item,
                                      child: Text(item),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (val) {
                                if (val != null) {
                                  setState(() => selectedStat = val);
                                }
                              },
                              style: GoogleFonts.kantumruyPro(
                                fontSize: 13,
                                color: const Color(0xff0F172A),
                              ),
                              decoration: InputDecoration(
                                labelText: "ស្ថានភាព *",
                                labelStyle: GoogleFonts.kantumruyPro(
                                  fontSize: 12,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  borderSide: BorderSide(
                                    color: Colors.grey.shade300,
                                  ),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Content Field
                  Text(
                    "ខ្លឹមសារ *",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xff0F172A),
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextField(
                    controller: contentCtrl,
                    maxLines: 4,
                    style: GoogleFonts.kantumruyPro(fontSize: 14),
                    decoration: InputDecoration(
                      hintText: "បញ្ចូលខ្លឹមសារសេចក្តីប្រកាស...",
                      contentPadding: const EdgeInsets.all(16),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(
                          color: Color(0xff8A6514),
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Actions Cancel / Save
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      // Cancel
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          "បោះបង់",
                          style: GoogleFonts.kantumruyPro(
                            color: Colors.grey.shade700,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      // Save
                      ElevatedButton(
                        onPressed: () {
                          if (titleCtrl.text.trim().isEmpty ||
                              contentCtrl.text.trim().isEmpty) {
                            Get.snackbar(
                              "កំហុស",
                              "សូមបញ្ចូលព័ត៌មានដែលចាំបាច់!",
                              backgroundColor: Colors.red,
                              colorText: Colors.white,
                              snackPosition: SnackPosition.BOTTOM,
                            );
                            return;
                          }

                          if (isEdit) {
                            final id = announcement['id']?.toString() ?? '';
                            controller.updateAnnouncement(
                              id: id,
                              title: titleCtrl.text.trim(),
                              content: contentCtrl.text.trim(),
                              status: selectedStat == 'ផ្សព្វផ្សាយ'
                                  ? 'PUBLISHED'
                                  : 'DRAFT',
                              priority: selectedCat == 'បន្ទាន់'
                                  ? 'IMPORTANT'
                                  : 'NORMAL',
                            );
                          } else {
                            controller.createAnnouncement(
                              title: titleCtrl.text.trim(),
                              content: contentCtrl.text.trim(),
                              status: selectedStat == 'ផ្សព្វផ្សាយ'
                                  ? 'PUBLISHED'
                                  : 'DRAFT',
                              priority: selectedCat == 'បន្ទាន់'
                                  ? 'IMPORTANT'
                                  : 'NORMAL',
                            );
                          }
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(0, 0),
                          backgroundColor: const Color(0xff8A6514),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                        ),
                        child: Text(
                          "រក្សាទុក",
                          style: GoogleFonts.kantumruyPro(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // --- Confirm Delete Dialog ---
  void _showConfirmDeleteDialog(
    BuildContext context,
    Map<String, dynamic> announcement,
  ) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.warning_amber_rounded,
                  color: Colors.red,
                  size: 56,
                ),
                const SizedBox(height: 16),
                Text(
                  "លុបសេចក្តីប្រកាស?",
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff0F172A),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  "តើអ្នកពិតជាចង់លុបសេចក្តីប្រកាសនេះមែនទេ? សកម្មភាពនេះមិនអាចត្រឡប់ក្រោយបានឡើយ។",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 13,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          side: BorderSide(color: Colors.grey.shade300),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: Text(
                          "បោះបង់",
                          style: GoogleFonts.kantumruyPro(
                            color: Colors.grey.shade700,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          final id = announcement['id']?.toString() ?? '';
                          if (id.isNotEmpty) {
                            controller.deleteAnnouncement(id);
                          }
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(0, 0),
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: Text(
                          "លុប",
                          style: GoogleFonts.kantumruyPro(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // --- Shared / Custom Dropdown Styling ---
  Widget _buildCustomDropdown({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    final safeValue = items.contains(value) ? value : items.first;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label,
            style: GoogleFonts.kantumruyPro(
              color: const Color(0xff8A6514),
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        DropdownButtonFormField<String>(
          value: safeValue,
          items: items
              .map(
                (item) => DropdownMenuItem<String>(
                  value: item,
                  child: Text(
                    item,
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xff1E293B),
                    ),
                  ),
                ),
              )
              .toList(),
          onChanged: onChanged,
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Color(0xff8A6514),
            size: 20,
          ),
          elevation: 2,
          dropdownColor: Colors.white,
          style: GoogleFonts.kantumruyPro(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: const Color(0xff1E293B),
          ),
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 10,
            ),
            filled: true,
            fillColor: const Color(0xffF8FAFC),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey.shade200, width: 1.5),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xff8A6514),
                width: 1.5,
              ),
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey.shade200, width: 1.5),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDatePickerField(
    BuildContext context, {
    required String label,
    required DateTime? selectedDate,
    required VoidCallback onTap,
  }) {
    final String dateText = selectedDate != null
        ? "${selectedDate.month.toString().padLeft(2, '0')}/${selectedDate.day.toString().padLeft(2, '0')}/${selectedDate.year}"
        : "mm/dd/yyyy";

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label,
            style: GoogleFonts.kantumruyPro(
              color: const Color(0xff8A6514),
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xffF8FAFC),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade200, width: 1.5),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  dateText,
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: selectedDate != null
                        ? const Color(0xff1E293B)
                        : Colors.grey.shade400,
                  ),
                ),
                Icon(
                  Icons.calendar_today_rounded,
                  size: 16,
                  color: selectedDate != null
                      ? const Color(0xff8A6514)
                      : Colors.grey.shade400,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _newsCard({
    required String category,
    required String title,
    required String time,
    required VoidCallback onTap,
  }) {
    String khmerCat = category;
    Color catColor = const Color(0xff8A6514);
    Color catBg = const Color(0xff8A6514).withOpacity(0.08);

    final upperCat = category.toUpperCase();
    if (upperCat == 'URGENT' || upperCat == 'បន្ទាន់') {
      khmerCat = "បន្ទាន់";
      catColor = const Color(0xffEF4444);
      catBg = const Color(0xffEF4444).withOpacity(0.08);
    } else if (upperCat == 'POLICY' || upperCat == 'គោលការណ៍') {
      khmerCat = "គោលការណ៍";
      catColor = const Color(0xff9333EA);
      catBg = const Color(0xff9333EA).withOpacity(0.08);
    } else if (upperCat == 'EVENT' || upperCat == 'ព្រឹត្តិការណ៍') {
      khmerCat = "ព្រឹត្តិការណ៍";
      catColor = const Color(0xffD97706);
      catBg = const Color(0xffD97706).withOpacity(0.08);
    } else {
      khmerCat = "ទូទៅ";
      catColor = const Color(0xff8A6514);
      catBg = const Color(0xff8A6514).withOpacity(0.08);
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              border: Border(left: BorderSide(color: catColor, width: 4)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: catBg,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        khmerCat,
                        style: GoogleFonts.kantumruyPro(
                          color: catColor,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.access_time_rounded,
                          size: 12,
                          color: Colors.grey,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          time,
                          style: GoogleFonts.kantumruyPro(
                            fontSize: 11,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff1E293B),
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Text(
                      "អានបន្ថែម",
                      style: GoogleFonts.kantumruyPro(
                        color: catColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Icon(
                      Icons.arrow_forward_rounded,
                      size: 12,
                      color: catColor,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showAnnouncementDialog(
    BuildContext context,
    Map<String, dynamic> announcement,
  ) {
    final String time =
        announcement['createdAt']?.toString() ??
        announcement['time']?.toString() ??
        '';
    final String title =
        announcement['title']?.toString() ??
        announcement['titleEn']?.toString() ??
        'គ្មានចំណងជើង';
    final String content =
        announcement['content']?.toString() ?? announcement['body'] ?? '';
    final String cleanContent = content
        .replaceAll(RegExp(r'<[^>]*>|&nbsp;'), ' ')
        .trim();

    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xffA88400).withOpacity(0.08),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      "សេចក្តីប្រកាស",
                      style: GoogleFonts.kantumruyPro(
                        color: const Color(0xffA88400),
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: Colors.grey),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (time.isNotEmpty)
                Row(
                  children: [
                    const Icon(
                      Icons.access_time_rounded,
                      size: 14,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        _formatKhmerDate(time),
                        style: GoogleFonts.kantumruyPro(
                          color: Colors.grey,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 12),
              Text(
                title,
                style: GoogleFonts.kantumruyPro(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xff1E293B),
                ),
              ),
              const Divider(
                height: 24,
                color: Color(0xffF1F5F9),
                thickness: 1.5,
              ),
              Flexible(
                child: SingleChildScrollView(
                  child: Text(
                    cleanContent,
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 15,
                      color: const Color(0xff475569),
                      height: 1.6,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xffA88400),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(
                    "បិទ",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeaturedCard(
    BuildContext context,
    Map<String, dynamic> announcement,
  ) {
    final String time =
        announcement['createdAt']?.toString() ??
        announcement['time']?.toString() ??
        '';
    final String title =
        announcement['title']?.toString() ??
        announcement['titleEn']?.toString() ??
        'គ្មានចំណងជើង';
    final String titleKh = announcement['titleKh']?.toString() ?? '';
    final String content =
        announcement['content']?.toString() ?? announcement['body'] ?? '';

    final String cleanContent = content
        .replaceAll(RegExp(r'<[^>]*>|&nbsp;'), ' ')
        .trim();

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: const Color(0xff8A6514).withOpacity(0.04),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showAnnouncementDialog(context, announcement),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Banner Indicator / Top Accent Gradient
              Container(
                height: 5,
                width: double.infinity,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xff8A6514), Color(0xffE9D8A6)],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xff8A6514).withOpacity(0.08),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.campaign_rounded,
                                size: 14,
                                color: Color(0xff8A6514),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                "សេចក្តីប្រកាសថ្មីបំផុត",
                                style: GoogleFonts.kantumruyPro(
                                  color: const Color(0xff8A6514),
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (time.isNotEmpty)
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.access_time_rounded,
                                size: 12,
                                color: Colors.grey,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                _formatKhmerDate(time, short: true),
                                style: GoogleFonts.kantumruyPro(
                                  color: Colors.grey,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(
                      title,
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xff1E293B),
                        height: 1.3,
                      ),
                    ),
                    if (titleKh.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(
                        titleKh,
                        style: GoogleFonts.kantumruyPro(
                          color: const Color(0xff8A6514),
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                    const Divider(
                      height: 24,
                      color: Color(0xffF1F5F9),
                      thickness: 1.2,
                    ),
                    Text(
                      cleanContent,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.kantumruyPro(
                        fontSize: 14,
                        color: const Color(0xff475569),
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Text(
                          "អានបន្ថែម",
                          style: GoogleFonts.kantumruyPro(
                            color: const Color(0xff8A6514),
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(
                          Icons.arrow_forward_rounded,
                          size: 12,
                          color: Color(0xff8A6514),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.lock_outline_rounded,
              color: Colors.grey,
              size: 64,
            ),
            const SizedBox(height: 16),
            Text(
              "ការចូលប្រើប្រាស់ត្រូវបានកំណត់",
              style: GoogleFonts.kantumruyPro(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              controller.errorMessage.value,
              textAlign: TextAlign.center,
              style: GoogleFonts.kantumruyPro(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () => controller.fetchAnnouncements(),
              icon: const Icon(Icons.refresh_rounded),
              label: Text(
                "ព្យាយាមម្តងទៀត",
                style: GoogleFonts.kantumruyPro(fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xffD4AF37),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.notifications_off_outlined,
              color: Colors.grey,
              size: 64,
            ),
            const SizedBox(height: 16),
            Text(
              "គ្មានសេចក្តីប្រកាស",
              style: GoogleFonts.kantumruyPro(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "មិនទាន់មានសេចក្តីប្រកាសនៅឡើយទេ។",
              textAlign: TextAlign.center,
              style: GoogleFonts.kantumruyPro(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () => controller.fetchAnnouncements(),
              icon: const Icon(Icons.refresh_rounded),
              label: Text(
                "ផ្ទុកឡើងវិញ",
                style: GoogleFonts.kantumruyPro(fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xffD4AF37),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatKhmerDate(String? dateStr, {bool short = false}) {
    if (dateStr == null || dateStr.isEmpty) return '';
    try {
      final dateTime = DateTime.tryParse(dateStr);
      if (dateTime == null) return dateStr;

      const khmerMonths = [
        'មករា',
        'កុម្ភៈ',
        'មីនា',
        'មេសា',
        'ឧសភា',
        'មិថុនា',
        'កក្កដា',
        'សីហា',
        'កញ្ញា',
        'តុលា',
        'វិច្ឆិកា',
        'ធ្នូ',
      ];

      final day = dateTime.day.toString();
      final month = khmerMonths[dateTime.month - 1];
      final year = dateTime.year.toString();
      final hour = dateTime.hour.toString().padLeft(2, '0');
      final minute = dateTime.minute.toString().padLeft(2, '0');

      // Convert digits to Khmer
      String toKhmer(String input) {
        const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        const khmer = ['០', '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩'];
        String res = input;
        for (int i = 0; i < english.length; i++) {
          res = res.replaceAll(english[i], khmer[i]);
        }
        return res;
      }

      if (short) {
        return '${toKhmer(day)} $month ${toKhmer(year)}, ${toKhmer(hour)}:${toKhmer(minute)}';
      }
      return 'ថ្ងៃទី ${toKhmer(day)} ខែ$month ឆ្នាំ${toKhmer(year)} ម៉ោង ${toKhmer(hour)}:${toKhmer(minute)}';
    } catch (_) {
      return dateStr;
    }
  }

  Widget _buildPaginationControls() {
    return Obx(() {
      final total = controller.totalPages;
      final current = controller.currentPage.value;

      String toKhmer(int number) {
        const khmerDigits = ['០', '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩'];
        return number
            .toString()
            .split('')
            .map((char) {
              final val = int.tryParse(char);
              return val != null ? khmerDigits[val] : char;
            })
            .join('');
      }

      return Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(
            top: BorderSide(
              color: const Color(0xffD4AF37).withOpacity(0.15),
              width: 1,
            ),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ElevatedButton(
              onPressed: current > 1
                  ? () => controller.currentPage.value--
                  : null,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(0, 0),
                backgroundColor: const Color(0xff8A6514),
                foregroundColor: Colors.white,
                disabledBackgroundColor: Colors.grey.shade200,
                disabledForegroundColor: Colors.grey.shade400,
                elevation: 0,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.arrow_back_ios_new_rounded, size: 12),
                  const SizedBox(width: 6),
                  Text(
                    "មុន",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              "ទំព័រ ${toKhmer(current)} នៃ ${toKhmer(total)}",
              style: GoogleFonts.kantumruyPro(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: const Color(0xff1E293B),
              ),
            ),
            ElevatedButton(
              onPressed: current < total
                  ? () => controller.currentPage.value++
                  : null,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(0, 0),
                backgroundColor: const Color(0xff8A6514),
                foregroundColor: Colors.white,
                disabledBackgroundColor: Colors.grey.shade200,
                disabledForegroundColor: Colors.grey.shade400,
                elevation: 0,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "បន្ទាប់",
                    style: GoogleFonts.kantumruyPro(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.arrow_forward_ios_rounded, size: 12),
                ],
              ),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildStatsCardsRow() {
    return Obx(() {
      final list = controller.announcements;
      final totalCount = list.length;
      final publishedCount = list.where((ann) {
        final status = (ann['status'] ?? '').toString().toUpperCase();
        return status == 'PUBLISHED' ||
            status == 'ACTIVE' ||
            status == 'ផ្សព្វផ្សាយ' ||
            status.isEmpty;
      }).length;
      final scheduledCount = 0;
      final draftCount = list.where((ann) {
        final status = (ann['status'] ?? '').toString().toUpperCase();
        return status == 'DRAFT' || status == 'INACTIVE' || status == 'ព្រាង';
      }).length;

      final double screenWidth = Get.width;
      final int crossAxisCount = screenWidth > 600 ? 4 : 2;
      final double childAspectRatio = screenWidth > 600
          ? 2.5
          : (screenWidth < 360 ? 1.6 : 1.9);

      return GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: childAspectRatio,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        children: [
          _buildStatCardItem(
            title: "សេចក្តីប្រកាសសរុប",
            value: totalCount.toString(),
            subtitle: "សេចក្តីប្រកាសទាំងអស់ក្នុងប្រព័ន្ធ",
            icon: Icons.campaign_rounded,
            iconColor: const Color(0xff2563EB),
            bgIconColor: const Color(0xffEFF6FF),
          ),
          _buildStatCardItem(
            title: "បានផ្សព្វផ្សាយ",
            value: publishedCount.toString(),
            subtitle: "អាចមើលបានដោយអ្នកប្រើប្រាស់",
            icon: Icons.check_circle_rounded,
            iconColor: const Color(0xff10B981),
            bgIconColor: const Color(0xffECFDF5),
          ),
          _buildStatCardItem(
            title: "បានកំណត់ពេល",
            value: scheduledCount.toString(),
            subtitle: "រង់ចាំពេលផ្សព្វផ្សាយ",
            icon: Icons.date_range_rounded,
            iconColor: const Color(0xffD97706),
            bgIconColor: const Color(0xffFEF3C7),
          ),
          _buildStatCardItem(
            title: "សេចក្តីព្រាង",
            value: draftCount.toString(),
            subtitle: "បានរក្សាទុកជាព្រាង",
            icon: Icons.save_rounded,
            iconColor: const Color(0xff7C3AED),
            bgIconColor: const Color(0xffF3E8FF),
          ),
        ],
      );
    });
  }

  Widget _buildStatCardItem({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required Color bgIconColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xffE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: bgIconColor,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: iconColor, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff64748B),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xff0F172A),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.kantumruyPro(
                    fontSize: 9,
                    color: const Color(0xff94A3B8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
