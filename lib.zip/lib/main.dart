import 'package:core_portal/routes/apppage.dart';
import 'package:core_portal/routes/page_route.dart';
import 'package:core_portal/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await GetStorage.init();

  final box = GetStorage();
  final token = box.read('token');

  String initialRoute = AppRoutes.login;
  if (token != null && token.toString().isNotEmpty) {
    final rolesRaw = box.read('roles');
    final List<String> roles = rolesRaw is List
        ? List<String>.from(rolesRaw)
        : (box.read('isAdmin') == true ? ['admin'] : ['user']);

    if (roles.contains('super_admin')) {
      initialRoute = AppRoutes.superAdmin;
    } else if (roles.contains('user')) {
      initialRoute = AppRoutes.mainPage;
    } else if (roles.contains('admin')) {
      initialRoute = AppRoutes.admin;
    } else {
      initialRoute = AppRoutes.mainPage;
    }
  }

  runApp(MainApp(initialRoute: initialRoute));
}

class MainApp extends StatelessWidget {
  final String initialRoute;

  const MainApp({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      initialRoute: initialRoute,
      getPages: AppPages.routes,
    );
  }
}
