import 'dart:convert';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:dio/dio.dart';
import 'package:get_storage/get_storage.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import 'package:get/get.dart';
import 'package:core_portal/routes/page_route.dart';

class ApiConfig {
  // Set to true if you are testing on a physical mobile device on the same Wi-Fi
  static const bool usePhysicalDevice = false;
  static const String pcIpAddress = ''; // Your computer's IP on Wi-Fi

  static String get bffHost {
    if (usePhysicalDevice) {
      return pcIpAddress;
    }
    if (kIsWeb) {
      return 'localhost';
    }
    if (Platform.isAndroid) {
      return '10.0.2.2'; // Loopback to host machine in Android Emulator
    }
    return 'localhost'; // Default (iOS Simulator / Desktop)
  }

  static const bool useLocalApi = true;

  static String get baseUrl {
    if (useLocalApi) {
      if (kIsWeb) {
        return 'http://localhost:8000';
      }
      if (Platform.isAndroid) {
        return 'http://10.0.2.2:8000'; // Android emulator loopback
      }
      return 'http://127.0.0.1:8000'; // iOS emulator/simulator or desktop
    }
    return 'https://core-app.interior.gov.kh';
  }

  late Dio dio;

  ApiConfig() {
    dio =
        Dio(
            BaseOptions(
              baseUrl: baseUrl,
              connectTimeout: const Duration(seconds: 10),
              receiveTimeout: const Duration(seconds: 10),
              headers: const {'Content-Type': 'application/json'},
            ),
          )
          ..interceptors.add(
            PrettyDioLogger(
              requestBody: true,
              requestHeader: true,
              responseBody: true,
            ),
          );

    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          final box = GetStorage();
          final String? token = box.read('token');
          if (token != null && token.isNotEmpty) {
            if (isTokenExpired(token)) {
              box.remove('token');
              box.remove('isAdmin');
              Get.offAllNamed(AppRoutes.login);
              return handler.reject(
                DioException(
                  requestOptions: options,
                  error: "Token has expired",
                  type: DioExceptionType.cancel,
                ),
              );
            }
            options.headers.remove('authorization');
            options.headers['Authorization'] = 'Bearer $token';
          }
          return handler.next(options);
        },
        onError: (DioException e, handler) async {
          if (e.response?.statusCode == 401) {
            final box = GetStorage();
            await box.remove('token'); // Clear the expired token
            await box.remove('isAdmin'); // Clear the admin flag
            Get.offAllNamed(AppRoutes.login); // Redirect to Login
          }
          return handler.next(e);
        },
      ),
    );
  }

  static bool isTokenExpired(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) return false;

      final String payload = parts[1];
      final String normalized = base64Url.normalize(payload);
      final String decoded = utf8.decode(base64Url.decode(normalized));
      final Map<String, dynamic> map = json.decode(decoded);

      if (map.containsKey('exp')) {
        final int exp = map['exp'];
        final DateTime expDate = DateTime.fromMillisecondsSinceEpoch(
          exp * 1000,
        );
        return DateTime.now().isAfter(expDate);
      }
    } catch (_) {
      return false;
    }
    return false;
  }
}
