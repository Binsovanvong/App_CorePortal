import 'package:core_portal/core/api/services/api_service.dart';
import 'package:dio/dio.dart';
import 'package:flutter/widgets.dart';
import 'package:get_storage/get_storage.dart'; // <-- CRITICAL: For reading the token

class AuthService {
  final ApiService apiService = ApiService();

  Future<Map<String, dynamic>> loginService({
    required String username,
    required String password,
  }) async {
    var response = await apiService.post(
      endpoint: '/api/mobile/auth/login',
      data: {'username': username, 'password': password},
    );

    return response;
  }

  // Changed return type to Future<dynamic> to match apiService.get()
  Future<dynamic> fetchProfile() async {
    try {
      final box = GetStorage();
      final String? token = box.read(
        'token',
      ); // Retrieve token from local storage

      return await apiService.get(
        endpoint: '/api/mobile/accounts/profile',
        headers: {
          'authorization':
              'Bearer $token', // Pass token to match your Swagger spec
        },
      );
    } on DioException catch (e) {
      debugPrint("PROFILE STATUS: ${e.response?.statusCode}");
      debugPrint("PROFILE BODY: ${e.response?.data}");
      rethrow;
    }
  }

  Future<dynamic> logoutService() async {
    try {
      final box = GetStorage();
      final String? token = box.read(
        'token',
      ); // Retrieve token from local storage

      return await apiService.post(
        endpoint: '/api/mobile/auth/logout',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("LOGOUT STATUS: ${e.response?.statusCode}");
      debugPrint("LOGOUT BODY: ${e.response?.data}");
      rethrow;
    }
  }

  Future<dynamic> fetchApps() async {
    try {
      final box = GetStorage();
      final String? token = box.read(
        'token',
      ); // Retrieve token from local storage

      return await apiService.get(
        endpoint: '/api/mobile/portals/apps',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("APPS STATUS: ${e.response?.statusCode}");
      debugPrint("APPS BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Fetch all apps (active + inactive) via the admin endpoint.
  /// Used by admin/super_admin dashboards.
  Future<dynamic> fetchAdminApps() async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');

      return await apiService.get(
        endpoint: '/api/mobile/admin/portal-apps',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("ADMIN APPS STATUS: ${e.response?.statusCode}");
      debugPrint("ADMIN APPS BODY: ${e.response?.data}");
      rethrow;
    }
  }

  Future<dynamic> changePasswordService({
    required String username,
    required String oldPassword,
    required String newPassword,
  }) async {
    try {
      final box = GetStorage();
      final String? token = box.read(
        'token',
      ); // Retrieve token from local storage

      return await apiService.put(
        endpoint: '/api/mobile/accounts/change-password',
        headers: {'authorization': 'Bearer $token'},
        data: {
          'username': username,
          'current_password': oldPassword,
          'new_password': newPassword,
        },
      );
    } on DioException catch (e) {
      debugPrint("CHANGE PASSWORD STATUS: ${e.response?.statusCode}");
      debugPrint("CHANGE PASSWORD BODY: ${e.response?.data}");
      rethrow;
    }
  }

  Future<dynamic> fetchAnnouncements() async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');

      return await apiService.get(
        endpoint: '/api/mobile/portals/announcements',
        headers: {
          if (token != null && token.isNotEmpty)
            'authorization': 'Bearer $token',
        },
      );
    } on DioException catch (e) {
      debugPrint("ANNOUNCEMENTS STATUS: ${e.response?.statusCode}");
      debugPrint("ANNOUNCEMENTS BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: fetch ALL announcements (PUBLISHED + DRAFT + SCHEDULED)
  Future<dynamic> fetchAdminAnnouncements() async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.get(
        endpoint: '/api/mobile/admin/announcements',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("ADMIN ANN STATUS: ${e.response?.statusCode}");
      debugPrint("ADMIN ANN BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: create a new announcement
  Future<dynamic> createAdminAnnouncement(Map<String, dynamic> data) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.post(
        endpoint: '/api/mobile/admin/announcements',
        headers: {'authorization': 'Bearer $token'},
        data: data,
      );
    } on DioException catch (e) {
      debugPrint("CREATE ANN STATUS: ${e.response?.statusCode}");
      debugPrint("CREATE ANN BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: update an existing announcement by id
  Future<dynamic> updateAdminAnnouncement(
    String id,
    Map<String, dynamic> data,
  ) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.put(
        endpoint: '/api/mobile/admin/announcements/$id',
        headers: {'authorization': 'Bearer $token'},
        data: data,
      );
    } on DioException catch (e) {
      debugPrint("UPDATE ANN STATUS: ${e.response?.statusCode}");
      debugPrint("UPDATE ANN BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: delete an announcement by id
  Future<dynamic> deleteAdminAnnouncement(String id) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.delete(
        endpoint: '/api/mobile/admin/announcements/$id',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("DELETE ANN STATUS: ${e.response?.statusCode}");
      debugPrint("DELETE ANN BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: create a new portal app
  Future<dynamic> createAdminApp(Map<String, dynamic> data) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.post(
        endpoint: '/api/mobile/admin/portal-apps',
        headers: {'authorization': 'Bearer $token'},
        data: data,
      );
    } on DioException catch (e) {
      debugPrint("CREATE APP STATUS: ${e.response?.statusCode}");
      debugPrint("CREATE APP BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: update an existing portal app
  Future<dynamic> updateAdminApp(String id, Map<String, dynamic> data) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.put(
        endpoint: '/api/mobile/admin/portal-apps/$id',
        headers: {'authorization': 'Bearer $token'},
        data: data,
      );
    } on DioException catch (e) {
      debugPrint("UPDATE APP STATUS: ${e.response?.statusCode}");
      debugPrint("UPDATE APP BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: delete a portal app by id
  Future<dynamic> deleteAdminApp(String id) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.delete(
        endpoint: '/api/mobile/admin/portal-apps/$id',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("DELETE APP STATUS: ${e.response?.statusCode}");
      debugPrint("DELETE APP BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: upload icon for a portal app
  Future<dynamic> uploadAppIcon({
    required String appId,
    required List<int> fileBytes,
    required String fileName,
  }) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');

      final formData = FormData.fromMap({
        'file': MultipartFile.fromBytes(fileBytes, filename: fileName),
      });

      return await apiService.post(
        endpoint: '/api/mobile/admin/portal-apps/$appId/icon',
        headers: {
          'authorization': 'Bearer $token',
          'Content-Type': 'multipart/form-data',
        },
        data: formData,
      );
    } on DioException catch (e) {
      debugPrint("UPLOAD ICON STATUS: ${e.response?.statusCode}");
      debugPrint("UPLOAD ICON BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: create a new portal role
  Future<dynamic> createAdminRole(Map<String, dynamic> data) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.post(
        endpoint: '/api/mobile/admin/portal-user-roles',
        headers: {'authorization': 'Bearer $token'},
        data: data,
      );
    } on DioException catch (e) {
      debugPrint("CREATE ROLE STATUS: ${e.response?.statusCode}");
      debugPrint("CREATE ROLE BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: update an existing portal role
  Future<dynamic> updateAdminRole(
    String code,
    Map<String, dynamic> data,
  ) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.put(
        endpoint: '/api/mobile/admin/portal-user-roles/$code',
        headers: {'authorization': 'Bearer $token'},
        data: data,
      );
    } on DioException catch (e) {
      debugPrint("UPDATE ROLE STATUS: ${e.response?.statusCode}");
      debugPrint("UPDATE ROLE BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: delete a portal role
  Future<dynamic> deleteAdminRole(String code) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.delete(
        endpoint: '/api/mobile/admin/portal-user-roles/$code',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("DELETE ROLE STATUS: ${e.response?.statusCode}");
      debugPrint("DELETE ROLE BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: assign user to groups
  Future<dynamic> assignUserGroups(
    String userIdOrUsername,
    List<String> groups,
  ) async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.post(
        endpoint: '/api/mobile/admin/users/$userIdOrUsername/groups',
        headers: {'authorization': 'Bearer $token'},
        data: {'groups': groups},
      );
    } on DioException catch (e) {
      debugPrint("ASSIGN GROUPS STATUS: ${e.response?.statusCode}");
      debugPrint("ASSIGN GROUPS BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Admin: fetch all portal groups
  Future<dynamic> fetchPortalGroups() async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');
      return await apiService.get(
        endpoint: '/api/mobile/admin/portal-groups',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("FETCH PORTAL GROUPS STATUS: ${e.response?.statusCode}");
      debugPrint("FETCH PORTAL GROUPS BODY: ${e.response?.data}");
      rethrow;
    }
  }

  /// Fetch ONLY the current logged-in user's real employment information array
  Future<dynamic> fetchMyEmploymentInfos() async {
    try {
      final box = GetStorage();
      final String? token = box.read('token');

      return await apiService.get(
        endpoint: '/api/mobile/accounts/profile/employment-infos',
        headers: {'authorization': 'Bearer $token'},
      );
    } on DioException catch (e) {
      debugPrint("EMPLOYMENT INFO API ERROR: ${e.response?.statusCode}");
      rethrow;
    }
  }
}
