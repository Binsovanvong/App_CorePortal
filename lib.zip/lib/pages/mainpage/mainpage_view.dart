import 'package:core_portal/controllers/nav_controller.dart';
import 'package:core_portal/screens/home/home_view.dart';
import 'package:core_portal/screens/setting/setting_view.dart';
import 'package:core_portal/screens/announcement/announcement_view.dart';
import 'package:core_portal/screens/application/application_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

part 'mainpage_controller.dart';

class MainpageView extends StatelessWidget {
  MainpageView({super.key});

  // Use Get.find to sync with the instance from MainpageBinding
  final NavController controller = Get.find<NavController>();

  final List<Widget> pages = [
    HomeView(),
    const ApplicationView(),
    const AnnouncementView(),
    SettingView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() => pages[controller.currentIndex.value]),
      bottomNavigationBar: Obx(
        () => Container(
          margin: const EdgeInsets.only(left: 16, right: 16, bottom: 24),
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.95),
            borderRadius: BorderRadius.circular(35),
            border: Border.all(
              color: const Color(0xffD4AF37).withOpacity(0.2),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xffD4AF37).withOpacity(0.08),
                blurRadius: 25,
                offset: const Offset(0, 12),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildNavItem(0, Icons.home_rounded, "ទំព័រដើម"),
              _buildNavItem(1, Icons.grid_view_rounded, "កម្មវិធី"),
              _buildNavItem(
                2,
                Icons.campaign_rounded,
                "សេចក្តីប្រកាស",
                badge: controller.unreadCount.value > 0
                    ? controller.unreadCount.value.toString()
                    : null,
              ),
              _buildNavItem(3, Icons.settings_rounded, "ការកំណត់"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(
    int index,
    IconData icon,
    String label, {
    String? badge,
  }) {
    final isSelected = controller.currentIndex.value == index;

    return GestureDetector(
      onTap: () => controller.changeTab(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xffFCFAF3) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? const Color(0xffE9D8A6).withOpacity(0.5)
                : Colors.transparent,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(
                  icon,
                  color: isSelected
                      ? const Color(0xff8A6514)
                      : Colors.grey.shade500,
                  size: 22,
                ),
                if (badge != null)
                  Positioned(
                    right: -6,
                    top: -6,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      constraints: const BoxConstraints(
                        minWidth: 16,
                        minHeight: 16,
                      ),
                      child: Text(
                        badge,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 6),
            AnimatedCrossFade(
              firstChild: Text(
                label,
                style: const TextStyle(
                  color: Color(0xff8A6514),
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.1,
                ),
              ),
              secondChild: const SizedBox.shrink(),
              crossFadeState: isSelected
                  ? CrossFadeState.showFirst
                  : CrossFadeState.showSecond,
              duration: const Duration(milliseconds: 200),
            ),
          ],
        ),
      ),
    );
  }
}
